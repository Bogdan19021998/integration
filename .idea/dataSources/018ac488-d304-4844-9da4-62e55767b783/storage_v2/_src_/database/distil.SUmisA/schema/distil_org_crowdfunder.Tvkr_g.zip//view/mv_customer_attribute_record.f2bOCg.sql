create view mv_customer_attribute_record as
SELECT customer_attribute_record_1576718075413.id,
       customer_attribute_record_1576718075413.customer_id,
       customer_attribute_record_1576718075413.data_source_id,
       customer_attribute_record_1576718075413.data_source_name,
       customer_attribute_record_1576718075413.attribute_id,
       customer_attribute_record_1576718075413.attribute_distil_name,
       customer_attribute_record_1576718075413.attribute_display_name,
       customer_attribute_record_1576718075413.attribute_type,
       customer_attribute_record_1576718075413.attribute_data_tag,
       customer_attribute_record_1576718075413.value_integer,
       customer_attribute_record_1576718075413.value_double,
       customer_attribute_record_1576718075413.value_string,
       customer_attribute_record_1576718075413.value_text,
       customer_attribute_record_1576718075413.value_date,
       customer_attribute_record_1576718075413.value_boolean,
       customer_attribute_record_1576718075413.value_long
FROM distil_org_crowdfunder.customer_attribute_record_1576718075413;

alter table mv_customer_attribute_record
  owner to "distilAdmin";

