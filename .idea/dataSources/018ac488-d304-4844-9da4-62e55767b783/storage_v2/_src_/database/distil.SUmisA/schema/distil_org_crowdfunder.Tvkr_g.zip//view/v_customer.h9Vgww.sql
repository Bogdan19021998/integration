create view v_customer as
SELECT customer_1576718075413.id,
       customer_1576718075413.date_created,
       customer_1576718075413.date_updated,
       customer_1576718075413.is_anonymous_only,
       customer_1576718075413.deleted
FROM distil_org_crowdfunder.customer_1576718075413;

alter table v_customer
  owner to "distilAdmin";

