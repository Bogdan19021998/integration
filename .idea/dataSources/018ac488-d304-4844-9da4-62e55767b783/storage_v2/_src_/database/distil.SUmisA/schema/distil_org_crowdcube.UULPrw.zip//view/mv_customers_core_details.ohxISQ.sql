create view mv_customers_core_details as
SELECT customers_core_details_1576707133229.id,
       customers_core_details_1576707133229.external_id,
       customers_core_details_1576707133229.first_name,
       customers_core_details_1576707133229.last_name,
       customers_core_details_1576707133229.email_address,
       customers_core_details_1576707133229.mobile_number,
       customers_core_details_1576707133229.postal_code,
       customers_core_details_1576707133229.country_code
FROM distil_org_crowdcube.customers_core_details_1576707133229;

alter table mv_customers_core_details
  owner to "distilAdmin";

