create view v_customer as
SELECT customer_1576707133229.id,
       customer_1576707133229.date_created,
       customer_1576707133229.date_updated,
       customer_1576707133229.is_anonymous_only,
       customer_1576707133229.deleted
FROM distil_org_crowdcube.customer_1576707133229;

alter table v_customer
  owner to "distilAdmin";

