create view mv_customers_core_details as
SELECT customers_core_details_1576718075413.id,
       customers_core_details_1576718075413.external_id,
       customers_core_details_1576718075413.first_name,
       customers_core_details_1576718075413.last_name,
       customers_core_details_1576718075413.email_address,
       customers_core_details_1576718075413.mobile_number,
       customers_core_details_1576718075413.postal_code,
       customers_core_details_1576718075413.country_code
FROM distil_org_crowdfunder.customers_core_details_1576718075413;

alter table mv_customers_core_details
  owner to "distilAdmin";

