create view v_distil_customers as
SELECT DISTINCT (s.user_key)::character varying                                                                                                  AS id,
                "first_value"((s.user_firstname)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS first_name,
                "first_value"((s.user_lastname)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS last_name,
                "first_value"((s.user_email)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS email_address,
                "first_value"((s.telephone)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS mobile_phone_no,
                "first_value"(c.subscribed_newsletter)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS gdpr_status_subscribed,
                "first_value"(NULL::boolean)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS gdpr_status_right_of_access_requested,
                CASE
                  WHEN (gf.created_at < ('now'::text)::date) THEN true
                  ELSE false END                                                                                                                 AS gdpr_anonymise_data,
                NULL::text                                                                                                                       AS facebook_slug,
                NULL::text                                                                                                                       AS twitter_handle,
                NULL::text                                                                                                                       AS instagram_slug,
                NULL::text                                                                                                                       AS linkedin_slug,
                "first_value"((s.private_address_address_1)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS postal_address_line_1,
                "first_value"((s.private_address_address_2)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS postal_address_line_2,
                "first_value"((s.private_address_town)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS postal_address_line_town,
                "first_value"((s.private_address_county)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS postal_address_region,
                "first_value"((s.private_address_country)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS postal_address_country,
                "first_value"((s.private_address_post_code)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS postal_address_postal_code,
                "first_value"((s.private_address_address_1)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS billing_address_line_1,
                "first_value"((s.private_address_address_2)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS billing_address_line_2,
                "first_value"((s.private_address_town)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS billing_address_line_town,
                "first_value"((s.private_address_county)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS billing_address_region,
                "first_value"((s.private_address_country)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS billing_address_country,
                "first_value"((s.private_address_post_code)::text)
                              OVER ( PARTITION BY s.user_key ORDER BY c.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS billing_address_postal_code,
                pp.pitch_key                                                                                                                     AS associated_pitch_id,
                pp.pitch_name                                                                                                                    AS associated_pitch_name,
                pp.pitch_launch_probability                                                                                                      AS associated_pitch_launch_probability,
                pp.pitch_launch_probability_confidence                                                                                           AS associated_pitch_launch_probability_confidence,
                ist.first_investment,
                ist.last_investment,
                ist.number_investments,
                ist.value_investment,
                ist.smallest_investment,
                ist.largest_investment,
                ist.avg_investment,
                ist.web_investment_count,
                ist.ios_investment_count,
                ist.android_investment_count,
                ist.value_last_5_web,
                ist.value_last_5_ios,
                ist.value_last_5_android,
                ist.last_5_preffered_investment_platform
FROM ((((dim_users_static s LEFT JOIN dim_users_changing c ON ((s.user_key = c.user_key))) LEFT JOIN gdpr_forget gf ON ((s.user_key = gf.user_key))) LEFT JOIN experimental.v_distil_pitch_prob_to_cust pp ON (((pp.customer_external_id)::text = (s.user_key)::text)))
       LEFT JOIN v_distil_investor_entity_investment_stats ist ON ((ist.user_key = s.user_key)));

alter table v_distil_customers
  owner to ccdatawh;

