create view v_master_registration_events as
SELECT dim_events.event_key
FROM dim_events
WHERE (((((((dim_events.event_name)::text = 'registration_complete'::text) OR
           ((dim_events.event_name)::text = 'registration_completed'::text)) OR
          ((dim_events.event_name)::text = 'Registration complete email'::text)) OR
         ((dim_events.event_name)::text = 'Registration complete facebook'::text)) OR
        ((dim_events.event_name)::text = 'Registration complete google'::text)) OR
       ((dim_events.event_name)::text = 'Registration complete linkedin'::text));

alter table v_master_registration_events
  owner to ccdatawh;

