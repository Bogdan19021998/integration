create view v_max_amount_invested_bond_last_30_days as
SELECT "max"(pi.amount_in_gbp) AS "max"
FROM ccdwh_dev.fact_pitch_investments pi,
     ccdwh_dev.dim_pitches_static ps
WHERE (((((pi.pitch_key = ps.pitch_key) AND ((ps.product_type)::text = ('Bonds'::character varying)::text)) AND
         ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND
        (pi.investment_date_key >= (SELECT (dim_dates.date_key - 31)
                                    FROM ccdwh_dev.dim_dates
                                    WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
       (pi.investment_date_key < (SELECT dim_dates.date_key
                                  FROM ccdwh_dev.dim_dates
                                  WHERE (dim_dates.the_date = ('now'::character varying)::date))));

alter table v_max_amount_invested_bond_last_30_days
  owner to ccdatawh;

