create view v_band_uk_tenure as
SELECT ds.pcd,
       ds.perc_own_outright,
       onsdata.f_percent_band(ds.perc_own_outright, 5)             AS own_outright_band,
       ds.perc_own_with_mortage_or_loan,
       onsdata.f_percent_band(ds.perc_own_with_mortage_or_loan, 5) AS own_with_mortage_or_loan_band,
       ds.perc_shared_ownership,
       onsdata.f_percent_band(ds.perc_shared_ownership, 5)         AS shared_ownership_band,
       ds.perc_social_rent,
       onsdata.f_percent_band(ds.perc_social_rent, 5)              AS social_rent_band,
       ds.perc_private_rent,
       onsdata.f_percent_band(ds.perc_private_rent, 5)             AS private_rent_band,
       ds.perc_rent_free,
       onsdata.f_percent_band(ds.perc_rent_free, 5)                AS rent_free_band
FROM (SELECT (upper("replace"(btrim((onspd.pcd)::text), ' '::text, ''::text)))::character varying(8)                 AS pcd,
             ((uk_tenure.own_outright)::double precision /
              (uk_tenure.all_categories)::double precision)                                                          AS perc_own_outright,
             ((uk_tenure.own_with_mortage_or_loan)::double precision /
              (uk_tenure.all_categories)::double precision)                                                          AS perc_own_with_mortage_or_loan,
             ((uk_tenure.shared_ownership_part_own_or_rent)::double precision /
              (uk_tenure.all_categories)::double precision)                                                          AS perc_shared_ownership,
             ((uk_tenure.social_rent_total)::double precision /
              (uk_tenure.all_categories)::double precision)                                                          AS perc_social_rent,
             ((uk_tenure.private_rent_total)::double precision /
              (uk_tenure.all_categories)::double precision)                                                          AS perc_private_rent,
             ((uk_tenure.rent_free)::double precision /
              (uk_tenure.all_categories)::double precision)                                                          AS perc_rent_free
      FROM (onsdata.onspd
             LEFT JOIN onsdata.uk_tenure ON (((onspd.oa11)::text = (uk_tenure.geography_code)::text)))
      WHERE (uk_tenure.all_categories > 0)) ds;

alter table v_band_uk_tenure
  owner to ccdatawh;

