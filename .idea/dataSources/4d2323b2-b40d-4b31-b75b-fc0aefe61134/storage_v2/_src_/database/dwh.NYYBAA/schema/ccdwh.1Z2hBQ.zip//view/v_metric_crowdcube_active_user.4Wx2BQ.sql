create view v_metric_crowdcube_active_user as
SELECT derived_table2.user_key,
       CASE
         WHEN (derived_table2.registered_days_ago <= 30) THEN 'Active'::text
         WHEN (derived_table2.days_ago <= 30) THEN 'Active'::text
         WHEN ((derived_table2.days_ago > 30) AND (derived_table2.days_ago <= 60)) THEN '30-day churn'::text
         WHEN ((derived_table2.days_ago > 60) AND (derived_table2.days_ago <= 90)) THEN '60-day churn'::text
         WHEN (derived_table2.days_ago > 90) THEN 'Inactive'::text
         ELSE NULL::text END AS crowdcube_active_user
FROM (SELECT derived_table1.user_key,
             ((SELECT dim_dates.date_key FROM dim_dates WHERE (dim_dates.the_date = ('now'::text)::date)) -
              derived_table1.registered_date_key) AS registered_days_ago,
             ((SELECT dim_dates.date_key FROM dim_dates WHERE (dim_dates.the_date = ('now'::text)::date)) -
              derived_table1.last_session)        AS days_ago
      FROM (SELECT u.user_key,
                   u.registered_date_key,
                   CASE WHEN (ds.last_session IS NULL) THEN -300 ELSE ds.last_session END AS last_session
            FROM (dim_users_static u
                   LEFT JOIN (SELECT au.user_key, "max"(e.request_date_date_key) AS last_session
                              FROM ((fact_engagement e JOIN dim_sessions s ON (((e.session_key)::text = (s.session_key)::text)))
                                     JOIN dim_anon_users_new au ON (((s.anonymousid)::text = (au.anon_id)::text)))
                              WHERE ((s.session_start_date_key <= (SELECT dim_dates.date_key
                                                                   FROM dim_dates
                                                                   WHERE (dim_dates.the_date = ('now'::text)::date))) AND
                                     (au.user_key > 0))
                              GROUP BY au.user_key) ds ON ((u.user_key = ds.user_key)))) derived_table1) derived_table2;

alter table v_metric_crowdcube_active_user
  owner to ccdatawh;

