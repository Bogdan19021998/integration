create view v_list_users as
SELECT pg_user.usename,
       pg_user.usesysid,
       pg_user.usecreatedb,
       pg_user.usesuper,
       pg_user.usecatupd,
       pg_user.passwd,
       pg_user.valuntil,
       pg_user.useconfig
FROM pg_user;

alter table v_list_users
  owner to ccdatawh;

