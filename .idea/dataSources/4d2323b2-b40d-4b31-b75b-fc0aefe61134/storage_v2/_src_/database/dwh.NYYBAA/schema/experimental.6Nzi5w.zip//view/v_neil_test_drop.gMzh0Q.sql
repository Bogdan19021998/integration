create view v_neil_test_drop as
SELECT neil_test_drop.id, neil_test_drop.col1, neil_test_drop.col2
FROM experimental.neil_test_drop;

alter table v_neil_test_drop
  owner to ccdatawh;

