create function f_rfi_score(recency_visit integer, frequency_sessions bigint, intensity_distinct_events bigint, intensity_browse_time_in_last_month bigint) returns character
  stable
  language plpythonu
as
$$
       #-- Rule 1: if there is no visit, return a -
       if(recency_visit is None)                                                        : return '-' 
       
       #-- Rule 2: If the visit is less than 400 days ago (i.e. over a year, consider them F
       if recency_visit < -400                                                          : return 'F'
       
       #-- Rule 3: If the visit last visit was over half a year ago.. Score is either F for low intensity of E for higher intensity
       if recency_visit >= -400 and recency_visit < -180 and intensity_browse_time_in_last_month < 60  : return 'F'
       if recency_visit >= -400 and recency_visit < -180 and intensity_browse_time_in_last_month > 60  : return 'E'
       
       #-- Rule 4: If the visit last visit was over 3 months a year ago.. Score is either E for low intensity of D for higher intensity
       if recency_visit >= -180 and recency_visit < -60 and intensity_browse_time_in_last_month < 60  : return 'E'
       if recency_visit >= -180 and recency_visit < -60 and intensity_browse_time_in_last_month > 60  : return 'D'
       
       
       #-- Rule 5: If the visit last visit was in the past 2 months a year ago.. Score is either E for low intensity of D for higher intensity
       if recency_visit >= -60 and recency_visit < -30 and intensity_browse_time_in_last_month < 60  : return 'D'
       if recency_visit >= -60 and recency_visit < -30 and intensity_browse_time_in_last_month > 60  : return 'C'
       
       #-- Rule 6: If the visit last visit was in the past month a year ago.. Score is either E for low intensity of D for higher intensity
       if recency_visit >= -30 and intensity_browse_time_in_last_month < 10                                                     : return 'C'
       if recency_visit >= -30 and intensity_browse_time_in_last_month >= 10  and intensity_browse_time_in_last_month < 30      : return 'B'
       if recency_visit >= -30 and intensity_browse_time_in_last_month >= 30                                                    : return 'A'
       
       #-- Un-caught condition. This should not occur
       return 'U'
       
$$;

