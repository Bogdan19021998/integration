create view v_master_dates as
SELECT dim_dates.date_key,
       dim_dates.the_date,
       dim_dates."year",
       dim_dates."month",
       dim_dates.month_name,
       dim_dates."day",
       dim_dates.day_of_year,
       dim_dates.day_name,
       dim_dates.calendar_week,
       dim_dates.formatted_date,
       dim_dates.quarter,
       dim_dates.year_quarter,
       dim_dates.year_month,
       dim_dates.year_calendar_week,
       dim_dates.weekend,
       dim_dates.period,
       dim_dates.calendar_week_start,
       dim_dates.calendar_week_end,
       dim_dates.month_start,
       dim_dates.month_end
FROM dim_dates
WHERE ((dim_dates.the_date <= ('now'::text)::date) AND (dim_dates.the_date >= '2015-07-01'::date));

alter table v_master_dates
  owner to ccdatawh;

