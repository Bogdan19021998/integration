create view v_band_ns_sec as
SELECT (upper("replace"(btrim((p.pcd)::text), ' '::text, ''::text)))::character varying(8)             AS pcd,
       ((s.c_1)::double precision / (s.all_categories)::double precision)                              AS perc_higher_managerial,
       ((s.c_2)::double precision / (s.all_categories)::double precision)                              AS perc_lower_managerial,
       ((s.c_3)::double precision / (s.all_categories)::double precision)                              AS perc_intermediate_occupations,
       ((s.c_4)::double precision / (s.all_categories)::double precision)                              AS perc_small_employers,
       ((s.c_5)::double precision / (s.all_categories)::double precision)                              AS perc_lower_supervisory_and_technical_occupations,
       ((s.c_6)::double precision / (s.all_categories)::double precision)                              AS perc_semi_routine_occupations,
       ((s.c_7)::double precision / (s.all_categories)::double precision)                              AS perc_routine_occupations,
       ((s.c_8)::double precision / (s.all_categories)::double precision)                              AS perc_never_worked_lomg_term_unemployed,
       ((s.c_l15)::double precision / (s.all_categories)::double precision)                            AS perc_full_time_student,
       onsdata.f_percent_band(((s.c_1)::double precision / (s.all_categories)::double precision),
                              6)                                                                       AS perc_higher_managerial_band,
       onsdata.f_percent_band(((s.c_2)::double precision / (s.all_categories)::double precision),
                              6)                                                                       AS perc_lower_managerial_band,
       onsdata.f_percent_band(((s.c_3)::double precision / (s.all_categories)::double precision),
                              6)                                                                       AS perc_intermediate_occupations_band,
       onsdata.f_percent_band(((s.c_4)::double precision / (s.all_categories)::double precision),
                              6)                                                                       AS perc_small_employers_band,
       onsdata.f_percent_band(((s.c_5)::double precision / (s.all_categories)::double precision),
                              6)                                                                       AS perc_lower_supervisory_and_technical_occupations_band,
       onsdata.f_percent_band(((s.c_6)::double precision / (s.all_categories)::double precision),
                              6)                                                                       AS perc_semi_routine_occupations_band,
       onsdata.f_percent_band(((s.c_7)::double precision / (s.all_categories)::double precision),
                              6)                                                                       AS perc_routine_occupations_band,
       onsdata.f_percent_band(((s.c_8)::double precision / (s.all_categories)::double precision),
                              6)                                                                       AS perc_never_worked_lomg_term_unemployed_band,
       onsdata.f_percent_band(((s.c_l15)::double precision / (s.all_categories)::double precision),
                              6)                                                                       AS perc_full_time_student_band
FROM (onsdata.onspd p
       LEFT JOIN onsdata.ns_sec s ON (((p.oa11)::text = (s.geography_code)::text)))
WHERE (s.all_categories > 0);

alter table v_band_ns_sec
  owner to ccdatawh;

