create view v_uk_user_opt_status as
SELECT DISTINCT v_master_users_latest.user_key, v_master_users_latest.subscribed_newsletter
FROM v_master_users_latest;

alter table v_uk_user_opt_status
  owner to ccdatawh;

