create view v_time_to_complete_by_pitch as
SELECT x.pitch_key,
       x.pitch_name,
       x.closed_month,
       x.closed_date,
       y.cert_sent_date,
       (y.cert_sent_date_key - x.closed_date_key) AS days_to_complete
FROM ((SELECT ps.pitch_key,
              ps.pitch_name,
              d.year_month AS closed_month,
              d.the_date   AS closed_date,
              d.date_key   AS closed_date_key
       FROM dim_dates d,
            dim_pitches_changing pc,
            dim_pitches_static ps
       WHERE (((((pc.snapshot_date_key = (SELECT dim_dates.date_key
                                          FROM dim_dates
                                          WHERE (dim_dates.the_date = ('now'::character varying)::date))) AND
                 (pc.closed_date_key = d.date_key)) AND (pc.pitch_key = ps.pitch_key)) AND
               ((pc.pitch_status)::text = ('Funded'::character varying)::text)) AND
              ((ps.portal_name)::text = ('crowdcube'::character varying)::text))) x
       LEFT JOIN (SELECT ps.pitch_key, d2.date_key AS cert_sent_date_key, d2.the_date AS cert_sent_date
                  FROM dim_pitches_changing pc,
                       dim_pitches_static ps,
                       dim_dates d2
                  WHERE ((((((pc.snapshot_date_key = (SELECT dim_dates.date_key
                                                      FROM dim_dates
                                                      WHERE (dim_dates.the_date = ('now'::character varying)::date))) AND
                             (pc.pitch_key = ps.pitch_key)) AND
                            ((pc.pitch_status)::text = ('Funded'::character varying)::text)) AND
                           ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND
                          (d2.date_key = ps.certs_sent_date_key)) AND (ps.certs_sent_date_key <> 1))) y
                 ON ((x.pitch_key = y.pitch_key)))
ORDER BY x.closed_date;

alter table v_time_to_complete_by_pitch
  owner to ccdatawh;

