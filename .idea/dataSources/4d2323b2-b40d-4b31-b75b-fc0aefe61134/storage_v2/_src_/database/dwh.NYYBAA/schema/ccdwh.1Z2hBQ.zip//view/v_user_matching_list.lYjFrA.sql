create view v_user_matching_list as
SELECT a.user_key,
       a.username,
       a.email,
       a.firstname,
       a.surname,
       a.mobile,
       a.telephone,
       a.investor_type,
       a.investment_behaviour_type,
       a.portal,
       CASE
         WHEN (b.attempted_equity_investments IS NULL) THEN (0)::bigint
         ELSE b.attempted_equity_investments END                                                                                                      AS attempted_equity_investments,
       CASE
         WHEN (c.attempted_bond_investments IS NULL) THEN (0)::bigint
         ELSE c.attempted_bond_investments END                                                                                                        AS attempted_bond_investments,
       (CASE WHEN (b.attempted_equity_investments IS NULL) THEN (0)::bigint ELSE b.attempted_equity_investments END +
        CASE
          WHEN (c.attempted_bond_investments IS NULL) THEN (0)::bigint
          ELSE c.attempted_bond_investments END)                                                                                                      AS attempted_total_investments,
       CASE
         WHEN (b.attempted_equity_pitches IS NULL) THEN (0)::bigint
         ELSE b.attempted_equity_pitches END                                                                                                          AS attempted_equity_pitches,
       CASE
         WHEN (c.attempted_bond_pitches IS NULL) THEN (0)::bigint
         ELSE c.attempted_bond_pitches END                                                                                                            AS attempted_bond_pitches,
       (CASE WHEN (b.attempted_equity_pitches IS NULL) THEN (0)::bigint ELSE b.attempted_equity_pitches END + CASE
                                                                                                                WHEN (c.attempted_bond_pitches IS NULL)
                                                                                                                  THEN (0)::bigint
                                                                                                                ELSE c.attempted_bond_pitches END)    AS attempted_total_pitches,
       CASE
         WHEN (b.attempted_equity_investment_amount IS NULL) THEN ((0)::numeric)::numeric(18, 0)
         ELSE b.attempted_equity_investment_amount END                                                                                                AS attempted_equity_investment_amount,
       CASE
         WHEN (c.attempted_bond_investment_amount IS NULL) THEN ((0)::numeric)::numeric(18, 0)
         ELSE c.attempted_bond_investment_amount END                                                                                                  AS attempted_bond_investment_amount,
       (CASE
          WHEN (b.attempted_equity_investment_amount IS NULL) THEN ((0)::numeric)::numeric(18, 0)
          ELSE b.attempted_equity_investment_amount END + CASE
                                                            WHEN (c.attempted_bond_investment_amount IS NULL)
                                                              THEN ((0)::numeric)::numeric(18, 0)
                                                            ELSE c.attempted_bond_investment_amount END)                                              AS attempted_total_investment_amount,
       CASE
         WHEN (d.successful_equity_investments IS NULL) THEN (0)::bigint
         ELSE d.successful_equity_investments END                                                                                                     AS successful_equity_investments,
       CASE
         WHEN (e.successful_bond_investments IS NULL) THEN (0)::bigint
         ELSE e.successful_bond_investments END                                                                                                       AS successful_bond_investments,
       (CASE WHEN (d.successful_equity_investments IS NULL) THEN (0)::bigint ELSE d.successful_equity_investments END +
        CASE
          WHEN (e.successful_bond_investments IS NULL) THEN (0)::bigint
          ELSE e.successful_bond_investments END)                                                                                                     AS successful_total_investments,
       CASE
         WHEN (d.successful_equity_pitches IS NULL) THEN (0)::bigint
         ELSE d.successful_equity_pitches END                                                                                                         AS successful_equity_pitches,
       CASE
         WHEN (e.successful_bond_pitches IS NULL) THEN (0)::bigint
         ELSE e.successful_bond_pitches END                                                                                                           AS successful_bond_pitches,
       (CASE WHEN (d.successful_equity_pitches IS NULL) THEN (0)::bigint ELSE d.successful_equity_pitches END + CASE
                                                                                                                  WHEN (e.successful_bond_pitches IS NULL)
                                                                                                                    THEN (0)::bigint
                                                                                                                  ELSE e.successful_bond_pitches END) AS successful_total_pitches,
       CASE
         WHEN (d.successful_equity_investment_amount IS NULL) THEN ((0)::numeric)::numeric(18, 0)
         ELSE d.successful_equity_investment_amount END                                                                                               AS successful_equity_investment_amount,
       CASE
         WHEN (e.successful_bond_investment_amount IS NULL) THEN ((0)::numeric)::numeric(18, 0)
         ELSE e.successful_bond_investment_amount END                                                                                                 AS successful_bond_investment_amount,
       (CASE
          WHEN (d.successful_equity_investment_amount IS NULL) THEN ((0)::numeric)::numeric(18, 0)
          ELSE d.successful_equity_investment_amount END + CASE
                                                             WHEN (e.successful_bond_investment_amount IS NULL)
                                                               THEN ((0)::numeric)::numeric(18, 0)
                                                             ELSE e.successful_bond_investment_amount END)                                            AS successful_total_investment_amount
FROM (((((SELECT us.user_key,
                 us.user_name                       AS username,
                 us.user_email                      AS email,
                 us.user_firstname                  AS firstname,
                 us.user_lastname                   AS surname,
                 us.private_address_post_code       AS postcode,
                 us.gender,
                 us.portal,
                 d1.the_date                        AS registered_date,
                 CASE
                   WHEN (us.birth_date_key = 1) THEN NULL::integer
                   ELSE (((SELECT dim_dates.date_key
                           FROM dim_dates
                           WHERE (dim_dates.the_date = ('now'::character varying)::date)) - us.birth_date_key) /
                         365) END                   AS age,
                 CASE
                   WHEN ((((("left"((us.telephone)::text, 2) = ('07'::character varying)::text) OR
                            ("left"((us.telephone)::text, 4) = ('+447'::character varying)::text)) OR
                           ("left"((us.telephone)::text, 5) = ('+44 7'::character varying)::text)) OR
                          ("left"((us.telephone)::text, 7) = ('+44(0)7'::character varying)::text)) OR
                         ("left"((us.telephone)::text, 5) = ('+44-7'::character varying)::text)) THEN us.telephone
                   ELSE NULL::character varying END AS mobile,
                 CASE
                   WHEN ((((("left"((us.telephone)::text, 2) <> ('07'::character varying)::text) AND
                            ("left"((us.telephone)::text, 4) <> ('+447'::character varying)::text)) AND
                           ("left"((us.telephone)::text, 5) <> ('+44 7'::character varying)::text)) AND
                          ("left"((us.telephone)::text, 7) <> ('+44(0)7'::character varying)::text)) AND
                         ("left"((us.telephone)::text, 5) <> ('+44-7'::character varying)::text)) THEN us.telephone
                   ELSE NULL::character varying END AS telephone,
                 uc.subscribed_newsletter           AS opted_in,
                 uc.user_category                   AS investor_type,
                 uc.investor_type_classification    AS investment_behaviour_type
          FROM dim_users_static us,
               dim_dates d1,
               dim_users_changing uc
          WHERE (((us.registered_date_key = d1.date_key) AND (us.user_key = uc.user_key)) AND (uc.snapshot_date_key =
                                                                                               (SELECT dim_dates.date_key
                                                                                                FROM dim_dates
                                                                                                WHERE (dim_dates.the_date = ('now'::character varying)::date))))) a LEFT JOIN (SELECT pi.user_key,
                                                                                                                                                                                      count(pi.user_key)           AS attempted_equity_investments,
                                                                                                                                                                                      count(DISTINCT pi.pitch_key) AS attempted_equity_pitches,
                                                                                                                                                                                      sum(pi.amount)               AS attempted_equity_investment_amount
                                                                                                                                                                               FROM dim_users_static us,
                                                                                                                                                                                    dim_dates d,
                                                                                                                                                                                    fact_pitch_investments pi,
                                                                                                                                                                                    dim_pitches_static ps,
                                                                                                                                                                                    dim_pitches_changing pc
                                                                                                                                                                               WHERE ((((((pi.pitch_key = ps.pitch_key) AND (pi.pitch_key = pc.pitch_key)) AND
                                                                                                                                                                                         (pc.snapshot_date_key =
                                                                                                                                                                                          (SELECT dim_dates.date_key
                                                                                                                                                                                           FROM dim_dates
                                                                                                                                                                                           WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
                                                                                                                                                                                        ((ps.product_type)::text = ('Equity'::character varying)::text)) AND
                                                                                                                                                                                       (pi.user_key = us.user_key)) AND
                                                                                                                                                                                      (pi.investment_date_key = d.date_key))
                                                                                                                                                                               GROUP BY pi.user_key) b ON ((a.user_key = b.user_key))) LEFT JOIN (SELECT pi.user_key,
                                                                                                                                                                                                                                                         count(pi.user_key)           AS attempted_bond_investments,
                                                                                                                                                                                                                                                         count(DISTINCT pi.pitch_key) AS attempted_bond_pitches,
                                                                                                                                                                                                                                                         sum(pi.amount)               AS attempted_bond_investment_amount
                                                                                                                                                                                                                                                  FROM dim_users_static us,
                                                                                                                                                                                                                                                       dim_dates d,
                                                                                                                                                                                                                                                       fact_pitch_investments pi,
                                                                                                                                                                                                                                                       dim_pitches_static ps,
                                                                                                                                                                                                                                                       dim_pitches_changing pc
                                                                                                                                                                                                                                                  WHERE ((((((pi.pitch_key = ps.pitch_key) AND (pi.pitch_key = pc.pitch_key)) AND
                                                                                                                                                                                                                                                            (pc.snapshot_date_key =
                                                                                                                                                                                                                                                             (SELECT dim_dates.date_key
                                                                                                                                                                                                                                                              FROM dim_dates
                                                                                                                                                                                                                                                              WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
                                                                                                                                                                                                                                                           ((ps.product_type)::text = ('Bonds'::character varying)::text)) AND
                                                                                                                                                                                                                                                          (pi.user_key = us.user_key)) AND
                                                                                                                                                                                                                                                         (pi.investment_date_key = d.date_key))
                                                                                                                                                                                                                                                  GROUP BY pi.user_key) c ON ((a.user_key = c.user_key))) LEFT JOIN (SELECT pi.user_key,
                                                                                                                                                                                                                                                                                                                            count(pi.user_key)           AS successful_equity_investments,
                                                                                                                                                                                                                                                                                                                            count(DISTINCT pi.pitch_key) AS successful_equity_pitches,
                                                                                                                                                                                                                                                                                                                            sum(pi.amount)               AS successful_equity_investment_amount
                                                                                                                                                                                                                                                                                                                     FROM dim_users_static us,
                                                                                                                                                                                                                                                                                                                          dim_dates d,
                                                                                                                                                                                                                                                                                                                          fact_pitch_investments pi,
                                                                                                                                                                                                                                                                                                                          dim_pitches_static ps,
                                                                                                                                                                                                                                                                                                                          dim_pitches_changing pc
                                                                                                                                                                                                                                                                                                                     WHERE ((((((((pi.pitch_key = ps.pitch_key) AND (pi.pitch_key = pc.pitch_key)) AND
                                                                                                                                                                                                                                                                                                                                 (pc.snapshot_date_key =
                                                                                                                                                                                                                                                                                                                                  (SELECT dim_dates.date_key
                                                                                                                                                                                                                                                                                                                                   FROM dim_dates
                                                                                                                                                                                                                                                                                                                                   WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
                                                                                                                                                                                                                                                                                                                                ((ps.product_type)::text = ('Equity'::character varying)::text)) AND
                                                                                                                                                                                                                                                                                                                               (pi.user_key = us.user_key)) AND
                                                                                                                                                                                                                                                                                                                              (pi.investment_date_key = d.date_key)) AND
                                                                                                                                                                                                                                                                                                                             ((pi.investment_status)::text <>
                                                                                                                                                                                                                                                                                                                              ('cancelled'::character varying)::text)) AND
                                                                                                                                                                                                                                                                                                                            ((pc.pitch_status)::text = ('Funded'::character varying)::text))
                                                                                                                                                                                                                                                                                                                     GROUP BY pi.user_key) d ON ((a.user_key = d.user_key)))
       LEFT JOIN (SELECT pi.user_key,
                         count(pi.user_key)           AS successful_bond_investments,
                         count(DISTINCT pi.pitch_key) AS successful_bond_pitches,
                         sum(pi.amount)               AS successful_bond_investment_amount
                  FROM dim_users_static us,
                       dim_dates d,
                       fact_pitch_investments pi,
                       dim_pitches_static ps,
                       dim_pitches_changing pc
                  WHERE ((((((((pi.pitch_key = ps.pitch_key) AND (pi.pitch_key = pc.pitch_key)) AND
                              (pc.snapshot_date_key = (SELECT dim_dates.date_key
                                                       FROM dim_dates
                                                       WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
                             ((ps.product_type)::text = ('Bonds'::character varying)::text)) AND
                            (pi.user_key = us.user_key)) AND (pi.investment_date_key = d.date_key)) AND
                          ((pi.investment_status)::text <> ('cancelled'::character varying)::text)) AND
                         ((pc.pitch_status)::text = ('Funded'::character varying)::text))
                  GROUP BY pi.user_key) e ON ((a.user_key = e.user_key)));

alter table v_user_matching_list
  owner to ccdatawh;

