create function f_rfim_score(recency_count integer, frequency integer, intensity_distinct_events integer, intensity_browse_time_in_last_month integer, intensity_monetary numeric) returns character
  stable
  language plpythonu
as
$$
        return 'B'
$$;

