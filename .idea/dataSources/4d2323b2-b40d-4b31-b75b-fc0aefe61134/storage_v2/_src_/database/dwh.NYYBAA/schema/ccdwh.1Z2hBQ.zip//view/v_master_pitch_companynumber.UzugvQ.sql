create view v_master_pitch_companynumber as
SELECT p.pitch_key,
       CASE
         WHEN (btrim((COALESCE(comp.company_reg_number_c, ''::character varying))::text) <> ''::text)
           THEN comp.company_reg_number_c
         WHEN (btrim((COALESCE(cs.registered_company_number, ''::character varying))::text) <> ''::text) THEN CASE
                                                                                                                WHEN (
                                                                                                                    ((cs.registered_company_number)::text = 'Unknown'::text) AND
                                                                                                                    (btrim((COALESCE(p.company_number, ''::character varying))::text) <>
                                                                                                                     ''::text))
                                                                                                                  THEN p.company_number
                                                                                                                WHEN ((cs.registered_company_number)::text = 'Unknown'::text)
                                                                                                                  THEN NULL::character varying
                                                                                                                ELSE cs.registered_company_number END
         WHEN (btrim((COALESCE(p.company_number, ''::character varying))::text) <> ''::text) THEN p.company_number
         ELSE NULL::character varying END AS company_number
FROM ((((dim_pitches_static p LEFT JOIN dim_companies_static cs ON ((cs.company_key = p.company_key))) LEFT JOIN v_salesforce_opportunity_pitch_relation opp_pitch ON ((opp_pitch.pitch_key = p.pitch_key))) LEFT JOIN sfexperimental.opportunities opps ON (((opps.x18_digit_id_c)::text = (opp_pitch.opportunity_id)::text)))
       LEFT JOIN sfexperimental.companies comp ON (((comp.x18_digit_id_c)::text = (opps.account_18_id_c)::text)));

alter table v_master_pitch_companynumber
  owner to ccdatawh;

