create view element_types as
SELECT (current_database())::information_schema.sql_identifier                        AS object_catalog,
       (n.nspname)::information_schema.sql_identifier                                 AS object_schema,
       (x.objname)::information_schema.sql_identifier                                 AS object_name,
       (x.objtype)::information_schema.character_data                                 AS object_type,
       (x.objdtdid)::information_schema.sql_identifier                                AS array_type_identifier,
       (CASE
          WHEN (nbt.nspname = 'pg_catalog'::name) THEN format_type(bt.oid, NULL::integer)
          ELSE 'USER-DEFINED'::text END)::information_schema.character_data           AS data_type,
       (NULL::information_schema.cardinal_number)::information_schema.cardinal_number AS character_maximum_length,
       (NULL::information_schema.cardinal_number)::information_schema.cardinal_number AS character_octet_length,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier   AS character_set_catalog,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier   AS character_set_schema,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier   AS character_set_name,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier   AS collation_catalog,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier   AS collation_schema,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier   AS collation_name,
       (NULL::information_schema.cardinal_number)::information_schema.cardinal_number AS numeric_precision,
       (NULL::information_schema.cardinal_number)::information_schema.cardinal_number AS numeric_precision_radix,
       (NULL::information_schema.cardinal_number)::information_schema.cardinal_number AS numeric_scale,
       (NULL::information_schema.cardinal_number)::information_schema.cardinal_number AS datetime_precision,
       (NULL::information_schema.character_data)::information_schema.character_data   AS interval_type,
       (NULL::information_schema.character_data)::information_schema.character_data   AS interval_precision,
       (NULL::information_schema.character_data)::information_schema.character_data   AS domain_default,
       (current_database())::information_schema.sql_identifier                        AS udt_catalog,
       (nbt.nspname)::information_schema.sql_identifier                               AS udt_schema,
       (bt.typname)::information_schema.sql_identifier                                AS udt_name,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier   AS scope_catalog,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier   AS scope_schema,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier   AS scope_name,
       (NULL::information_schema.cardinal_number)::information_schema.cardinal_number AS maximum_cardinality,
       (('a'::text || (x.objdtdid)::text))::information_schema.sql_identifier         AS dtd_identifier
FROM pg_namespace n,
     pg_type "at",
     pg_namespace nbt,
     pg_type bt,
     (((SELECT c.relnamespace,
               (c.relname)::information_schema.sql_identifier AS relname,
               'TABLE'::character varying                     AS "varchar",
               a.attnum,
               a.atttypid
        FROM pg_class c,
             pg_attribute a
        WHERE ((((c.oid = a.attrelid) AND ((c.relkind = 'r'::"char") OR (c.relkind = 'v'::"char"))) AND
                (a.attnum > 0)) AND (NOT a.attisdropped))
        UNION ALL
        SELECT t.typnamespace,
               (t.typname)::information_schema.sql_identifier AS typname,
               'DOMAIN'::character varying                    AS "varchar",
               1,
               t.typbasetype
        FROM pg_type t
        WHERE (t.typtype = 'd'::"char"))
       UNION ALL
       SELECT p.pronamespace,
              ((((p.proname)::text || '_'::text) ||
                ((p.oid)::character varying)::text))::information_schema.sql_identifier AS sql_identifier,
              'ROUTINE'::character varying                                              AS "varchar",
              pos.n,
              p.proargtypes [ (pos.n - 1)]                                              AS proargtypes
       FROM pg_proc p,
            information_schema._pg_keypositions() pos(n)
       WHERE (p.pronargs >= pos.n))
      UNION ALL
      SELECT p.pronamespace,
             ((((p.proname)::text || '_'::text) ||
               ((p.oid)::character varying)::text))::information_schema.sql_identifier AS sql_identifier,
             'ROUTINE'::character varying                                              AS "varchar",
             0,
             p.prorettype
      FROM pg_proc p) x(objschema, objname, objtype, objdtdid, objtypeid)
WHERE ((((((n.oid = x.objschema) AND ("at".oid = x.objtypeid)) AND
          (("at".typelem <> (0)::oid) AND ("at".typlen = -1))) AND ("at".typelem = bt.oid)) AND
        (nbt.oid = bt.typnamespace)) AND
       (((n.nspname)::information_schema.sql_identifier, (x.objname)::information_schema.sql_identifier,
         (x.objtype)::information_schema.character_data, (x.objdtdid)::information_schema.sql_identifier) IN
        (SELECT data_type_privileges.object_schema,
                data_type_privileges.object_name,
                data_type_privileges.object_type,
                data_type_privileges.dtd_identifier
         FROM information_schema.data_type_privileges)));

alter table element_types
  owner to rdsdb;

