create view v_metric_number_selligent_active_users as
SELECT dt.the_date, count(DISTINCT uc.user_key) AS count_selligent_active_users
FROM ((dim_users_changing uc JOIN dim_users_static us ON ((uc.user_key = us.user_key)))
       JOIN dim_dates dt ON ((uc.snapshot_date_key = dt.date_key)))
WHERE (((uc.selligent_active_user)::text = 'Active'::text) AND ((us.portal)::text = 'crowdcube'::text))
GROUP BY dt.the_date
ORDER BY dt.the_date;

alter table v_metric_number_selligent_active_users
  owner to ccdatawh;

