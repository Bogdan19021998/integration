create view v_distil_investor_entity_chronotype_classifications as
SELECT ds.user_key,
       CASE
         WHEN ((((ds.c0 = ds.c1) AND (ds.c0 = ds.c2)) AND (ds.c0 = ds.c3)) AND (ds.c0 = ds.c4)) THEN 'Unknown'::text
         WHEN ((((ds.c0 > ds.c1) AND (ds.c0 > ds.c2)) AND (ds.c0 > ds.c3)) AND (ds.c0 > ds.c4)) THEN 'Night-Owl'::text
         WHEN ((((ds.c1 > ds.c0) AND (ds.c1 > ds.c2)) AND (ds.c1 > ds.c3)) AND (ds.c1 > ds.c4)) THEN 'Early-Bird'::text
         WHEN ((((ds.c2 > ds.c0) AND (ds.c2 > ds.c1)) AND (ds.c2 > ds.c3)) AND (ds.c2 > ds.c4)) THEN 'Lunch-Timer'::text
         WHEN ((((ds.c3 > ds.c0) AND (ds.c3 > ds.c1)) AND (ds.c3 > ds.c2)) AND (ds.c3 > ds.c4)) THEN 'Afternoon'::text
         WHEN ((((ds.c4 > ds.c0) AND (ds.c4 > ds.c1)) AND (ds.c4 > ds.c2)) AND (ds.c4 > ds.c3)) THEN 'Evening'::text
         ELSE 'blah'::text END AS chronotype
FROM (SELECT u.user_key,
             CASE WHEN (ct_0.count_0 IS NULL) THEN (0)::bigint ELSE ct_0.count_0 END AS c0,
             CASE WHEN (ct_1.count_1 IS NULL) THEN (0)::bigint ELSE ct_1.count_1 END AS c1,
             CASE WHEN (ct_2.count_2 IS NULL) THEN (0)::bigint ELSE ct_2.count_2 END AS c2,
             CASE WHEN (ct_3.count_3 IS NULL) THEN (0)::bigint ELSE ct_3.count_3 END AS c3,
             CASE WHEN (ct_4.count_4 IS NULL) THEN (0)::bigint ELSE ct_4.count_4 END AS c4
      FROM (((((dim_users_static u LEFT JOIN (SELECT fact_engagement.user_key, count(*) AS count_0
                                              FROM fast.fact_engagement
                                              WHERE (((fact_engagement.user_key IS NOT NULL) AND
                                                      (fact_engagement.user_key <> -1)) AND
                                                     (("date_part"('hour'::text, fact_engagement.event_timestamp) >= 0) AND
                                                      ("date_part"('hour'::text, fact_engagement.event_timestamp) <= 5)))
                                              GROUP BY fact_engagement.user_key) ct_0 ON ((u.user_key = ct_0.user_key))) LEFT JOIN (SELECT fact_engagement.user_key, count(*) AS count_1
                                                                                                                                    FROM fast.fact_engagement
                                                                                                                                    WHERE (((fact_engagement.user_key IS NOT NULL) AND
                                                                                                                                            (fact_engagement.user_key <> -1)) AND
                                                                                                                                           (("date_part"('hour'::text, fact_engagement.event_timestamp) >= 6) AND
                                                                                                                                            ("date_part"('hour'::text, fact_engagement.event_timestamp) <= 10)))
                                                                                                                                    GROUP BY fact_engagement.user_key) ct_1 ON ((u.user_key = ct_1.user_key))) LEFT JOIN (SELECT fact_engagement.user_key, count(*) AS count_2
                                                                                                                                                                                                                          FROM fast.fact_engagement
                                                                                                                                                                                                                          WHERE (((fact_engagement.user_key IS NOT NULL) AND
                                                                                                                                                                                                                                  (fact_engagement.user_key <> -1)) AND
                                                                                                                                                                                                                                 (("date_part"('hour'::text, fact_engagement.event_timestamp) >= 11) AND
                                                                                                                                                                                                                                  ("date_part"('hour'::text, fact_engagement.event_timestamp) <= 14)))
                                                                                                                                                                                                                          GROUP BY fact_engagement.user_key) ct_2 ON ((u.user_key = ct_2.user_key))) LEFT JOIN (SELECT fact_engagement.user_key, count(*) AS count_3
                                                                                                                                                                                                                                                                                                                FROM fast.fact_engagement
                                                                                                                                                                                                                                                                                                                WHERE (((fact_engagement.user_key IS NOT NULL) AND
                                                                                                                                                                                                                                                                                                                        (fact_engagement.user_key <> -1)) AND
                                                                                                                                                                                                                                                                                                                       (("date_part"('hour'::text, fact_engagement.event_timestamp) >= 15) AND
                                                                                                                                                                                                                                                                                                                        ("date_part"('hour'::text, fact_engagement.event_timestamp) <= 18)))
                                                                                                                                                                                                                                                                                                                GROUP BY fact_engagement.user_key) ct_3 ON ((u.user_key = ct_3.user_key)))
             LEFT JOIN (SELECT fact_engagement.user_key, count(*) AS count_4
                        FROM fast.fact_engagement
                        WHERE (((fact_engagement.user_key IS NOT NULL) AND (fact_engagement.user_key <> -1)) AND
                               (("date_part"('hour'::text, fact_engagement.event_timestamp) >= 19) AND
                                ("date_part"('hour'::text, fact_engagement.event_timestamp) <= 23)))
                        GROUP BY fact_engagement.user_key) ct_4 ON ((u.user_key = ct_4.user_key)))) ds;

alter table v_distil_investor_entity_chronotype_classifications
  owner to ccdatawh;

