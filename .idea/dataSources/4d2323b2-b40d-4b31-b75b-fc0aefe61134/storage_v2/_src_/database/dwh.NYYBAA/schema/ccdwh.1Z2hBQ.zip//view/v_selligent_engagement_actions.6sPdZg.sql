create view v_selligent_engagement_actions as
SELECT dc.the_date,
       dc.campaign_name                                                                AS selligent_campaign,
       dc.user_group,
       dc.user_key,
       CASE WHEN (o.opens IS NULL) THEN (0)::bigint ELSE o.opens END                   AS opens,
       CASE WHEN (c.clicks IS NULL) THEN (0)::bigint ELSE c.clicks END                 AS clicks,
       CASE WHEN (w.view_web IS NULL) THEN (0)::bigint ELSE w.view_web END             AS view_web,
       CASE WHEN (s.send IS NULL) THEN (0)::bigint ELSE s.send END                     AS send,
       CASE WHEN (u.unknown_action IS NULL) THEN (0)::bigint ELSE u.unknown_action END AS unknown_action
FROM ((((((SELECT DISTINCT (v_selligent_report_actions.action_date)::date AS the_date,
                           v_selligent_report_actions.campaign_name,
                           CASE
                             WHEN (mod(v_selligent_report_actions.user_key, 2) = 0) THEN 'Group B'::text
                             WHEN (mod(v_selligent_report_actions.user_key, 2) = 1) THEN 'Group A'::text
                             ELSE 'Unknown'::text END                     AS user_group,
                           v_selligent_report_actions.user_key
           FROM v_selligent_report_actions) dc LEFT JOIN (SELECT derived_table1.the_date,
                                                                 derived_table1.campaign_name,
                                                                 derived_table1.user_group,
                                                                 derived_table1.user_key,
                                                                 count(*) AS opens
                                                          FROM (SELECT (v_selligent_report_actions.action_date)::date AS the_date,
                                                                       v_selligent_report_actions.campaign_name,
                                                                       v_selligent_report_actions."action",
                                                                       CASE
                                                                         WHEN (mod(v_selligent_report_actions.user_key, 2) = 0)
                                                                           THEN 'Group B'::text
                                                                         WHEN (mod(v_selligent_report_actions.user_key, 2) = 1)
                                                                           THEN 'Group A'::text
                                                                         ELSE 'Unknown'::text END                     AS user_group,
                                                                       v_selligent_report_actions.user_key
                                                                FROM v_selligent_report_actions
                                                                WHERE (v_selligent_report_actions."action" = 'Open'::text)) derived_table1
                                                          GROUP BY derived_table1.the_date,
                                                                   derived_table1.campaign_name,
                                                                   derived_table1.user_group, derived_table1.user_key
                                                          ORDER BY derived_table1.the_date,
                                                                   derived_table1.campaign_name,
                                                                   derived_table1.user_group,
                                                                   derived_table1.user_key) o ON ((
    (((dc.the_date = o.the_date) AND ((dc.campaign_name)::text = (o.campaign_name)::text)) AND
     (dc.user_group = o.user_group)) AND (dc.user_key = o.user_key)))) LEFT JOIN (SELECT derived_table2.the_date,
                                                                                         derived_table2.campaign_name,
                                                                                         derived_table2.user_group,
                                                                                         derived_table2.user_key,
                                                                                         count(*) AS clicks
                                                                                  FROM (SELECT (v_selligent_report_actions.action_date)::date AS the_date,
                                                                                               v_selligent_report_actions.campaign_name,
                                                                                               v_selligent_report_actions."action",
                                                                                               CASE
                                                                                                 WHEN (mod(v_selligent_report_actions.user_key, 2) = 0)
                                                                                                   THEN 'Group B'::text
                                                                                                 WHEN (mod(v_selligent_report_actions.user_key, 2) = 1)
                                                                                                   THEN 'Group A'::text
                                                                                                 ELSE 'Unknown'::text END                     AS user_group,
                                                                                               v_selligent_report_actions.user_key
                                                                                        FROM v_selligent_report_actions
                                                                                        WHERE (v_selligent_report_actions."action" = 'Click'::text)) derived_table2
                                                                                  GROUP BY derived_table2.the_date,
                                                                                           derived_table2.campaign_name,
                                                                                           derived_table2.user_group,
                                                                                           derived_table2.user_key
                                                                                  ORDER BY derived_table2.the_date,
                                                                                           derived_table2.campaign_name,
                                                                                           derived_table2.user_group,
                                                                                           derived_table2.user_key) c ON ((
    (((dc.the_date = c.the_date) AND ((dc.campaign_name)::text = (c.campaign_name)::text)) AND
     (dc.user_group = c.user_group)) AND (dc.user_key = c.user_key)))) LEFT JOIN (SELECT derived_table3.the_date,
                                                                                         derived_table3.campaign_name,
                                                                                         derived_table3.user_group,
                                                                                         derived_table3.user_key,
                                                                                         count(*) AS view_web
                                                                                  FROM (SELECT (v_selligent_report_actions.action_date)::date AS the_date,
                                                                                               v_selligent_report_actions.campaign_name,
                                                                                               v_selligent_report_actions."action",
                                                                                               CASE
                                                                                                 WHEN (mod(v_selligent_report_actions.user_key, 2) = 0)
                                                                                                   THEN 'Group B'::text
                                                                                                 WHEN (mod(v_selligent_report_actions.user_key, 2) = 1)
                                                                                                   THEN 'Group A'::text
                                                                                                 ELSE 'Unknown'::text END                     AS user_group,
                                                                                               v_selligent_report_actions.user_key
                                                                                        FROM v_selligent_report_actions
                                                                                        WHERE (v_selligent_report_actions."action" = 'View Web Version'::text)) derived_table3
                                                                                  GROUP BY derived_table3.the_date,
                                                                                           derived_table3.campaign_name,
                                                                                           derived_table3.user_group,
                                                                                           derived_table3.user_key
                                                                                  ORDER BY derived_table3.the_date,
                                                                                           derived_table3.campaign_name,
                                                                                           derived_table3.user_group,
                                                                                           derived_table3.user_key) w ON ((
    (((dc.the_date = w.the_date) AND ((dc.campaign_name)::text = (w.campaign_name)::text)) AND
     (dc.user_group = w.user_group)) AND (dc.user_key = w.user_key)))) LEFT JOIN (SELECT derived_table4.the_date,
                                                                                         derived_table4.campaign_name,
                                                                                         derived_table4.user_group,
                                                                                         derived_table4.user_key,
                                                                                         count(*) AS send
                                                                                  FROM (SELECT (v_selligent_report_actions.action_date)::date AS the_date,
                                                                                               v_selligent_report_actions.campaign_name,
                                                                                               v_selligent_report_actions."action",
                                                                                               CASE
                                                                                                 WHEN (mod(v_selligent_report_actions.user_key, 2) = 0)
                                                                                                   THEN 'Group B'::text
                                                                                                 WHEN (mod(v_selligent_report_actions.user_key, 2) = 1)
                                                                                                   THEN 'Group A'::text
                                                                                                 ELSE 'Unknown'::text END                     AS user_group,
                                                                                               v_selligent_report_actions.user_key
                                                                                        FROM v_selligent_report_actions
                                                                                        WHERE (v_selligent_report_actions."action" = 'Send'::text)) derived_table4
                                                                                  GROUP BY derived_table4.the_date,
                                                                                           derived_table4.campaign_name,
                                                                                           derived_table4.user_group,
                                                                                           derived_table4.user_key
                                                                                  ORDER BY derived_table4.the_date,
                                                                                           derived_table4.campaign_name,
                                                                                           derived_table4.user_group,
                                                                                           derived_table4.user_key) s ON ((
    (((dc.the_date = s.the_date) AND ((dc.campaign_name)::text = (s.campaign_name)::text)) AND
     (dc.user_group = s.user_group)) AND (dc.user_key = s.user_key))))
       LEFT JOIN (SELECT derived_table5.the_date,
                         derived_table5.campaign_name,
                         derived_table5.user_group,
                         derived_table5.user_key,
                         count(*) AS unknown_action
                  FROM (SELECT (v_selligent_report_actions.action_date)::date AS the_date,
                               v_selligent_report_actions.campaign_name,
                               'Unknown'::character varying,
                               CASE
                                 WHEN (mod(v_selligent_report_actions.user_key, 2) = 0) THEN 'Group B'::text
                                 WHEN (mod(v_selligent_report_actions.user_key, 2) = 1) THEN 'Group A'::text
                                 ELSE 'Unknown'::text END                     AS user_group,
                               v_selligent_report_actions.user_key
                        FROM v_selligent_report_actions
                        WHERE (v_selligent_report_actions."action" IS NULL)) derived_table5
                  GROUP BY derived_table5.the_date, derived_table5.campaign_name, derived_table5.user_group,
                           derived_table5.user_key
                  ORDER BY derived_table5.the_date, derived_table5.campaign_name, derived_table5.user_group,
                           derived_table5.user_key) u
                 ON (((dc.the_date = u.the_date) AND ((dc.campaign_name)::text = (u.campaign_name)::text))))
WHERE ((dc.the_date > '2016-08-01'::date) AND (dc.the_date <= ('now'::text)::date))
ORDER BY dc.the_date, dc.campaign_name, dc.user_group, dc.user_key;

alter table v_selligent_engagement_actions
  owner to ccdatawh;

