create view v_distil_products as
SELECT DISTINCT ps.pitch_key                                                                                                                        AS product_id,
                "first_value"((ps.pitch_name)::text)
                              OVER ( PARTITION BY ps.pitch_key ORDER BY pc.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS product_name,
                "first_value"((ps.desciption)::text)
                              OVER ( PARTITION BY ps.pitch_key ORDER BY pc.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS product_precis,
                "first_value"((ps.pitch_logourl)::text)
                              OVER ( PARTITION BY ps.pitch_key ORDER BY pc.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS product_thumbnail_url,
                "first_value"((ps.pitch_coverurl)::text)
                              OVER ( PARTITION BY ps.pitch_key ORDER BY pc.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS product_full_image_url,
                "first_value"((ps.pitch_url)::text)
                              OVER ( PARTITION BY ps.pitch_key ORDER BY pc.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS product_url,
                CASE
                  WHEN ("first_value"((pc.pitch_status)::text)
                                      OVER ( PARTITION BY ps.pitch_key ORDER BY pc.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) =
                        'Approved'::text) THEN true
                  ELSE false END                                                                                                                    AS available,
                0.0                                                                                                                                 AS list_price_excluding_tax,
                0.0                                                                                                                                 AS list_price_including_tax,
                NULL::text                                                                                                                          AS price_breaks_description,
                "first_value"((ps.product_type)::text)
                              OVER ( PARTITION BY ps.pitch_key ORDER BY pc.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS product_type,
                "first_value"((ps.company_name)::text)
                              OVER ( PARTITION BY ps.pitch_key ORDER BY pc.snapshot_date_key DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS company_name
FROM (dim_pitches_static ps
       LEFT JOIN dim_pitches_changing pc ON ((ps.pitch_key = pc.pitch_key)));

alter table v_distil_products
  owner to ccdatawh;

