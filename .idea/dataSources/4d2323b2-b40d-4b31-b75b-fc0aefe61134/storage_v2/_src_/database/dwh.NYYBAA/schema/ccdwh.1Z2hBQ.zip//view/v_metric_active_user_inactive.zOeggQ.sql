create view v_metric_active_user_inactive as
SELECT dt.the_date, count(*) AS cc_active_user_status_inactive
FROM ((dim_users_changing uc JOIN dim_dates dt ON ((uc.snapshot_date_key = dt.date_key)))
       JOIN dim_users_static us ON ((us.user_key = uc.user_key)))
WHERE (((uc.crowdcube_active_user)::text = 'Inactive'::text) AND ((us.portal)::text = 'crowdcube'::text))
GROUP BY dt.the_date
ORDER BY dt.the_date DESC;

alter table v_metric_active_user_inactive
  owner to ccdatawh;

