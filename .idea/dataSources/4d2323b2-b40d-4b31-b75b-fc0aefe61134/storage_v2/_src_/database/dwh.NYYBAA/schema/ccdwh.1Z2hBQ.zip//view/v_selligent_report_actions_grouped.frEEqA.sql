create view v_selligent_report_actions_grouped as
SELECT (v_selligent_report_actions.action_date)::date AS the_date,
       v_selligent_report_actions.campaign_name,
       v_selligent_report_actions."action",
       CASE
         WHEN (mod(v_selligent_report_actions.user_key, 2) = 0) THEN 'Group B'::text
         WHEN (mod(v_selligent_report_actions.user_key, 2) = 1) THEN 'Group A'::text
         ELSE NULL::text END                          AS user_group
FROM v_selligent_report_actions;

alter table v_selligent_report_actions_grouped
  owner to ccdatawh;

