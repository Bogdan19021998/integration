create view v_get_obj_priv_by_user as
SELECT derived_table1.schemaname,
       derived_table1.objectname,
       derived_table1.usename,
       derived_table1.sel,
       derived_table1.ins,
       derived_table1.upd,
       derived_table1.del,
       derived_table1.ref
FROM (SELECT objs.schemaname,
             objs.objectname,
             usrs.usename,
             has_table_privilege(usrs.usename, (objs.fullobj)::text, 'select'::text)     AS sel,
             has_table_privilege(usrs.usename, (objs.fullobj)::text, 'insert'::text)     AS ins,
             has_table_privilege(usrs.usename, (objs.fullobj)::text, 'update'::text)     AS upd,
             has_table_privilege(usrs.usename, (objs.fullobj)::text, 'delete'::text)     AS del,
             has_table_privilege(usrs.usename, (objs.fullobj)::text, 'references'::text) AS ref
      FROM (SELECT pg_tables.schemaname,
                   't'::character varying                                          AS obj_type,
                   pg_tables.tablename                                             AS objectname,
                   (((quote_ident((pg_tables.schemaname)::text) || '.'::text) ||
                     quote_ident((pg_tables.tablename)::text)))::character varying AS fullobj
            FROM pg_tables
            WHERE (pg_tables.schemaname <> 'pg_internal'::name)
            UNION
            SELECT pg_views.schemaname,
                   'v'::character varying                                        AS obj_type,
                   pg_views.viewname                                             AS objectname,
                   (((quote_ident((pg_views.schemaname)::text) || '.'::text) ||
                     quote_ident((pg_views.viewname)::text)))::character varying AS fullobj
            FROM pg_views
            WHERE (pg_views.schemaname <> 'pg_internal'::name)) objs,
           (SELECT pg_user.usename,
                   pg_user.usesysid,
                   pg_user.usecreatedb,
                   pg_user.usesuper,
                   pg_user.usecatupd,
                   pg_user.passwd,
                   pg_user.valuntil,
                   pg_user.useconfig
            FROM pg_user) usrs
      ORDER BY objs.fullobj) derived_table1
WHERE (((((derived_table1.sel = true) OR (derived_table1.ins = true)) OR (derived_table1.upd = true)) OR
        (derived_table1.del = true)) OR (derived_table1.ref = true));

alter table v_get_obj_priv_by_user
  owner to neil_stoneman;

