create view v_cluster_source as
SELECT ds."winner cluster" AS winner_cluster, ds.source, count(ds.session_key) AS num_sessions
FROM (SELECT ng.user_key, ng."winner cluster", cha.session_key, cha.channel, cha.source
      FROM (ccseg.tbl_user_cluster_assignments_non_geospatial ng
             LEFT JOIN (SELECT sa.session_key, sa.anonymousid, "max"(sa.user_key) AS user_key, sa.channel, sa.source
                        FROM experimental.dim_session_attribution sa
                        GROUP BY sa.session_key, sa.anonymousid, sa.channel, sa.source) cha
                       ON ((ng.user_key = cha.user_key)))) ds
GROUP BY ds."winner cluster", ds.source
ORDER BY ds."winner cluster", count(ds.session_key) DESC;

alter table v_cluster_source
  owner to ccdatawh;

