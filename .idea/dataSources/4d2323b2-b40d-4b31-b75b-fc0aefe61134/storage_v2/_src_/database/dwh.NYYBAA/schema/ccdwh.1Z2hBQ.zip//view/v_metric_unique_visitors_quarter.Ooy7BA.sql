create view v_metric_unique_visitors_quarter as
SELECT dt.year_quarter, count(DISTINCT s.anonymousid) AS num_unique_visitors
FROM (dim_sessions s
       JOIN dim_dates dt ON ((s.session_start_date_key = dt.date_key)))
WHERE ((dt.the_date < (('now'::text)::date + 1)) AND ((dt.year_quarter)::text >= '2015/Q2'::text))
GROUP BY dt.year_quarter
ORDER BY dt.year_quarter DESC;

alter table v_metric_unique_visitors_quarter
  owner to ccdatawh;

