create view v_time_fund_and_close_by_created_month as
SELECT a.created_month,
       count(*)                             AS num_funded_pitches_created_in_month,
       count(a.days_from_created_to_closed) AS num_closed_pitches_created_in_month,
       avg(a.days_from_created_to_funded)   AS avg_days_from_created_to_funded,
       avg(a.days_from_funded_to_closed)    AS avg_days_from_funded_to_closed,
       avg(a.days_from_created_to_closed)   AS avg_days_from_created_to_closed,
       avg(a.days_from_first_inv_to_funded) AS avg_days_from_first_inv_to_funded,
       avg(a.days_from_first_inv_to_closed) AS avg_days_from_first_inv_to_closed
FROM (SELECT ps.pitch_key,
             ps.pitch_name,
             d.year_month                AS created_month,
             pc.created_date_key,
             CASE
               WHEN (pc.initial_funded_date_key <> 1) THEN (pc.initial_funded_date_key - pc.created_date_key)
               ELSE NULL::integer END    AS days_from_created_to_funded,
             CASE
               WHEN (pc.closed_date_key <> 1) THEN (pc.closed_date_key - pc.initial_funded_date_key)
               ELSE NULL::integer END    AS days_from_funded_to_closed,
             CASE
               WHEN (pc.closed_date_key <> 1) THEN (pc.closed_date_key - pc.created_date_key)
               ELSE NULL::integer END    AS days_from_created_to_closed,
             min(pi.investment_date_key) AS date_of_first_investment,
             CASE
               WHEN (pc.initial_funded_date_key <> 1) THEN (pc.initial_funded_date_key - min(pi.investment_date_key))
               ELSE NULL::integer END    AS days_from_first_inv_to_funded,
             CASE
               WHEN (pc.closed_date_key <> 1) THEN (pc.closed_date_key - min(pi.investment_date_key))
               ELSE NULL::integer END    AS days_from_first_inv_to_closed
      FROM dim_dates d,
           dim_pitches_changing pc,
           dim_pitches_static ps,
           fact_pitch_investments pi
      WHERE (((((((((pc.snapshot_date_key = (SELECT dim_dates.date_key
                                             FROM dim_dates
                                             WHERE (dim_dates.the_date = ('now'::character varying)::date))) AND
                    (pc.created_date_key = d.date_key)) AND (pc.pitch_key = ps.pitch_key)) AND
                  (pc.initial_funded_date_key <> 1)) AND
                 ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND (ps.pitch_key <> 14190)) AND
               (ps.pitch_key = pi.pitch_key)) AND
              ((pi.investment_status)::text <> ('cancelled'::character varying)::text)) AND
             ((pi.investment_status)::text <> ('refunded'::character varying)::text))
      GROUP BY ps.pitch_key, ps.pitch_name, d.year_month, pc.created_date_key, pc.initial_funded_date_key,
               pc.closed_date_key
      ORDER BY pc.created_date_key) a
GROUP BY a.created_month
ORDER BY a.created_month;

alter table v_time_fund_and_close_by_created_month
  owner to ccdatawh;

