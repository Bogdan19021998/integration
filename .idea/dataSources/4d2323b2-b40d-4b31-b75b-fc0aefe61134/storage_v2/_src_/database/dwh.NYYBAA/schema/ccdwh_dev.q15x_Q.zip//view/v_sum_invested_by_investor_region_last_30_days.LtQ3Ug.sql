create view v_sum_invested_by_investor_region_last_30_days as
SELECT sum(y.amount) AS amount, count(y.transaction_id) AS frequency, y."region"
FROM (SELECT x.amount,
             x.transaction_id,
             x.postcode_lookup,
             CASE
               WHEN (x.postcode_lookup = ('overseas'::character varying)::text) THEN 'Overseas'::character varying
               ELSE x.postalregion END AS "region"
      FROM (SELECT x.amount, x.transaction_id, x.postcode_lookup, r.postalregion
            FROM ((SELECT pi.amount_in_gbp                                                          AS amount,
                          pi.transaction_id,
                          CASE
                            WHEN (((((((((("substring"((us.private_address_post_code)::text, 1, 1) =
                                           ('0'::character varying)::text) OR
                                          ("substring"((us.private_address_post_code)::text, 1, 1) =
                                           ('1'::character varying)::text)) OR
                                         ("substring"((us.private_address_post_code)::text, 1, 1) =
                                          ('2'::character varying)::text)) OR
                                        ("substring"((us.private_address_post_code)::text, 1, 1) =
                                         ('3'::character varying)::text)) OR
                                       ("substring"((us.private_address_post_code)::text, 1, 1) =
                                        ('4'::character varying)::text)) OR
                                      ("substring"((us.private_address_post_code)::text, 1, 1) =
                                       ('5'::character varying)::text)) OR
                                     ("substring"((us.private_address_post_code)::text, 1, 1) =
                                      ('6'::character varying)::text)) OR
                                    ("substring"((us.private_address_post_code)::text, 1, 1) =
                                     ('7'::character varying)::text)) OR
                                   ("substring"((us.private_address_post_code)::text, 1, 1) =
                                    ('8'::character varying)::text)) OR
                                  ("substring"((us.private_address_post_code)::text, 1, 1) =
                                   ('9'::character varying)::text)) THEN ('overseas'::character varying)::text
                            WHEN (((((((((("substring"((us.private_address_post_code)::text, 2, 1) =
                                           ('0'::character varying)::text) OR
                                          ("substring"((us.private_address_post_code)::text, 2, 1) =
                                           ('1'::character varying)::text)) OR
                                         ("substring"((us.private_address_post_code)::text, 2, 1) =
                                          ('2'::character varying)::text)) OR
                                        ("substring"((us.private_address_post_code)::text, 2, 1) =
                                         ('3'::character varying)::text)) OR
                                       ("substring"((us.private_address_post_code)::text, 2, 1) =
                                        ('4'::character varying)::text)) OR
                                      ("substring"((us.private_address_post_code)::text, 2, 1) =
                                       ('5'::character varying)::text)) OR
                                     ("substring"((us.private_address_post_code)::text, 2, 1) =
                                      ('6'::character varying)::text)) OR
                                    ("substring"((us.private_address_post_code)::text, 2, 1) =
                                     ('7'::character varying)::text)) OR
                                   ("substring"((us.private_address_post_code)::text, 2, 1) =
                                    ('8'::character varying)::text)) OR
                                  ("substring"((us.private_address_post_code)::text, 2, 1) =
                                   ('9'::character varying)::text))
                              THEN upper("substring"((us.private_address_post_code)::text, 1, 1))
                            ELSE upper("substring"((us.private_address_post_code)::text, 1, 2)) END AS postcode_lookup
                   FROM ccdwh_dev.dim_users_static us,
                        (ccdwh_dev.fact_pitch_investments pi
                          JOIN ccdwh_dev.dim_pitches_static ps ON ((pi.pitch_key = ps.pitch_key)))
                   WHERE ((((pi.user_key = us.user_key) AND
                            ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND
                           (pi.investment_date_key >= (SELECT (dim_dates.date_key - 31)
                                                       FROM ccdwh_dev.dim_dates
                                                       WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
                          (pi.investment_date_key < (SELECT dim_dates.date_key
                                                     FROM ccdwh_dev.dim_dates
                                                     WHERE (dim_dates.the_date = ('now'::character varying)::date))))) x
                   LEFT JOIN ccdwh_dev.dim_regions r ON ((x.postcode_lookup = (r.postcode)::text)))) x) y
GROUP BY y."region"
ORDER BY sum(y.amount) DESC;

alter table v_sum_invested_by_investor_region_last_30_days
  owner to ccdatawh;

