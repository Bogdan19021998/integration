create view v_pitch_channel_investment_data as
SELECT DISTINCT channeldata.pitch_key,
                channeldata.user_key,
                inv.investment_date_key AS request_date_key,
                channeldata.channel,
                channeldata.source,
                inv.amount,
                inv.investment_timestamp
FROM ((SELECT DISTINCT fe.pitch_key,
                       fe.request_timestamp,
                       sa.user_key,
                       sa.anonymousid,
                       sa.request_date_date_key AS request_date_key,
                       sa.channel,
                       sa.source
       FROM (((materialised_views.fact_session_attribution_last_non_direct_30_days sa JOIN fact_engagement fe ON (((sa.session_key)::text = (fe.session_key)::text))) JOIN dim_events e ON ((fe.event_key = e.event_key)))
              JOIN dim_sessions s ON (((sa.session_key)::text = (s.session_key)::text)))
       WHERE ((((((e.event_name)::text = 'Completed Order'::text) AND (sa.user_key > 0)) AND
                ((sa.user_key <> 431094) AND (sa.user_key <> 436557))) AND (fe.pitch_key > 0)) AND
              (s.duration_seconds >= 9))
       ORDER BY fe.pitch_key) channeldata
       JOIN (SELECT DISTINCT pi.user_key,
                             pi.amount,
                             pi.pitch_key,
                             pi.investment_date_key,
                             pi.investment_status,
                             pi.investment_timestamp
             FROM fact_pitch_investments pi
             WHERE (((pi.user_key <> 431094) AND (pi.user_key <> 436557)) AND
                    (((((pi.investment_status)::text = 'paid'::text) OR
                       ((pi.investment_status)::text = 'live'::text)) OR
                      ((pi.investment_status)::text = 'captured'::text)) OR
                     ((pi.investment_status)::text = 'withdrawn'::text)))) inv
            ON ((((inv.user_key = channeldata.user_key) AND (inv.pitch_key = channeldata.pitch_key)) AND
                 (abs(date_diff('minute'::text, inv.investment_timestamp, channeldata.request_timestamp)) < 3))));

alter table v_pitch_channel_investment_data
  owner to ccdatawh;

