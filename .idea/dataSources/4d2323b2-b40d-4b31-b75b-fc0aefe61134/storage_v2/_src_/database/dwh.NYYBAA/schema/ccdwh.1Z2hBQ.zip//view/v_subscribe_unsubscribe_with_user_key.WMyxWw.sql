create view v_subscribe_unsubscribe_with_user_key as
SELECT d.the_date,
       d.selligent_active_user,
       d.user_key,
       d.subscribed_referrer,
       sum(CASE
             WHEN ((u.subscribed_newsletter = false) AND (u.previous_subscribed_newsletter = true)) THEN 1
             ELSE 0 END)                                                 AS unsubscribe,
       sum(CASE WHEN (u.subscribed_newsletter = true) THEN 1 ELSE 0 END) AS subscribe,
       sum(COALESCE(u.invested, ((0)::numeric)::numeric(18, 0)))         AS invested,
       sum(COALESCE(u.investments, (0)::bigint))                         AS investments
FROM ((SELECT d.the_date, d."join", s.selligent_active_user, s.user_key, s.subscribed_referrer, s."join"
       FROM ((SELECT dim_dates.the_date, 'x'::character varying AS "join"
              FROM dim_dates
              WHERE ((dim_dates.the_date >= '2017-01-01'::date) AND
                     (dim_dates.the_date <= ('now'::character varying)::date))) d
              JOIN (SELECT DISTINCT dim_users_changing.selligent_active_user,
                                    dim_users_changing.user_key,
                                    dim_users_changing.subscribed_referrer,
                                    'x'::character varying AS "join"
                    FROM dim_users_changing
                    WHERE (dim_users_changing.selligent_active_user IS NOT NULL)) s
                   ON (((d."join")::text = (s."join")::text)))) d
       LEFT JOIN (SELECT u.user_key,
                         u.the_date,
                         u.subscribed_newsletter,
                         u.previous_subscribed_newsletter,
                         u.selligent_active_user,
                         i.invested,
                         i.investments
                  FROM ((SELECT uc.user_key,
                                d.the_date,
                                uc.subscribed_newsletter,
                                pg_catalog.lead(uc.subscribed_newsletter, 1)
                                OVER ( PARTITION BY uc.user_key ORDER BY d.the_date DESC) AS previous_subscribed_newsletter,
                                uc.selligent_active_user
                         FROM (dim_users_changing uc
                                JOIN dim_dates d ON ((uc.snapshot_date_key = d.date_key)))
                         WHERE ((d.the_date >= '2017-01-01'::date) AND
                                (d.the_date <= ('now'::character varying)::date))) u
                         LEFT JOIN (SELECT derived_table1.user_key,
                                           derived_table1.the_date,
                                           "max"(derived_table1.invested)    AS invested,
                                           "max"(derived_table1.investments) AS investments
                                    FROM (SELECT i.user_key,
                                                 d.the_date,
                                                 sum(i.amount_in_gbp)
                                                     OVER ( PARTITION BY i.user_key ORDER BY d.the_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)   AS invested,
                                                 count(i.amount_in_gbp)
                                                       OVER ( PARTITION BY i.user_key ORDER BY d.the_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS investments
                                          FROM ((SELECT dim_dates.the_date, dim_dates.date_key
                                                 FROM dim_dates
                                                 WHERE ((dim_dates.the_date >= '2017-01-01'::date) AND
                                                        (dim_dates.the_date <= ('now'::character varying)::date))) d
                                                 LEFT JOIN fact_pitch_investments i ON ((d.date_key = i.investment_date_key)))
                                          WHERE ((((i.investment_status)::text <>
                                                   ('cancelled'::character varying)::text) AND
                                                  ((i.investment_status)::text <>
                                                   ('refunded'::character varying)::text)) AND
                                                 ((i.investment_status)::text <> ('expired'::character varying)::text))) derived_table1
                                    GROUP BY derived_table1.user_key, derived_table1.the_date) i
                                   ON (((u.user_key = i.user_key) AND (u.the_date = i.the_date))))
                  WHERE (u.subscribed_newsletter <> u.previous_subscribed_newsletter)) u
                 ON (((d.the_date = u.the_date) AND
                      ((d.selligent_active_user)::text = (u.selligent_active_user)::text))))
GROUP BY d.the_date, d.selligent_active_user, d.user_key, d.subscribed_referrer
ORDER BY d.the_date, d.selligent_active_user, d.subscribed_referrer;

alter table v_subscribe_unsubscribe_with_user_key
  owner to ccdatawh;

