create view v_band_highest_level_qualification as
SELECT ds.pcd,
       ds.perc_no_qualifications,
       onsdata.f_percent_band(ds.perc_no_qualifications, 4) AS no_qualifications_band,
       ds.perc_level_1,
       onsdata.f_percent_band(ds.perc_level_1, 4)           AS level_1_band,
       ds.perc_level_2,
       onsdata.f_percent_band(ds.perc_level_2, 4)           AS level_2_band,
       ds.perc_level_3,
       onsdata.f_percent_band(ds.perc_level_3, 4)           AS level_3_band,
       ds.perc_level_4,
       (CASE
          WHEN (ds.perc_level_4 <= (0.4)::double precision) THEN 'A'::text
          WHEN ((ds.perc_level_4 > (0.4)::double precision) AND (ds.perc_level_4 <= (0.5)::double precision)) THEN 'B'::text
          ELSE 'C'::text END)::character(1)                 AS level_4_band
FROM (SELECT (upper("replace"(btrim((onspd.pcd)::text), ' '::text, ''::text)))::character varying(8) AS pcd,
             ((highest_level_qualification.no_qualifications)::double precision /
              (highest_level_qualification.all_categories)::double precision)                        AS perc_no_qualifications,
             ((highest_level_qualification.level_1)::double precision /
              (highest_level_qualification.all_categories)::double precision)                        AS perc_level_1,
             ((highest_level_qualification.level_2)::double precision /
              (highest_level_qualification.all_categories)::double precision)                        AS perc_level_2,
             ((highest_level_qualification.level_3)::double precision /
              (highest_level_qualification.all_categories)::double precision)                        AS perc_level_3,
             ((highest_level_qualification.level_4)::double precision /
              (highest_level_qualification.all_categories)::double precision)                        AS perc_level_4
      FROM (onsdata.onspd
             LEFT JOIN onsdata.highest_level_qualification
                       ON (((onspd.oa11)::text = (highest_level_qualification.geography_code)::text)))
      WHERE (highest_level_qualification.all_categories > 0)) ds;

alter table v_band_highest_level_qualification
  owner to ccdatawh;

