create view v_master_users_static as
SELECT DISTINCT us.user_key,
                us.user_name,
                us.user_email,
                us.user_firstname,
                us.user_lastname,
                us.private_address_address_1,
                us.private_address_address_2,
                us.private_address_town,
                us.private_address_county,
                us.private_address_post_code,
                us.private_address_country,
                us.telephone,
                us.gender,
                us.portal,
                us.first_channel_key,
                us.registered_date_key,
                us.birth_date_key,
                us.registered_timestamp,
                us.rfi,
                us.rfm
FROM dim_users_static us
WHERE ((us.portal)::text = 'crowdcube'::text);

alter table v_master_users_static
  owner to ccdatawh;

