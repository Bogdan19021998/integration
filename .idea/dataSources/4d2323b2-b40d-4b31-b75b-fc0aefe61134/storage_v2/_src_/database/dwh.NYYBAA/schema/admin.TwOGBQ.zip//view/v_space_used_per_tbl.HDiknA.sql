create view v_space_used_per_tbl as
SELECT info.dbase_name,
       info.schemaname,
       info.tablename,
       info.tbl_oid,
       info.megabytes,
       info.rowcount,
       info.unsorted_rowcount,
       info.pct_unsorted,
       CASE
         WHEN (info.rowcount = 0) THEN 'n/a'::character varying
         WHEN (info.pct_unsorted >= (((20)::numeric)::numeric(18, 0))::numeric(20, 2))
           THEN 'VACUUM SORT recommended'::character varying
         ELSE 'n/a'::character varying END AS recommendation
FROM (SELECT btrim(((pgdb.datname)::character varying)::text)                                        AS dbase_name,
             btrim(((pgn.nspname)::character varying)::text)                                         AS schemaname,
             btrim(((pgc.relname)::character varying)::text)                                         AS tablename,
             a.id                                                                                    AS tbl_oid,
             b.mbytes                                                                                AS megabytes,
             CASE WHEN (pgc.reldiststyle = 8) THEN a.rows_all_dist ELSE a."rows" END                 AS rowcount,
             CASE
               WHEN (pgc.reldiststyle = 8) THEN a.unsorted_rows_all_dist
               ELSE a.unsorted_rows END                                                              AS unsorted_rowcount,
             CASE
               WHEN (pgc.reldiststyle = 8) THEN (CASE
                                                   WHEN ((det.n_sortkeys = 0) OR ((det.n_sortkeys IS NULL) AND (0 IS NULL)))
                                                     THEN (NULL::numeric)::numeric(18, 0)
                                                   ELSE CASE
                                                          WHEN ((a.rows_all_dist = 0) OR ((a.rows_all_dist IS NULL) AND (0 IS NULL)))
                                                            THEN ((0)::numeric)::numeric(18, 0)
                                                          ELSE (
                                                              ((((a.unsorted_rows_all_dist)::numeric)::numeric(18, 0))::numeric(32, 0) /
                                                               ((a.rows_all_dist)::numeric)::numeric(18, 0)) *
                                                              ((100)::numeric)::numeric(18, 0)) END END)::numeric(20, 2)
               ELSE (CASE
                       WHEN ((det.n_sortkeys = 0) OR ((det.n_sortkeys IS NULL) AND (0 IS NULL)))
                         THEN (NULL::numeric)::numeric(18, 0)
                       ELSE CASE
                              WHEN ((a."rows" = 0) OR ((a."rows" IS NULL) AND (0 IS NULL)))
                                THEN ((0)::numeric)::numeric(18, 0)
                              ELSE (((((a.unsorted_rows)::numeric)::numeric(18, 0))::numeric(32, 0) /
                                     ((a."rows")::numeric)::numeric(18, 0)) *
                                    ((100)::numeric)::numeric(18, 0)) END END)::numeric(20, 2) END   AS pct_unsorted
      FROM ((((((SELECT stv_tbl_perm.db_id,
                        stv_tbl_perm.id,
                        stv_tbl_perm.name,
                        "max"(stv_tbl_perm."rows")                                     AS rows_all_dist,
                        ("max"(stv_tbl_perm."rows") - "max"(stv_tbl_perm.sorted_rows)) AS unsorted_rows_all_dist,
                        sum(stv_tbl_perm."rows")                                       AS "rows",
                        (sum(stv_tbl_perm."rows") - sum(stv_tbl_perm.sorted_rows))     AS unsorted_rows
                 FROM stv_tbl_perm
                 GROUP BY stv_tbl_perm.db_id, stv_tbl_perm.id, stv_tbl_perm.name) a JOIN pg_class pgc ON ((pgc.oid = (a.id)::oid))) JOIN pg_namespace pgn ON ((pgn.oid = pgc.relnamespace))) JOIN pg_database pgdb ON ((pgdb.oid = (a.db_id)::oid))) JOIN (SELECT pg_attribute.attrelid,
                                                                                                                                                                                                                                                                  min(
                                                                                                                                                                                                                                                                      ((CASE
                                                                                                                                                                                                                                                                          WHEN (pg_attribute.attisdistkey = true)
                                                                                                                                                                                                                                                                            THEN pg_attribute.attname
                                                                                                                                                                                                                                                                          ELSE NULL::name END)::character varying)::text) AS "distkey",
                                                                                                                                                                                                                                                                  min(
                                                                                                                                                                                                                                                                      ((CASE
                                                                                                                                                                                                                                                                          WHEN (pg_attribute.attsortkeyord = 1)
                                                                                                                                                                                                                                                                            THEN pg_attribute.attname
                                                                                                                                                                                                                                                                          ELSE NULL::name END)::character varying)::text) AS head_sort,
                                                                                                                                                                                                                                                                  "max"(pg_attribute.attsortkeyord)                       AS n_sortkeys,
                                                                                                                                                                                                                                                                  "max"(pg_attribute.attencodingtype)                     AS max_enc,
                                                                                                                                                                                                                                                                  (((((sum(CASE WHEN (pg_attribute.attencodingtype <> 0) THEN 1 ELSE 0 END))::numeric)::numeric(18, 0))::numeric(20, 3) /
                                                                                                                                                                                                                                                                    (((count(pg_attribute.attencodingtype))::numeric)::numeric(18, 0))::numeric(20, 3)) *
                                                                                                                                                                                                                                                                   100.00)                                                AS pct_enc
                                                                                                                                                                                                                                                           FROM pg_attribute
                                                                                                                                                                                                                                                           GROUP BY pg_attribute.attrelid) det ON ((det.attrelid = (a.id)::oid)))
             LEFT JOIN (SELECT stv_blocklist.tbl, count(*) AS mbytes FROM stv_blocklist GROUP BY stv_blocklist.tbl) b
                       ON ((a.id = b.tbl)))
      WHERE (pgc.relowner > 1)) info;

alter table v_space_used_per_tbl
  owner to ccdatawh;

