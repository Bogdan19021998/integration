create view v_generate_user_object_permissions as
SELECT v_get_obj_priv_by_user.schemaname,
       v_get_obj_priv_by_user.objectname,
       v_get_obj_priv_by_user.usename,
       reverse("substring"(reverse(((((CASE
                                         WHEN (v_get_obj_priv_by_user.sel IS TRUE) THEN (((((('GRANT SELECT ON '::text +
                                                                                              quote_ident((v_get_obj_priv_by_user.schemaname)::text)) +
                                                                                             '.'::text) +
                                                                                            quote_ident((v_get_obj_priv_by_user.objectname)::text)) +
                                                                                           ' TO '::text) +
                                                                                          quote_ident((v_get_obj_priv_by_user.usename)::text)) +
                                                                                         ';\012'::text)
                                         ELSE ''::text END + CASE
                                                               WHEN (v_get_obj_priv_by_user.ins IS TRUE) THEN (
                                                                   ((((('GRANT INSERT ON '::text +
                                                                        quote_ident((v_get_obj_priv_by_user.schemaname)::text)) +
                                                                       '.'::text) +
                                                                      quote_ident((v_get_obj_priv_by_user.objectname)::text)) +
                                                                     ' TO '::text) +
                                                                    quote_ident((v_get_obj_priv_by_user.usename)::text)) +
                                                                   ';\012'::text)
                                                               ELSE ''::text END) + CASE
                                                                                      WHEN (v_get_obj_priv_by_user.upd IS TRUE)
                                                                                        THEN (
                                                                                          ((((('GRANT UPDATE ON '::text +
                                                                                               quote_ident((v_get_obj_priv_by_user.schemaname)::text)) +
                                                                                              '.'::text) +
                                                                                             quote_ident((v_get_obj_priv_by_user.objectname)::text)) +
                                                                                            ' TO '::text) +
                                                                                           quote_ident((v_get_obj_priv_by_user.usename)::text)) +
                                                                                          ';\012'::text)
                                                                                      ELSE ''::text END) + CASE
                                                                                                             WHEN (v_get_obj_priv_by_user.del IS TRUE)
                                                                                                               THEN (
                                                                                                                 ((((('GRANT DELETE ON '::text +
                                                                                                                      quote_ident((v_get_obj_priv_by_user.schemaname)::text)) +
                                                                                                                     '.'::text) +
                                                                                                                    quote_ident((v_get_obj_priv_by_user.objectname)::text)) +
                                                                                                                   ' TO '::text) +
                                                                                                                  quote_ident((v_get_obj_priv_by_user.usename)::text)) +
                                                                                                                 ';\012'::text)
                                                                                                             ELSE ''::text END) +
                                    CASE
                                      WHEN (v_get_obj_priv_by_user.ref IS TRUE) THEN (
                                          ((((('GRANT REFERENCES ON '::text +
                                               quote_ident((v_get_obj_priv_by_user.schemaname)::text)) + '.'::text) +
                                             quote_ident((v_get_obj_priv_by_user.objectname)::text)) + ' TO '::text) +
                                           quote_ident((v_get_obj_priv_by_user.usename)::text)) + ';\012'::text)
                                      ELSE ''::text END)), 2)) AS ddl
FROM admin.v_get_obj_priv_by_user;

alter table v_generate_user_object_permissions
  owner to neil_stoneman;

