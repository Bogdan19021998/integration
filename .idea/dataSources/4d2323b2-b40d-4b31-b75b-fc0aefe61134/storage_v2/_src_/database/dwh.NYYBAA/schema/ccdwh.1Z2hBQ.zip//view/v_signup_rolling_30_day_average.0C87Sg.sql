create view v_signup_rolling_30_day_average as
SELECT count_of_c.registered_date_key AS the_date, count_of_c.count_of_signups, calc_ave.rolling_avg_30_day_signups
FROM (((SELECT u.registered_date_key, count(*) AS count_of_signups
        FROM dim_users_static u
        GROUP BY u.registered_date_key) count_of_c JOIN (SELECT tbl1.registered_date_key,
                                                                avg(tbl2.count_of_signups) AS rolling_avg_30_day_signups
                                                         FROM ((SELECT dim_users_static.registered_date_key,
                                                                       count(*) AS count_of_signups
                                                                FROM dim_users_static
                                                                GROUP BY dim_users_static.registered_date_key
                                                                ORDER BY dim_users_static.registered_date_key) tbl1
                                                                JOIN (SELECT u.registered_date_key, count(*) AS count_of_signups
                                                                      FROM (dim_users_static u
                                                                             JOIN (SELECT dim_dates.date_key
                                                                                   FROM dim_dates
                                                                                   WHERE (dim_dates.the_date = ('now'::character varying)::date)) cdate_1
                                                                                  ON ((u.registered_date_key < cdate_1.date_key)))
                                                                      GROUP BY u.registered_date_key) tbl2
                                                                     ON ((tbl2.registered_date_key > (tbl1.registered_date_key - 30))))
                                                         GROUP BY tbl1.registered_date_key
                                                         ORDER BY tbl1.registered_date_key) calc_ave ON ((calc_ave.registered_date_key = count_of_c.registered_date_key)))
       JOIN (SELECT dim_dates.date_key
             FROM dim_dates
             WHERE (dim_dates.the_date = ('now'::character varying)::date)) cdate2
            ON (((count_of_c.registered_date_key > (cdate2.date_key - 30)) AND
                 (count_of_c.registered_date_key <= cdate2.date_key))))
ORDER BY count_of_c.registered_date_key;

alter table v_signup_rolling_30_day_average
  owner to ccdatawh;

