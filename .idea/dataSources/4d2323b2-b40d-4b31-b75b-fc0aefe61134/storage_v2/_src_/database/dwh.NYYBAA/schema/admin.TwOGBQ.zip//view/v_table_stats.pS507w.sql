create view v_table_stats as
SELECT ti."schema"                                                                                  AS schemaname,
       ti."table"                                                                                   AS tablename,
       ti.table_id                                                                                  AS tableid,
       ti.size                                                                                      AS size_in_mb,
       CASE
         WHEN ((ti."diststyle" <> ('EVEN'::character varying)::text) AND
               (ti."diststyle" <> ('ALL'::character varying)::text)) THEN 1
         ELSE 0 END                                                                                 AS has_dist_key,
       CASE WHEN (ti.sortkey1 IS NOT NULL) THEN 1 ELSE 0 END                                        AS has_sort_key,
       CASE WHEN (ti.encoded = ('Y'::character varying)::text) THEN 1 ELSE 0 END                    AS has_col_encoding,
       (((iq.max_blocks_per_slice - iq.min_blocks_per_slice))::double precision /
        (GREATEST((COALESCE(iq.min_blocks_per_slice, (0)::bigint))::integer,
                  1))::double precision)                                                            AS ratio_skew_across_slices,
       (((100 * iq.dist_slice))::double precision /
        ((SELECT count(DISTINCT stv_slices.slice) AS count FROM stv_slices))::double precision)     AS pct_slices_populated
FROM (svv_table_info ti
       JOIN (SELECT derived_table1.tbl,
                    min(derived_table1.c)                AS min_blocks_per_slice,
                    "max"(derived_table1.c)              AS max_blocks_per_slice,
                    count(DISTINCT derived_table1.slice) AS dist_slice
             FROM (SELECT b.tbl, b.slice, count(*) AS c FROM stv_blocklist b GROUP BY b.tbl, b.slice) derived_table1
             WHERE ((derived_table1.tbl)::oid IN (SELECT svv_table_info.table_id FROM svv_table_info))
             GROUP BY derived_table1.tbl) iq ON (((iq.tbl)::oid = ti.table_id)));

alter table v_table_stats
  owner to ccdatawh;

