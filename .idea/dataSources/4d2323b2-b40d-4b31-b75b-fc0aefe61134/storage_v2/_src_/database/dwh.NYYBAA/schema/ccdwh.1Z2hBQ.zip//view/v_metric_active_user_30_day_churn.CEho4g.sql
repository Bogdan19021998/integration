create view v_metric_active_user_30_day_churn as
SELECT dt.the_date, count(*) AS cc_active_user_status_30_day_churn
FROM ((dim_users_changing uc JOIN dim_users_static us ON ((uc.user_key = us.user_key)))
       JOIN dim_dates dt ON ((uc.snapshot_date_key = dt.date_key)))
WHERE (((uc.crowdcube_active_user)::text = '30-day churn'::text) AND ((us.portal)::text = 'crowdcube'::text))
GROUP BY dt.the_date
ORDER BY dt.the_date DESC;

alter table v_metric_active_user_30_day_churn
  owner to ccdatawh;

