create view v_metric_fo_engagment as
SELECT dt.the_date,
       num_reg.number_registered_users,
       num_unique_vis.num_unique_visitors,
       num_active.cc_active_user_status_active,
       num_30_day_churn.cc_active_user_status_30_day_churn,
       num_60_day_churn.cc_active_user_status_60_day_churn,
       num_inactive.cc_active_user_status_inactive,
       reengagement.reengagement_inactive_to_active,
       reengagement.reengagement_30daychurn_to_active,
       reengagement.reengagement_60daychurn_to_active
FROM (((((((dim_dates dt LEFT JOIN (SELECT dt.the_date, count(*) AS number_registered_users
                                    FROM (dim_users_static us
                                           JOIN dim_dates dt ON ((us.registered_date_key = dt.date_key)))
                                    GROUP BY dt.the_date
                                    ORDER BY dt.the_date DESC) num_reg ON ((dt.the_date = num_reg.the_date))) LEFT JOIN (SELECT dt.the_date,
                                                                                                                                count(DISTINCT s.anonymousid) AS num_unique_visitors
                                                                                                                         FROM (dim_sessions s
                                                                                                                                JOIN dim_dates dt ON ((s.session_start_date_key = dt.date_key)))
                                                                                                                         WHERE (dt.the_date < (('now'::text)::date + 1))
                                                                                                                         GROUP BY dt.the_date
                                                                                                                         ORDER BY dt.the_date DESC) num_unique_vis ON ((dt.the_date = num_unique_vis.the_date))) LEFT JOIN (SELECT dt.the_date, count(*) AS cc_active_user_status_active
                                                                                                                                                                                                                            FROM (dim_users_changing uc
                                                                                                                                                                                                                                   JOIN dim_dates dt ON ((uc.snapshot_date_key = dt.date_key)))
                                                                                                                                                                                                                            WHERE ((uc.crowdcube_active_user)::text = 'Active'::text)
                                                                                                                                                                                                                            GROUP BY dt.the_date
                                                                                                                                                                                                                            ORDER BY dt.the_date DESC) num_active ON ((dt.the_date = num_active.the_date))) LEFT JOIN (SELECT dt.the_date, count(*) AS cc_active_user_status_30_day_churn
                                                                                                                                                                                                                                                                                                                       FROM (dim_users_changing uc
                                                                                                                                                                                                                                                                                                                              JOIN dim_dates dt ON ((uc.snapshot_date_key = dt.date_key)))
                                                                                                                                                                                                                                                                                                                       WHERE ((uc.crowdcube_active_user)::text = '30-day churn'::text)
                                                                                                                                                                                                                                                                                                                       GROUP BY dt.the_date
                                                                                                                                                                                                                                                                                                                       ORDER BY dt.the_date DESC) num_30_day_churn ON ((dt.the_date = num_30_day_churn.the_date))) LEFT JOIN (SELECT dt.the_date, count(*) AS cc_active_user_status_60_day_churn
                                                                                                                                                                                                                                                                                                                                                                                                                              FROM (dim_users_changing uc
                                                                                                                                                                                                                                                                                                                                                                                                                                     JOIN dim_dates dt ON ((uc.snapshot_date_key = dt.date_key)))
                                                                                                                                                                                                                                                                                                                                                                                                                              WHERE ((uc.crowdcube_active_user)::text = '60-day churn'::text)
                                                                                                                                                                                                                                                                                                                                                                                                                              GROUP BY dt.the_date
                                                                                                                                                                                                                                                                                                                                                                                                                              ORDER BY dt.the_date DESC) num_60_day_churn ON ((dt.the_date = num_60_day_churn.the_date))) LEFT JOIN (SELECT dt.the_date, count(*) AS cc_active_user_status_inactive
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     FROM (dim_users_changing uc
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            JOIN dim_dates dt ON ((uc.snapshot_date_key = dt.date_key)))
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     WHERE ((uc.crowdcube_active_user)::text = 'Inactive'::text)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     GROUP BY dt.the_date) num_inactive ON ((dt.the_date = num_inactive.the_date)))
       LEFT JOIN (SELECT ds2.the_date,
                         sum(ds2.reengagement_inactive_to_active)   AS reengagement_inactive_to_active,
                         sum(ds2.reengagement_30daychurn_to_active) AS reengagement_30daychurn_to_active,
                         sum(ds2.reengagement_60daychurn_to_active) AS reengagement_60daychurn_to_active
                  FROM (SELECT dt.the_date,
                               ds.user_key,
                               CASE
                                 WHEN (((ds.active_status_previous)::text = 'Inactive'::text) AND
                                       ((ds.active_status_current)::text = 'Active'::text)) THEN 1
                                 ELSE 0 END AS reengagement_inactive_to_active,
                               CASE
                                 WHEN (((ds.active_status_previous)::text = '30-day churn'::text) AND
                                       ((ds.active_status_current)::text = 'Active'::text)) THEN 1
                                 ELSE 0 END AS reengagement_30daychurn_to_active,
                               CASE
                                 WHEN (((ds.active_status_previous)::text = '60-day churn'::text) AND
                                       ((ds.active_status_current)::text = 'Active'::text)) THEN 1
                                 ELSE 0 END AS reengagement_60daychurn_to_active
                        FROM ((SELECT uc.user_key,
                                      uc_p.crowdcube_active_user AS active_status_previous,
                                      uc.crowdcube_active_user   AS active_status_current,
                                      '-'::character varying     AS blank,
                                      uc_p.snapshot_date_key     AS snapshot_date_key_previous,
                                      uc.snapshot_date_key       AS snapshot_date_key_current
                               FROM (dim_users_changing uc
                                      JOIN dim_users_changing uc_p ON (((uc.user_key = uc_p.user_key) AND
                                                                        ((uc.snapshot_date_key - 1) = uc_p.snapshot_date_key))))
                               WHERE ((uc.user_key > 0) AND (uc.crowdcube_active_user IS NOT NULL))
                               ORDER BY uc.user_key, uc.snapshot_date_key) ds
                               JOIN dim_dates dt ON ((ds.snapshot_date_key_current = dt.date_key)))
                        WHERE ((ds.active_status_current)::text <> (ds.active_status_previous)::text)) ds2
                  GROUP BY ds2.the_date) reengagement ON ((dt.the_date = reengagement.the_date)))
WHERE ((dt.the_date > (('now'::text)::date - 100)) AND (dt.the_date < (('now'::text)::date + 1)))
ORDER BY dt.the_date;

alter table v_metric_fo_engagment
  owner to ccdatawh;

