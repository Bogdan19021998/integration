create view v_metric_investor_type_classification as
SELECT ds2.user_key,
       ((ds2.qtyclass || ' '::text) || ds2.valclass) AS investor_classification,
       ds2.qtyclass                                  AS investor_classification_qty,
       ds2.valclass                                  AS investor_classification_val,
       ds2.num_investments,
       ds2.min_investment,
       ds2.max_investment,
       ds2.avg_investment
FROM (SELECT us.user_key,
             us.user_name,
             CASE
               WHEN (ds.num_investments IS NULL) THEN 'No'::text
               WHEN (ds.num_investments = 1) THEN 'Single'::text
               WHEN ((ds.num_investments > 1) AND (ds.num_investments < 10)) THEN 'Small number'::text
               WHEN ((ds.num_investments >= 10) AND (ds.num_investments < 20)) THEN 'Medium number'::text
               WHEN ((ds.num_investments >= 20) AND (ds.num_investments < 50)) THEN 'Large number'::text
               WHEN (ds.num_investments >= 50) THEN 'Addicted'::text
               ELSE NULL::text END AS qtyclass,
             CASE
               WHEN (ds.max_investment IS NULL) THEN 'investment(s)'::text
               WHEN (ds.max_investment < (300)::numeric) THEN 'tentative investment(s)'::text
               WHEN ((ds.max_investment >= (300)::numeric) AND (ds.max_investment < (1000)::numeric))
                 THEN 'small investment(s)'::text
               WHEN ((ds.max_investment >= (1000)::numeric) AND (ds.max_investment < (5000)::numeric))
                 THEN 'medium investment(s)'::text
               WHEN ((ds.max_investment >= (5000)::numeric) AND (ds.max_investment < (50000)::numeric))
                 THEN 'large investment(s)'::text
               WHEN ((ds.max_investment >= (50000)::numeric) AND (ds.max_investment < (1000000)::numeric))
                 THEN 'significant investment(s)'::text
               WHEN (ds.max_investment >= (1000000)::numeric) THEN 'unicorn(s)'::text
               ELSE NULL::text END AS valclass,
             ds.num_investments,
             ds.min_investment,
             ds.max_investment,
             ds.avg_investment
      FROM (dim_users_static us
             LEFT JOIN (SELECT i.user_key,
                               count(*)               AS num_investments,
                               min(i.amount_in_gbp)   AS min_investment,
                               "max"(i.amount_in_gbp) AS max_investment,
                               avg(i.amount_in_gbp)   AS avg_investment
                        FROM fact_pitch_investments i
                        GROUP BY i.user_key
                        ORDER BY i.user_key) ds ON ((us.user_key = ds.user_key)))) ds2
ORDER BY ds2.user_name;

alter table v_metric_investor_type_classification
  owner to ccdatawh;

