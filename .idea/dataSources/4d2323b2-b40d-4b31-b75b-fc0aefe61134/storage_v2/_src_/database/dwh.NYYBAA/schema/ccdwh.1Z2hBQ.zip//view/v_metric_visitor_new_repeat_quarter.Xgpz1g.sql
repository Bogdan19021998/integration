create view v_metric_visitor_new_repeat_quarter as
SELECT y.year_quarter,
       y.num_new_quarter,
       (y.num_unique_visitors - y.num_new_quarter) AS num_repeat_visitors,
       y.num_unique_visitors
FROM (SELECT x.year_quarter, sum(x.num_new) AS num_new_quarter, x.num_unique_visitors
      FROM (SELECT dt.date_key, dt.year_quarter, count(DISTINCT ds.anonymousid) AS num_new, vis.num_unique_visitors
            FROM ((dim_dates dt LEFT JOIN (SELECT DISTINCT s.anonymousid, min(s.session_start_date_key) AS first_session
                                           FROM dim_sessions s
                                           GROUP BY s.anonymousid) ds ON ((dt.date_key = ds.first_session)))
                   LEFT JOIN (SELECT v_metric_unique_visitors_quarter.year_quarter,
                                     v_metric_unique_visitors_quarter.num_unique_visitors
                              FROM v_metric_unique_visitors_quarter) vis
                             ON (((dt.year_quarter)::text = (vis.year_quarter)::text)))
            WHERE (dt.the_date < ('now'::text)::date)
            GROUP BY dt.date_key, vis.num_unique_visitors, dt.year_quarter
            ORDER BY dt.date_key, dt.year_quarter DESC) x
      GROUP BY x.year_quarter, x.num_unique_visitors
      ORDER BY x.year_quarter DESC) y
WHERE ((y.year_quarter)::text >= '2015/Q2'::text)
ORDER BY y.year_quarter DESC;

alter table v_metric_visitor_new_repeat_quarter
  owner to ccdatawh;

