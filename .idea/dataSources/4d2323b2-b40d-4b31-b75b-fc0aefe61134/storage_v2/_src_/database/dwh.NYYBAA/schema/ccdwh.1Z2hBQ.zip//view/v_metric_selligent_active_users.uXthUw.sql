create view v_metric_selligent_active_users as
SELECT derived_table1.user_key,
       derived_table1.unsubscribed,
       derived_table1.no_email,
       derived_table1.invalid_email,
       derived_table1.deleted,
       derived_table1.suspended,
       CASE
         WHEN derived_table1.unsubscribed THEN 'Inactive - Unsubscribed'::text
         WHEN derived_table1.no_email THEN 'Inactive - No email'::text
         WHEN derived_table1.invalid_email THEN 'Inactive - Invalid Email'::text
         WHEN derived_table1.deleted THEN 'Inactive - Deleted'::text
         WHEN derived_table1.suspended THEN 'Inactive - Suspended'::text
         ELSE 'Active'::text END AS selligent_active_status
FROM (SELECT us.user_key,
             CASE WHEN (subscribed.user_key IS NULL) THEN true ELSE false END AS unsubscribed,
             CASE WHEN (no_em.user_key IS NULL) THEN false ELSE true END      AS no_email,
             CASE WHEN (inv_em.user_key IS NULL) THEN false ELSE true END     AS invalid_email,
             CASE WHEN (del.user_key IS NULL) THEN false ELSE true END        AS deleted,
             CASE WHEN (sus.user_key IS NULL) THEN false ELSE true END        AS suspended
      FROM (((((dim_users_static us LEFT JOIN (SELECT DISTINCT dim_users_changing.user_key
                                               FROM dim_users_changing
                                               WHERE ((COALESCE(dim_users_changing.subscribed_marketing, 0) = 1) AND
                                                      (dim_users_changing.snapshot_date_key =
                                                       (SELECT "max"(dim_users_changing.snapshot_date_key) AS "max"
                                                        FROM dim_users_changing)))) subscribed ON ((us.user_key = subscribed.user_key))) LEFT JOIN (SELECT DISTINCT dim_users_static.user_key
                                                                                                                                                    FROM dim_users_static
                                                                                                                                                    WHERE (btrim((dim_users_static.user_email)::text) = ''::text)) no_em ON ((us.user_key = no_em.user_key))) LEFT JOIN (SELECT DISTINCT dim_users_changing.user_key
                                                                                                                                                                                                                                                                         FROM dim_users_changing
                                                                                                                                                                                                                                                                         WHERE ((dim_users_changing.snapshot_date_key =
                                                                                                                                                                                                                                                                                 (SELECT dim_dates.date_key
                                                                                                                                                                                                                                                                                  FROM dim_dates
                                                                                                                                                                                                                                                                                  WHERE (dim_dates.the_date = ('now'::text)::date))) AND
                                                                                                                                                                                                                                                                                (dim_users_changing.email_address_valid = false))) inv_em ON ((us.user_key = inv_em.user_key))) LEFT JOIN (SELECT DISTINCT dim_users_changing.user_key
                                                                                                                                                                                                                                                                                                                                                                                           FROM dim_users_changing
                                                                                                                                                                                                                                                                                                                                                                                           WHERE ((dim_users_changing.snapshot_date_key =
                                                                                                                                                                                                                                                                                                                                                                                                   (SELECT dim_dates.date_key
                                                                                                                                                                                                                                                                                                                                                                                                    FROM dim_dates
                                                                                                                                                                                                                                                                                                                                                                                                    WHERE (dim_dates.the_date = ('now'::text)::date))) AND
                                                                                                                                                                                                                                                                                                                                                                                                  ((dim_users_changing.deleted)::text = 'Yes'::text))) del ON ((us.user_key = del.user_key)))
             LEFT JOIN (SELECT DISTINCT dim_users_changing.user_key
                        FROM dim_users_changing
                        WHERE ((dim_users_changing.snapshot_date_key = (SELECT dim_dates.date_key
                                                                        FROM dim_dates
                                                                        WHERE (dim_dates.the_date = ('now'::text)::date))) AND
                               ((dim_users_changing.suspended)::text = 'Yes'::text))) sus
                       ON ((us.user_key = sus.user_key)))) derived_table1;

alter table v_metric_selligent_active_users
  owner to ccdatawh;

