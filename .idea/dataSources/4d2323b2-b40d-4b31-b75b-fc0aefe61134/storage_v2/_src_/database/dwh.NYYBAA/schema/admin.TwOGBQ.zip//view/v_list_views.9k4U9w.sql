create view v_list_views as
SELECT "tables".table_name, "tables".table_schema
FROM information_schema."tables"
WHERE (((("tables".table_type)::text = 'VIEW'::text) AND ((("tables".table_schema)::text <> 'pg_catalog'::text) AND
                                                          (("tables".table_schema)::text <> 'information_schema'::text))) AND
       (("tables".table_name)::text !~ '^pg_'::text));

alter table v_list_views
  owner to ccdatawh;

