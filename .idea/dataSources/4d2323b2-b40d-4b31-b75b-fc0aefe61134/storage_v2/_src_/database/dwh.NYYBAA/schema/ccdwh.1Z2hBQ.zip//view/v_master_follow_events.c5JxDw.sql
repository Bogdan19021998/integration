create view v_master_follow_events as
  ((SELECT dim_events.event_key, dim_events.event_name, true AS follow
    FROM dim_events
    WHERE (lower((dim_events.event_name)::text) = 'follow'::text)
    UNION
    SELECT dim_events.event_key, dim_events.event_name, true AS follow
    FROM dim_events
    WHERE (lower((dim_events.event_name)::text) = 'company follow'::text))
   UNION
   SELECT dim_events.event_key, dim_events.event_name, false AS follow
   FROM dim_events
   WHERE (lower((dim_events.event_name)::text) = 'unfollow'::text))
  UNION
  SELECT dim_events.event_key, dim_events.event_name, false AS follow
  FROM dim_events
  WHERE (lower((dim_events.event_name)::text) = 'company unfollow'::text);

alter table v_master_follow_events
  owner to ccdatawh;

