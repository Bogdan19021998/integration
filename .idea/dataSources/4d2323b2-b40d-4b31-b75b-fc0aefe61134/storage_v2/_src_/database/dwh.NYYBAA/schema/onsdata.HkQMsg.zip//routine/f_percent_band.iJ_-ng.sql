create function f_percent_band(percentage double precision, number_of_bands integer) returns character
  stable
  language plpythonu
as
$$
        if number_of_bands == 2:
                if percentage <= 0.5:
                        return 'A'
                else:  
                        return 'B'
        elif number_of_bands == 3:
                if percentage <= 0.33:
                        return 'A'
                elif percentage < 0.66:
                        return 'B'
                else:
                        return 'C'
        elif number_of_bands == 4:
                if percentage <= 0.25:
                        return 'A'
                elif percentage <= 0.5:
                        return 'B'
                elif percentage <= 0.75:
                        return 'C'
                else:
                        return 'D'
        elif number_of_bands == 5:
                if percentage <= 0.2:
                        return 'A'
                elif percentage <= 0.4:
                        return 'B'
                elif percentage <= 0.6:
                        return 'C'
                elif percentage <= 0.8:
                        return 'D'
                else:
                        return 'E'
        elif number_of_bands == 6:
                if percentage <= 0.16:
                        return 'A'
                elif percentage <= 0.33:
                        return 'B'
                elif percentage <= 0.5:
                        return 'C'
                elif percentage <= 0.66:
                        return 'D'
                elif percentage <= 0.82:
                        return 'E'
                else:
                        return 'F'                
        else:
                #-- Un-caught condition. This should not occur
                return 'U'
       
$$;

