create view v_metric_pitch_follow_channel_attribution_last_60 as
SELECT COALESCE(follows.request_date_date_key, unfollows.request_date_date_key)                        AS request_date_date_key,
       COALESCE(follows.pitch_key, unfollows.pitch_key)                                                AS pitch_key,
       COALESCE(follows.channel, unfollows.channel)                                                    AS channel,
       COALESCE(follows.source, unfollows.source)                                                      AS source,
       COALESCE(follows.medium, unfollows.medium)                                                      AS medium,
       follows.count_follow,
       unfollows.count_unfollow,
       (COALESCE(follows.count_follow, (0)::bigint) - COALESCE(unfollows.count_unfollow, (0)::bigint)) AS count_total
FROM ((SELECT all_events.request_date_date_key,
              all_events.pitch_key,
              all_events.channel,
              all_events.source,
              all_events.medium,
              count(1) AS count_follow
       FROM (SELECT DISTINCT sa.request_date_date_key,
                             sa.session_key,
                             fe.pitch_key,
                             sa.channel,
                             sa.source,
                             sa.medium,
                             e.follow
             FROM ((materialised_views.fact_session_attribution_last_non_direct_30_days sa JOIN fact_engagement fe ON (((sa.session_key)::text = (fe.session_key)::text)))
                    JOIN v_master_follow_events e ON ((fe.event_key = e.event_key)))
             WHERE (sa.request_date_date_key >= (SELECT dim_dates.date_key
                                                 FROM dim_dates
                                                 WHERE (dim_dates.the_date = (('now'::text)::date - 60))))) all_events
       WHERE (all_events.follow = (1)::boolean)
       GROUP BY all_events.request_date_date_key, all_events.pitch_key, all_events.channel, all_events.source,
                all_events.medium) follows
       FULL JOIN (SELECT all_events.request_date_date_key,
                         all_events.pitch_key,
                         all_events.channel,
                         all_events.source,
                         all_events.medium,
                         count(1) AS count_unfollow
                  FROM (SELECT DISTINCT sa.request_date_date_key,
                                        sa.session_key,
                                        fe.pitch_key,
                                        sa.channel,
                                        sa.source,
                                        sa.medium,
                                        e.follow
                        FROM ((materialised_views.fact_session_attribution_last_non_direct_30_days sa JOIN fact_engagement fe ON (((sa.session_key)::text = (fe.session_key)::text)))
                               JOIN v_master_follow_events e ON ((fe.event_key = e.event_key)))
                        WHERE (sa.request_date_date_key >= (SELECT dim_dates.date_key
                                                            FROM dim_dates
                                                            WHERE (dim_dates.the_date = (('now'::text)::date - 60))))) all_events
                  WHERE (all_events.follow = (0)::boolean)
                  GROUP BY all_events.request_date_date_key, all_events.pitch_key, all_events.channel,
                           all_events.source, all_events.medium) unfollows ON ((
    ((((unfollows.request_date_date_key = follows.request_date_date_key) AND
       (unfollows.pitch_key = follows.pitch_key)) AND ((unfollows.channel)::text = (follows.channel)::text)) AND
     ((unfollows.source)::text = (follows.source)::text)) AND ((unfollows.medium)::text = (follows.medium)::text))));

alter table v_metric_pitch_follow_channel_attribution_last_60
  owner to ccdatawh;

