create function int8_pl_timestamp(bigint, timestamp without time zone) returns timestamp without time zone
  immutable
  language sql
as
$$
select $2 + $1
$$;

