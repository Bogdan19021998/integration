create view v_top_5_investment_amounts_bonds_last_30_days as
SELECT pi.amount_in_gbp, count(pi.transaction_id) AS frequency
FROM ccdwh_dev.fact_pitch_investments pi,
     ccdwh_dev.dim_pitches_static ps
WHERE (((((pi.pitch_key = ps.pitch_key) AND ((ps.product_type)::text = ('Bonds'::character varying)::text)) AND
         ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND
        (pi.investment_date_key >= (SELECT (dim_dates.date_key - 31)
                                    FROM ccdwh_dev.dim_dates
                                    WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
       (NOT (pi.investment_date_key IN (SELECT dim_dates.date_key
                                        FROM ccdwh_dev.dim_dates
                                        WHERE (dim_dates.the_date = ('now'::character varying)::date)))))
GROUP BY pi.amount_in_gbp
ORDER BY count(pi.transaction_id) DESC
LIMIT 5;

alter table v_top_5_investment_amounts_bonds_last_30_days
  owner to ccdatawh;

