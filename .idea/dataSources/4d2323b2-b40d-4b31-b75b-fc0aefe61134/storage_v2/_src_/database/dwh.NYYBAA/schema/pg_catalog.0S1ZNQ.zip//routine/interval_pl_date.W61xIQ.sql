create function interval_pl_date(interval, date) returns timestamp without time zone
  immutable
  language sql
as
$$
select $2 + $1
$$;

