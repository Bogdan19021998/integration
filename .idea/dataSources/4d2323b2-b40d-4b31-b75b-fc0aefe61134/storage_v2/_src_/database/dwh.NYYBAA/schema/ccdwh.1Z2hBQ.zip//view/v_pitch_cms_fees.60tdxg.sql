create view v_pitch_cms_fees as
SELECT pc.pitch_key, pc.commission, pc.investment_fee, pc.completion_fee
FROM dim_pitches_changing pc
WHERE (pc.snapshot_date_key =
       (SELECT "max"(dim_pitches_changing.snapshot_date_key) AS "max" FROM dim_pitches_changing));

alter table v_pitch_cms_fees
  owner to ccdatawh;

