create view v_salesforce_opportunity_pitch_relation as
  SELECT opp_pitches.opportunity_id, opp_pitches.pitch_key
  FROM (SELECT o.x18_digit_id_c AS opportunity_id, o.pitch_id_c AS opp_pitch_key, p.pitch_key
        FROM (sfexperimental.opportunities o
               JOIN v_master_pitches_latest p
                    ON (((p.salesforce_opportunity_id)::text = (o.x18_digit_id_c)::text)))) opp_pitches
  WHERE (NOT (opp_pitches.opportunity_id IN (SELECT de_duped_opp_pitches.opportunity_id
                                             FROM (SELECT derived_table1.opportunity_id, derived_table1.pitch_key
                                                   FROM (SELECT dup_opp_pitches.opportunity_id,
                                                                dup_opp_pitches.pitch_key,
                                                                pg_catalog.row_number()
                                                                OVER ( PARTITION BY dup_opp_pitches.opportunity_id ORDER BY dup_opp_pitches.pitch_key DESC) AS rn
                                                         FROM (SELECT opp_pitches.opportunity_id,
                                                                      opp_pitches.opp_pitch_key,
                                                                      opp_pitches.pitch_key
                                                               FROM (SELECT o.x18_digit_id_c AS opportunity_id,
                                                                            o.pitch_id_c     AS opp_pitch_key,
                                                                            p.pitch_key
                                                                     FROM (sfexperimental.opportunities o
                                                                            JOIN v_master_pitches_latest p
                                                                                 ON (((p.salesforce_opportunity_id)::text = (o.x18_digit_id_c)::text)))) opp_pitches
                                                               WHERE (opp_pitches.opportunity_id IN
                                                                      (SELECT opp_pitches.opportunity_id
                                                                       FROM (SELECT o.x18_digit_id_c AS opportunity_id,
                                                                                    o.pitch_id_c     AS opp_pitch_key,
                                                                                    p.pitch_key
                                                                             FROM (sfexperimental.opportunities o
                                                                                    JOIN v_master_pitches_latest p
                                                                                         ON (((p.salesforce_opportunity_id)::text = (o.x18_digit_id_c)::text)))) opp_pitches
                                                                       GROUP BY opp_pitches.opportunity_id
                                                                       HAVING (count(1) > 1)))) dup_opp_pitches) derived_table1
                                                   WHERE (derived_table1.rn = 1)) de_duped_opp_pitches)))
  UNION
  SELECT de_duped_opp_pitches.opportunity_id, de_duped_opp_pitches.pitch_key
  FROM (SELECT derived_table1.opportunity_id, derived_table1.pitch_key
        FROM (SELECT dup_opp_pitches.opportunity_id,
                     dup_opp_pitches.pitch_key,
                     pg_catalog.row_number()
                     OVER ( PARTITION BY dup_opp_pitches.opportunity_id ORDER BY dup_opp_pitches.pitch_key DESC) AS rn
              FROM (SELECT opp_pitches.opportunity_id, opp_pitches.opp_pitch_key, opp_pitches.pitch_key
                    FROM (SELECT o.x18_digit_id_c AS opportunity_id, o.pitch_id_c AS opp_pitch_key, p.pitch_key
                          FROM (sfexperimental.opportunities o
                                 JOIN v_master_pitches_latest p
                                      ON (((p.salesforce_opportunity_id)::text = (o.x18_digit_id_c)::text)))) opp_pitches
                    WHERE (opp_pitches.opportunity_id IN (SELECT opp_pitches.opportunity_id
                                                          FROM (SELECT o.x18_digit_id_c AS opportunity_id,
                                                                       o.pitch_id_c     AS opp_pitch_key,
                                                                       p.pitch_key
                                                                FROM (sfexperimental.opportunities o
                                                                       JOIN v_master_pitches_latest p
                                                                            ON (((p.salesforce_opportunity_id)::text = (o.x18_digit_id_c)::text)))) opp_pitches
                                                          GROUP BY opp_pitches.opportunity_id
                                                          HAVING (count(1) > 1)))) dup_opp_pitches) derived_table1
        WHERE (derived_table1.rn = 1)) de_duped_opp_pitches;

alter table v_salesforce_opportunity_pitch_relation
  owner to ccdatawh;

