create view v_average_weekly_income as
SELECT (upper("replace"(btrim((p.pcd)::text), ' '::text, ''::text)))::character varying(8) AS pcd,
       i.average_weekly_income
FROM (onsdata.onspd p
       LEFT JOIN ((SELECT DISTINCT p.pcd, i.average_weekly_income
                   FROM (onsdata.income_combined i
                          JOIN onsdata.onspd p ON (((i.geography_code)::text = (p.oslaua)::text)))
                   WHERE ((i.ctry12nm)::text = 'Scotland'::text)
                   UNION ALL
                   SELECT DISTINCT p.pcd, i.average_weekly_income
                   FROM (onsdata.income_combined i
                          JOIN onsdata.onspd p ON (((i.lgd_code)::text = "left"((p.casward)::text, 4))))
                   WHERE ((i.ctry12nm)::text = 'Northern Ireland'::text))
                  UNION ALL
                  SELECT DISTINCT p.pcd, i.average_weekly_income
                  FROM (onsdata.income_combined i
                         JOIN onsdata.onspd p ON (((i.msoa_code)::text = (p.msoa11)::text)))
                  WHERE (((i.ctry12nm)::text = 'England'::text) OR ((i.ctry12nm)::text = 'Wales'::text))) i
                 ON (((p.pcd)::text = (i.pcd)::text)));

alter table v_average_weekly_income
  owner to ccdatawh;

