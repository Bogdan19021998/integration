create view v_distil_sahara_beauhurst_raise_prediction as
SELECT DISTINCT derived_table3.beauhurst_url,
                derived_table3.company_name,
                derived_table3.companies_house_number,
                derived_table3.companies_house_status,
                derived_table3.current_stage_of_evolution,
                derived_table3.number_of_fundraisings_completed_by_the_company,
                derived_table3.total_amount_received_by_the_company_through_fundraisings_gbp,
                derived_table3.date_of_the_last_fundraising,
                derived_table3.company_funders_to_date,
                derived_table3.incorporation_date,
                derived_table3.description,
                derived_table3.date_of_latest_credit_rating_change,
                derived_table3.latest_pre_money_valuation,
                derived_table3.latest_post_money_valuation,
                derived_table3.credit_rating,
                derived_table3.credit_limit_gbp,
                derived_table3.telephone,
                derived_table3.website,
                derived_table3.contact_name,
                derived_table3.first_name,
                derived_table3.last_name,
                derived_table3.contact_email,
                derived_table3.contact_title,
                derived_table3.cc_funded_count,
                derived_table3.funded_with_crowdcube,
                derived_table3.cc_gone_live_count,
                derived_table3.gone_live_with_crowdcube,
                derived_table3.sf_opportunity_count,
                derived_table3.sf_opportunity,
                derived_table3.sf_lead,
                derived_table3.record_type_id,
                derived_table3.owner_id,
                derived_table3.marketing_notes,
                derived_table3.bd_manager,
                derived_table3.lead_source,
                derived_table3.status,
                derived_table3.industry,
                derived_table3.beauhurst_sectors,
                derived_table3.estimated_next_raise_date,
                derived_table3.suggested_contact_date,
                derived_table3.days_until_contact,
                derived_table3.months_until_contact,
                CASE
                  WHEN (derived_table3.days_until_contact < 0) THEN 'Contact Date Passed'::text
                  WHEN (derived_table3.days_until_contact <= 30) THEN 'Contact Now'::text
                  WHEN (derived_table3.months_until_contact <= 3) THEN 'Contact in next 3 Months'::text
                  ELSE 'Contact not due'::text END AS contact_category
FROM (SELECT derived_table2.beauhurst_url,
             derived_table2.company_name,
             derived_table2.companies_house_number,
             derived_table2.companies_house_status,
             derived_table2.current_stage_of_evolution,
             derived_table2.number_of_fundraisings_completed_by_the_company,
             derived_table2.total_amount_received_by_the_company_through_fundraisings_gbp,
             derived_table2.date_of_the_last_fundraising,
             derived_table2.company_funders_to_date,
             derived_table2.incorporation_date,
             derived_table2.description,
             derived_table2.date_of_latest_credit_rating_change,
             derived_table2.latest_pre_money_valuation,
             derived_table2.latest_post_money_valuation,
             derived_table2.credit_rating,
             derived_table2.credit_limit_gbp,
             derived_table2.telephone,
             derived_table2.website,
             derived_table2.contact_name,
             derived_table2.first_name,
             derived_table2.last_name,
             derived_table2.contact_email,
             derived_table2.contact_title,
             derived_table2.cc_funded_count,
             derived_table2.funded_with_crowdcube,
             derived_table2.cc_gone_live_count,
             derived_table2.gone_live_with_crowdcube,
             derived_table2.sf_opportunity_count,
             derived_table2.sf_opportunity,
             derived_table2.sf_lead,
             derived_table2.record_type_id,
             derived_table2.owner_id,
             derived_table2.marketing_notes,
             derived_table2.bd_manager,
             derived_table2.lead_source,
             derived_table2.status,
             derived_table2.industry,
             derived_table2.beauhurst_sectors,
             derived_table2.estimated_next_raise_date,
             derived_table2.suggested_contact_date,
             date_diff('day'::text, (('now'::text)::date)::timestamp without time zone,
                       (derived_table2.suggested_contact_date)::timestamp without time zone) AS days_until_contact,
             date_diff('month'::text, (('now'::text)::date)::timestamp without time zone,
                       (derived_table2.suggested_contact_date)::timestamp without time zone) AS months_until_contact
      FROM (SELECT derived_table1.beauhurst_url,
                   derived_table1.company_name,
                   derived_table1.companies_house_number,
                   derived_table1.companies_house_status,
                   derived_table1.current_stage_of_evolution,
                   derived_table1.number_of_fundraisings_completed_by_the_company,
                   derived_table1.total_amount_received_by_the_company_through_fundraisings_gbp,
                   derived_table1.date_of_the_last_fundraising,
                   derived_table1.company_funders_to_date,
                   derived_table1.incorporation_date,
                   derived_table1.description,
                   derived_table1.date_of_latest_credit_rating_change,
                   derived_table1.latest_pre_money_valuation,
                   derived_table1.latest_post_money_valuation,
                   derived_table1.credit_rating,
                   derived_table1.credit_limit_gbp,
                   derived_table1.telephone,
                   derived_table1.website,
                   derived_table1.contact_name,
                   derived_table1.first_name,
                   derived_table1.last_name,
                   derived_table1.contact_email,
                   derived_table1.contact_title,
                   derived_table1.cc_funded_count,
                   derived_table1.funded_with_crowdcube,
                   derived_table1.cc_gone_live_count,
                   derived_table1.gone_live_with_crowdcube,
                   derived_table1.sf_opportunity_count,
                   derived_table1.sf_opportunity,
                   derived_table1.sf_lead,
                   derived_table1.record_type_id,
                   derived_table1.owner_id,
                   derived_table1.marketing_notes,
                   derived_table1.bd_manager,
                   derived_table1.lead_source,
                   derived_table1.status,
                   derived_table1.industry,
                   derived_table1.beauhurst_sectors,
                   derived_table1.estimated_next_raise_date,
                   date(CASE
                          WHEN ((derived_table1.current_stage_of_evolution)::text = 'Seed'::text) THEN date_add(
                              'month'::text, (-2)::bigint,
                              (derived_table1.estimated_next_raise_date)::timestamp without time zone)
                          WHEN ((derived_table1.current_stage_of_evolution)::text = 'Venture'::text) THEN date_add(
                              'month'::text, (-4)::bigint,
                              (derived_table1.estimated_next_raise_date)::timestamp without time zone)
                          WHEN ((derived_table1.current_stage_of_evolution)::text = 'Growth'::text) THEN date_add(
                              'month'::text, (-6)::bigint,
                              (derived_table1.estimated_next_raise_date)::timestamp without time zone)
                          ELSE NULL::timestamp without time zone END) AS suggested_contact_date
            FROM (SELECT b.beauhurst_url,
                         b.company_name,
                         b.companies_house_number,
                         b.companies_house_status,
                         b.current_stage_of_evolution,
                         b.number_of_fundraisings_completed_by_the_company,
                         b.total_amount_received_by_the_company_through_fundraisings_gbp,
                         b.date_of_the_companys_latest_fundraising                                       AS date_of_the_last_fundraising,
                         b.company_funders_to_date,
                         b.incorporation_date,
                         b.description,
                         b.date_of_latest_credit_rating_change,
                         b.latest_pre_money_valuation,
                         b.latest_post_money_valuation,
                         b.credit_rating,
                         b.credit_limit_gbp,
                         COALESCE(b.telephone, ''::character varying)                                    AS telephone,
                         COALESCE(b.website, ''::character varying)                                      AS website,
                         (((COALESCE(b.primary_c_suite_contacts_1_first_name, ''::character varying))::text +
                           ' '::text) + (COALESCE(b.primary_c_suite_contacts_1_surname,
                                                  ''::character varying))::text)                         AS contact_name,
                         COALESCE(b.primary_c_suite_contacts_1_first_name, ''::character varying)        AS first_name,
                         COALESCE(b.primary_c_suite_contacts_1_surname, ''::character varying)           AS last_name,
                         COALESCE(b.primary_c_suite_contacts_1_email, ''::character varying)             AS contact_email,
                         COALESCE(b.primary_c_suite_contacts_1_job_title,
                                  ''::character varying)                                                 AS contact_title,
                         opps.cc_funded_count,
                         CASE
                           WHEN (opps.cc_funded_count > 0) THEN 'Yes'::text
                           ELSE 'No'::text END                                                           AS funded_with_crowdcube,
                         opps.cc_gone_live_count,
                         CASE
                           WHEN (opps.cc_gone_live_count > 0) THEN 'Yes'::text
                           ELSE 'No'::text END                                                           AS gone_live_with_crowdcube,
                         opps.sf_opportunity_count,
                         CASE
                           WHEN (opps.sf_opportunity_count > 0) THEN 'Yes'::text
                           ELSE 'No'::text END                                                           AS sf_opportunity,
                         CASE
                           WHEN ((leads.sf_lead_count > 0) OR (leads.id IS NOT NULL)) THEN 'Yes'::text
                           ELSE 'No'::text END                                                           AS sf_lead,
                         COALESCE(leads.record_type_id, ''::character varying)                           AS record_type_id,
                         COALESCE(leads.owner_id, ''::character varying)                                 AS owner_id,
                         COALESCE(leads.marketing_c, ''::character varying)                              AS marketing_notes,
                         COALESCE(leads.bd_manager, ''::character varying)                               AS bd_manager,
                         COALESCE(leads.lead_source, 'Beauhurst'::character varying)                     AS lead_source,
                         COALESCE(leads.status, 'Prospect'::character varying)                           AS status,
                         leads.industry,
                         b.top_level_sectors                                                             AS beauhurst_sectors,
                         date(CASE
                                WHEN (((b.current_stage_of_evolution)::text = 'Seed'::text) OR
                                      ((b.current_stage_of_evolution)::text = 'Venture'::text)) THEN date_add(
                                    'year'::text, (1)::bigint,
                                    (b.date_of_the_companys_latest_fundraising)::timestamp without time zone)
                                WHEN ((b.current_stage_of_evolution)::text = 'Growth'::text) THEN date_add(
                                    'month'::text, (16)::bigint,
                                    (b.date_of_the_companys_latest_fundraising)::timestamp without time zone)
                                ELSE NULL::timestamp without time zone END)                              AS estimated_next_raise_date
                  FROM ((v_distil_sahara_beauhurst_data b LEFT JOIN (SELECT o.opp_id,
                                                                            o.company_number,
                                                                            o.lead_id,
                                                                            o.stage_name,
                                                                            o.rn,
                                                                            os.cc_funded_count,
                                                                            os.cc_gone_live_count,
                                                                            os.sf_opportunity_count
                                                                     FROM ((SELECT o.x18_digit_id_c                                                               AS opp_id,
                                                                                   c.company_reg_number_c                                                         AS company_number,
                                                                                   o.lead_18_id_c                                                                 AS lead_id,
                                                                                   o.stage_name,
                                                                                   pg_catalog.row_number()
                                                                                   OVER ( PARTITION BY c.company_reg_number_c ORDER BY o.last_modified_date DESC) AS rn
                                                                            FROM (sfexperimental.opportunities o
                                                                                   LEFT JOIN sfexperimental.companies c
                                                                                             ON (((c.id)::text = (o.account_18_id_c)::text)))
                                                                            WHERE (((o.is_test_c IS FALSE) AND (o.is_deleted IS FALSE)) AND
                                                                                   ((COALESCE(c.company_reg_number_c, ''::character varying))::text <>
                                                                                    ''::text))) o
                                                                            JOIN (SELECT sfopps.company_number,
                                                                                         sum(CASE
                                                                                               WHEN ((sfopps.stage_name)::text = 'Funded'::text)
                                                                                                 THEN 1
                                                                                               ELSE 0 END) AS cc_funded_count,
                                                                                         sum(CASE
                                                                                               WHEN (
                                                                                                   (((sfopps.stage_name)::text = 'Active'::text) OR
                                                                                                    ((sfopps.stage_name)::text = 'Closed Lost'::text)) OR
                                                                                                   ((sfopps.stage_name)::text = 'Funded'::text))
                                                                                                 THEN 1
                                                                                               ELSE 0 END) AS cc_gone_live_count,
                                                                                         count(*)          AS sf_opportunity_count
                                                                                  FROM (SELECT o.x18_digit_id_c                                                               AS opp_id,
                                                                                               c.company_reg_number_c                                                         AS company_number,
                                                                                               o.lead_18_id_c                                                                 AS lead_id,
                                                                                               o.stage_name,
                                                                                               pg_catalog.row_number()
                                                                                               OVER ( PARTITION BY c.company_reg_number_c ORDER BY o.last_modified_date DESC) AS rn
                                                                                        FROM (sfexperimental.opportunities o
                                                                                               LEFT JOIN sfexperimental.companies c
                                                                                                         ON (((c.id)::text = (o.account_18_id_c)::text)))
                                                                                        WHERE (((o.is_test_c IS FALSE) AND (o.is_deleted IS FALSE)) AND
                                                                                               ((COALESCE(c.company_reg_number_c, ''::character varying))::text <>
                                                                                                ''::text))) sfopps
                                                                                  GROUP BY sfopps.company_number) os
                                                                                 ON (((o.company_number)::text = (os.company_number)::text)))
                                                                     WHERE (o.rn = 1)) opps ON (((b.companies_house_number)::text = (opps.company_number)::text)))
                         LEFT JOIN (SELECT DISTINCT l.id,
                                                    l.company_number,
                                                    l.record_type_id,
                                                    l.owner_id,
                                                    l.marketing_notes,
                                                    l.bd_manager,
                                                    l.lead_source,
                                                    l.status,
                                                    l.industry,
                                                    l.last_modified_date,
                                                    l.marketing_c,
                                                    l.rn,
                                                    ls.sf_lead_count
                                    FROM ((SELECT l.id,
                                                  l.company_reg_number_c                                                         AS company_number,
                                                  l.record_type_id,
                                                  l.owner_id,
                                                  l.marketing_c                                                                  AS marketing_notes,
                                                  COALESCE(bdm.name, ''::character varying)                                      AS bd_manager,
                                                  l.lead_source,
                                                  l.status,
                                                  l.industry,
                                                  l.last_modified_date,
                                                  l.marketing_c,
                                                  pg_catalog.row_number()
                                                  OVER ( PARTITION BY l.company_reg_number_c ORDER BY l.last_modified_date DESC) AS rn
                                           FROM (sfexperimental.leads l
                                                  LEFT JOIN sfexperimental.users bdm
                                                            ON (((l.bd_manager_lookup_c)::text = (bdm.id)::text)))
                                           WHERE ((l.is_test_c IS FALSE) AND (l.is_deleted IS FALSE))) l
                                           LEFT JOIN (SELECT sfleads.company_number, "max"(sfleads.rn) AS sf_lead_count
                                                      FROM (SELECT l.id,
                                                                   l.company_reg_number_c                                                         AS company_number,
                                                                   l.record_type_id,
                                                                   l.owner_id,
                                                                   l.marketing_c                                                                  AS marketing_notes,
                                                                   COALESCE(bdm.name, ''::character varying)                                      AS bd_manager,
                                                                   l.lead_source,
                                                                   l.status,
                                                                   l.industry,
                                                                   l.last_modified_date,
                                                                   l.marketing_c,
                                                                   pg_catalog.row_number()
                                                                   OVER ( PARTITION BY l.company_reg_number_c ORDER BY l.last_modified_date DESC) AS rn
                                                            FROM (sfexperimental.leads l
                                                                   LEFT JOIN sfexperimental.users bdm
                                                                             ON (((l.bd_manager_lookup_c)::text = (bdm.id)::text)))
                                                            WHERE ((l.is_test_c IS FALSE) AND (l.is_deleted IS FALSE))) sfleads
                                                      GROUP BY sfleads.company_number) ls
                                                     ON (((ls.company_number)::text = (l.company_number)::text)))
                                    WHERE (l.rn = 1)) leads
                                   ON ((((b.companies_house_number)::text = (leads.company_number)::text) OR
                                        ((leads.id)::text = (opps.lead_id)::text))))
                  WHERE ((((((b.current_stage_of_evolution)::text = 'Growth'::text) OR
                            ((b.current_stage_of_evolution)::text = 'Venture'::text)) OR
                           ((b.current_stage_of_evolution)::text = 'Seed'::text)) AND
                          (((((((b.companies_house_status)::text <> 'In Liquidation'::text) AND
                               ((b.companies_house_status)::text <> 'Company not trading'::text)) AND
                              ((b.companies_house_status)::text <> 'Non trading'::text)) AND
                             ((b.companies_house_status)::text <> 'Dormant Company'::text)) AND
                            ((b.companies_house_status)::text <> 'In Administration'::text)) AND
                           ((b.companies_house_status)::text <> 'Dissolution (First Gazette)'::text))) AND
                         (COALESCE(b.number_of_fundraisings_completed_by_the_company, 0) > 0))) derived_table1) derived_table2) derived_table3;

alter table v_distil_sahara_beauhurst_raise_prediction
  owner to ccdatawh;

