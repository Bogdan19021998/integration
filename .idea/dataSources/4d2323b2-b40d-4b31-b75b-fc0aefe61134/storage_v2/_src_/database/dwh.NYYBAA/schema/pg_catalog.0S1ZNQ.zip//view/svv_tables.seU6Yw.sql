create view svv_tables as
  SELECT (current_database())::character varying(128) AS table_catalog,
         (nc.nspname)::character varying(128)         AS table_schema,
         (c.relname)::character varying(128)          AS table_name,
         (CASE
            WHEN (nc.nspname ~~ like_escape('pg!_temp!_%'::text, '!'::text)) THEN 'LOCAL TEMPORARY'::text
            WHEN (c.relkind = 'r'::"char") THEN 'BASE TABLE'::text
            WHEN (c.relkind = 'v'::"char") THEN 'VIEW'::text
            ELSE NULL::text END)::character varying   AS table_type,
         (d.description)::character varying           AS remarks
  FROM (((pg_namespace nc JOIN pg_class c ON ((c.relnamespace = nc.oid))) JOIN pg_user u ON ((u.usesysid = c.relowner)))
         LEFT JOIN pg_description d ON (((c.oid = d.objoid) AND (d.objsubid = 0))))
  WHERE ((c.relkind = 'r'::"char") OR (c.relkind = 'v'::"char"))
  UNION ALL
  SELECT (current_database())::character varying(128) AS table_catalog,
         svv_external_tables.schemaname               AS table_schema,
         svv_external_tables.tablename                AS table_name,
         'EXTERNAL TABLE'                             AS table_type,
         NULL::"unknown"                              AS remarks
  FROM svv_external_tables;

alter table svv_tables
  owner to rdsdb;

