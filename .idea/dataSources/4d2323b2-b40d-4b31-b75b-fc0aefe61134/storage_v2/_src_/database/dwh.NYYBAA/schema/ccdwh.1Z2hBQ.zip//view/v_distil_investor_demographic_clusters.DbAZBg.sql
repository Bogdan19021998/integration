create view v_distil_investor_demographic_clusters as
SELECT fact_user_cluster_assignment.user_key,
       CASE
         WHEN ((fact_user_cluster_assignment.cluster_id)::text = 'cluster_5'::text) THEN 'High Top'::text
         WHEN (((((fact_user_cluster_assignment.cluster_id)::text = 'cluster_0'::text) OR
                 ((fact_user_cluster_assignment.cluster_id)::text = 'cluster_1'::text)) OR
                ((fact_user_cluster_assignment.cluster_id)::text = 'cluster_11'::text)) OR
               ((fact_user_cluster_assignment.cluster_id)::text = 'cluster_12'::text)) THEN 'Top'::text
         WHEN (((((fact_user_cluster_assignment.cluster_id)::text = 'cluster_7'::text) OR
                 ((fact_user_cluster_assignment.cluster_id)::text = 'cluster_8'::text)) OR
                ((fact_user_cluster_assignment.cluster_id)::text = 'cluster_9'::text)) OR
               ((fact_user_cluster_assignment.cluster_id)::text = 'cluster_10'::text)) THEN 'Middle'::text
         WHEN (((((((fact_user_cluster_assignment.cluster_id)::text = 'cluster_4'::text) OR
                   ((fact_user_cluster_assignment.cluster_id)::text = 'cluster_14'::text)) OR
                  ((fact_user_cluster_assignment.cluster_id)::text = 'cluster_13'::text)) OR
                 ((fact_user_cluster_assignment.cluster_id)::text = 'cluster_2'::text)) OR
                ((fact_user_cluster_assignment.cluster_id)::text = 'cluster_6'::text)) OR
               ((fact_user_cluster_assignment.cluster_id)::text = 'cluster_3'::text)) THEN 'Lower '::text
         ELSE 'Unknown'::text END              AS demographic_cluster,
       fact_user_cluster_assignment.cluster_id AS raw_cluster
FROM fact_user_cluster_assignment
ORDER BY fact_user_cluster_assignment.user_key DESC;

alter table v_distil_investor_demographic_clusters
  owner to ccdatawh;

