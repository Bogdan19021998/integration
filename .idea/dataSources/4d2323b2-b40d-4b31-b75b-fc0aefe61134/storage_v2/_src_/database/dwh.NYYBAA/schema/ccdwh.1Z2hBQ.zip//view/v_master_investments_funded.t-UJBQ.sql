create view v_master_investments_funded as
SELECT pi.investment_id,
       pi.transaction_id,
       pi.investment_date_key,
       pi.investment_timestamp,
       pi.update_date_key,
       pi.update_timestamp,
       pi.pitch_key,
       pi.user_key,
       pi.amount,
       pi.currency_iso_code,
       pi.currency_symbol,
       pi.exchange_rate_to_gbp,
       pi.payment_method,
       pi.amount_in_gbp,
       pi.investor_count_key,
       pi.pitch_progress_key,
       pi.remaining_timespan_key,
       pi.session_key,
       pi.investment_status,
       pi.fee_percentage,
       pi.fee_amount,
       pi.investment_source
FROM (fact_pitch_investments pi
       JOIN v_master_pitches_latest p ON ((p.pitch_key = pi.pitch_key)))
WHERE (((((pi.investment_status)::text <> 'cancelled'::text) AND ((pi.investment_status)::text <> 'refunded'::text)) AND
        ((pi.investment_status)::text <> 'expired'::text)) AND ((p.pitch_status)::text = 'Funded'::text));

alter table v_master_investments_funded
  owner to ccdatawh;

