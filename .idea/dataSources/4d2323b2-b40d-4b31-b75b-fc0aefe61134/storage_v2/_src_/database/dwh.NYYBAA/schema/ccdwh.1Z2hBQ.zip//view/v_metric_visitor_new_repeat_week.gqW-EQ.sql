create view v_metric_visitor_new_repeat_week as
SELECT y.year_calendar_week,
       y.num_new_week,
       (y.num_unique_visitors - y.num_new_week) AS num_repeat_visitors,
       y.num_unique_visitors
FROM (SELECT x.year_calendar_week, sum(x.num_new) AS num_new_week, x.num_unique_visitors
      FROM (SELECT dt.date_key,
                   dt.year_calendar_week,
                   count(DISTINCT ds.anonymousid) AS num_new,
                   vis.num_unique_visitors
            FROM ((dim_dates dt LEFT JOIN (SELECT DISTINCT s.anonymousid, min(s.session_start_date_key) AS first_session
                                           FROM dim_sessions s
                                           GROUP BY s.anonymousid) ds ON ((dt.date_key = ds.first_session)))
                   LEFT JOIN (SELECT v_metric_unique_visitors_week.year_calendar_week,
                                     v_metric_unique_visitors_week.num_unique_visitors
                              FROM v_metric_unique_visitors_week) vis
                             ON (((dt.year_calendar_week)::text = (vis.year_calendar_week)::text)))
            WHERE (dt.the_date < ('now'::text)::date)
            GROUP BY dt.date_key, vis.num_unique_visitors, dt.year_calendar_week
            ORDER BY dt.date_key, dt.year_calendar_week DESC) x
      GROUP BY x.year_calendar_week, x.num_unique_visitors
      ORDER BY x.year_calendar_week DESC) y
ORDER BY y.year_calendar_week DESC;

alter table v_metric_visitor_new_repeat_week
  owner to ccdatawh;

