create view v_metric_pitches_funded_by_date as
SELECT dt.the_date,
       CASE WHEN (ds.num_closed IS NULL) THEN (0)::bigint ELSE ds.num_closed END                            AS num_closed,
       CASE
         WHEN (ds.pitches_closed IS NULL) THEN 'None'::character varying
         ELSE ds.pitches_closed END                                                                         AS pitches_closed,
       CASE
         WHEN (ds.number_investments IS NULL) THEN (0)::bigint
         ELSE ds.number_investments END                                                                     AS number_investments,
       CASE
         WHEN (ds.final_investment_amount IS NULL) THEN (0)::numeric
         ELSE ds.final_investment_amount END                                                                AS investment_reached_amount_gbp
FROM (v_master_dates dt
       LEFT JOIN (SELECT CASE
                           WHEN (((((pc.pitch_key = 21376) OR (pc.pitch_key = 21408)) OR (pc.pitch_key = 21343)) OR
                                  (pc.pitch_key = 21314)) OR (pc.pitch_key = 21431)) THEN (pc.closed_date_key - 1)
                           ELSE pc.closed_date_key END               AS closed_date,
                         count(*)                                    AS num_closed,
                         sum(pc.investor_count)                      AS number_investments,
                         sum(pc.reached_amount)                      AS final_investment_amount,
                         pg_catalog.listagg((pc.pitch_name)::text, ', '::text)
                         WITHIN GROUP ( ORDER BY pc.pitch_name DESC) AS pitches_closed
                  FROM v_master_pitches_latest pc
                  WHERE ((((pc.pitch_status)::text = 'Funded'::text) OR
                          ((pc.pitch_status)::text = 'Active Hidden Private'::text)) AND (NOT (pc.pitch_key IN
                                                                                               (SELECT fact_test_pitch_exclude.pitch_key
                                                                                                FROM fact_test_pitch_exclude))))
                  GROUP BY pc.closed_date_key, pc.pitch_key) ds ON ((dt.date_key = ds.closed_date)))
ORDER BY dt.the_date DESC;

alter table v_metric_pitches_funded_by_date
  owner to ccdatawh;

