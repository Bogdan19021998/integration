create view v_distil_investors as
SELECT ds1.user_key,
       ds1.encrypted_user_id,
       ds1.firstname,
       ds1.lastname,
       ds1.email,
       ds1.fullname,
       ds4.chronotype,
       ds1.address_town,
       ds1.address_county,
       ds1.address_postcode,
       ds1.address_country,
       ds1.gender,
       ds1.investor_category_selfcertified,
       ds1.investor_category_from_behaviour,
       ds1.aml_status_checked_count,
       ds1.aml_status_last_interpreted_result,
       ds1.active_user,
       ds1.pitch_owner_type,
       ds1.selligent_active_user,
       ds1.subscribed_marketing,
       CASE
         WHEN (ds1.registered_days_ago <= 7) THEN 7
         WHEN (ds1.registered_days_ago <= 30) THEN 30
         WHEN (ds1.registered_days_ago <= 60) THEN 60
         WHEN (ds1.registered_days_ago <= 90) THEN 90
         WHEN (ds1.registered_days_ago <= 365) THEN 365
         ELSE 1000 END                                                                                                AS registered_days_ago,
       ds1.portal,
       CASE
         WHEN (ds5.demographic_cluster IS NULL) THEN 'Unknown'::text
         ELSE ds5.demographic_cluster END                                                                             AS demographic_cluster,
       CASE
         WHEN (ds5.raw_cluster IS NULL) THEN 'Unknown'::character varying
         ELSE ds5.raw_cluster END                                                                                     AS demographic_cluster_raw,
       ds2.first_investment,
       ds2.last_investment,
       CASE
         WHEN (ds2.last_investment_days_ago <= 7) THEN 7
         WHEN (ds2.last_investment_days_ago <= 30) THEN 30
         WHEN (ds2.last_investment_days_ago <= 60) THEN 60
         WHEN (ds2.last_investment_days_ago <= 90) THEN 90
         WHEN (ds2.last_investment_days_ago <= 365) THEN 365
         ELSE 1000 END                                                                                                AS last_investment_days_ago,
       ds2.number_investments,
       ds2.value_investment,
       ds2.number_investments_live,
       ds2.value_investment_live,
       ds2.number_investments_paid,
       ds2.value_investment_paid,
       ds2.number_investments_unsuccessful,
       ds2.value_investment_unsuccessful,
       ds2.smallest_investment,
       ds2.largest_investment,
       ds2.avg_investment,
       ds2.web_investment_count,
       ds2.ios_investment_count,
       ds2.android_investment_count,
       ds2.value_last_5_web,
       ds2.value_last_5_ios,
       ds2.value_last_5_android,
       ds2.last_5_preffered_investment_platform,
       CASE
         WHEN (ds2.investment_automotive IS NULL) THEN (0)::numeric
         ELSE ds2.investment_automotive END                                                                           AS investment_automotive,
       CASE
         WHEN (ds2.investment_business_services IS NULL) THEN (0)::numeric
         ELSE ds2.investment_business_services END                                                                    AS investment_business_services,
       CASE
         WHEN (ds2.investment_clean_technology IS NULL) THEN (0)::numeric
         ELSE ds2.investment_clean_technology END                                                                     AS investment_clean_technology,
       CASE
         WHEN (ds2.investment_consumer_goods IS NULL) THEN (0)::numeric
         ELSE ds2.investment_consumer_goods END                                                                       AS investment_consumer_goods,
       CASE
         WHEN (ds2.investment_consumer_internet IS NULL) THEN (0)::numeric
         ELSE ds2.investment_consumer_internet END                                                                    AS investment_consumer_internet,
       CASE
         WHEN (ds2.investment_education IS NULL) THEN (0)::numeric
         ELSE ds2.investment_education END                                                                            AS investment_education,
       CASE
         WHEN (ds2.investment_entertainment_and_media IS NULL) THEN (0)::numeric
         ELSE ds2.investment_entertainment_and_media END                                                              AS investment_entertainment_and_media,
       CASE
         WHEN (ds2.investment_fintech IS NULL) THEN (0)::numeric
         ELSE ds2.investment_fintech END                                                                              AS investment_fintech,
       CASE
         WHEN (ds2.investment_fitness_and_sports IS NULL) THEN (0)::numeric
         ELSE ds2.investment_fitness_and_sports END                                                                   AS investment_fitness_and_sports,
       CASE
         WHEN (ds2.investment_food_and_beverage IS NULL) THEN (0)::numeric
         ELSE ds2.investment_food_and_beverage END                                                                    AS investment_food_and_beverage,
       CASE
         WHEN (ds2.investment_healthtech_and_healthcare IS NULL) THEN (0)::numeric
         ELSE ds2.investment_healthtech_and_healthcare END                                                            AS investment_healthtech_and_healthcare,
       CASE
         WHEN (ds2.investment_infrastructure IS NULL) THEN (0)::numeric
         ELSE ds2.investment_infrastructure END                                                                       AS investment_infrastructure,
       CASE
         WHEN (ds2.investment_it_telecommunications IS NULL) THEN (0)::numeric
         ELSE ds2.investment_it_telecommunications END                                                                AS investment_it_telecommunications,
       CASE
         WHEN (ds2.investment_leisure_and_tourism IS NULL) THEN (0)::numeric
         ELSE ds2.investment_leisure_and_tourism END                                                                  AS investment_leisure_and_tourism,
       CASE
         WHEN (ds2.investment_life_sciences_and_biotech IS NULL) THEN (0)::numeric
         ELSE ds2.investment_life_sciences_and_biotech END                                                            AS investment_life_sciences_and_biotech,
       CASE
         WHEN (ds2.investment_manufacturing IS NULL) THEN (0)::numeric
         ELSE ds2.investment_manufacturing END                                                                        AS investment_manufacturing,
       CASE
         WHEN (ds2.investment_restaurants_cafes_bars IS NULL) THEN (0)::numeric
         ELSE ds2.investment_restaurants_cafes_bars END                                                               AS investment_restaurants_cafes_bars,
       CASE
         WHEN (ds6.investment_crowdcube_count IS NULL) THEN (0)::bigint
         ELSE ds6.investment_crowdcube_count END                                                                      AS investment_crowdcube_count,
       CASE
         WHEN (ds6.investment_crowdcube_value IS NULL) THEN (0)::numeric
         ELSE ds6.investment_crowdcube_value END                                                                      AS investment_crowdcube_value
FROM ((((v_distil_investor_entity_user_details ds1 LEFT JOIN v_distil_investor_entity_investment_stats ds2 ON ((ds1.user_key = ds2.user_key))) LEFT JOIN v_distil_investor_entity_chronotype_classifications ds4 ON ((ds1.user_key = ds4.user_key))) LEFT JOIN v_distil_investor_demographic_clusters ds5 ON ((ds1.user_key = ds5.user_key)))
       LEFT JOIN v_distil_investor_entity_crowdcube_investment ds6 ON ((ds1.user_key = ds6.user_key)));

alter table v_distil_investors
  owner to ccdatawh;

