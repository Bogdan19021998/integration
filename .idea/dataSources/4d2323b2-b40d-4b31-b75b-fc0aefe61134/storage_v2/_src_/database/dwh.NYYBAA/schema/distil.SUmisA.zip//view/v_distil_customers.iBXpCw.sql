create view v_distil_customers as
SELECT s.user_key                                                                                                AS id,
       s.user_firstname                                                                                          AS first_name,
       s.user_lastname                                                                                           AS last_name,
       s.user_email                                                                                              AS email_address,
       s.telephone                                                                                               AS mobile_phone_no,
       s.subscribed_newsletter                                                                                   AS gdpr_status_subscribed,
       s.selligent_active_user,
       NULL::"unknown"                                                                                           AS gdpr_status_right_of_access_requested,
       CASE
         WHEN (gf.created_at < ('now'::character varying)::timestamp with time zone) THEN true
         ELSE false END                                                                                          AS gdpr_anonymise_data,
       NULL::"unknown"                                                                                           AS facebook_slug,
       NULL::"unknown"                                                                                           AS twitter_handle,
       NULL::"unknown"                                                                                           AS instagram_slug,
       NULL::"unknown"                                                                                           AS linkedin_slug,
       s.private_address_address_1                                                                               AS postal_address_line_1,
       s.private_address_address_2                                                                               AS postal_address_line_2,
       s.private_address_town                                                                                    AS postal_address_line_town,
       s.private_address_county                                                                                  AS postal_address_region,
       s.private_address_country                                                                                 AS postal_address_country,
       s.private_address_post_code                                                                               AS postal_address_postal_code,
       s.private_address_address_1                                                                               AS billing_address_line_1,
       s.private_address_address_2                                                                               AS billing_address_line_2,
       s.private_address_town                                                                                    AS billing_address_line_town,
       s.private_address_county                                                                                  AS billing_address_region,
       s.private_address_country                                                                                 AS billing_address_country,
       s.private_address_post_code                                                                               AS billing_address_postal_code,
       pp.pitch_key                                                                                              AS associated_pitch_id,
       pp.pitch_name                                                                                             AS associated_pitch_name,
       pp.pitch_launch_probability                                                                               AS associated_pitch_launch_probability,
       pp.pitch_launch_probability_confidence                                                                    AS associated_pitch_launch_probability_confidence,
       ist.first_investment,
       ist.last_investment,
       ist.number_investments,
       ist.value_investment,
       ist.smallest_investment,
       ist.largest_investment,
       ist.avg_investment,
       ist.web_investment_count,
       ist.ios_investment_count,
       ist.android_investment_count,
       ist.value_last_5_web,
       ist.value_last_5_ios,
       ist.value_last_5_android,
       ist.last_5_preffered_investment_platform
FROM (((v_master_users_latest s LEFT JOIN gdpr_forget gf ON ((s.user_key = gf.user_key))) LEFT JOIN experimental.v_distil_pitch_prob_to_cust pp ON (((pp.customer_external_id)::text = (s.user_key)::text)))
       LEFT JOIN v_distil_investor_entity_investment_stats ist ON ((ist.user_key = s.user_key)))
ORDER BY s.user_key DESC;

alter table v_distil_customers
  owner to neil_stoneman;

