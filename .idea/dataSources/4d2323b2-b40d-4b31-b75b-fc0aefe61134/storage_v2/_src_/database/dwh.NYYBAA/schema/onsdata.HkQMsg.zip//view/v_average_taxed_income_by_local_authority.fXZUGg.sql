create view v_average_taxed_income_by_local_authority as
SELECT p.pcd, i.mean_total_income
FROM (onsdata.onspd p
       LEFT JOIN ((SELECT DISTINCT p.pcd, i.mean_total_income
                   FROM (onsdata.income_and_tax_borough_district i
                          JOIN onsdata.onspd p ON (((i.geographical_code)::text = (p.oslaua)::text)))
                   WHERE ("left"((i.geographical_code)::text, 1) = 'S'::text)
                   UNION ALL
                   SELECT DISTINCT p.pcd, i.mean_total_income
                   FROM (onsdata.income_and_tax_borough_district i
                          JOIN onsdata.onspd p ON (((i.geographical_code)::text = "left"((p.casward)::text, 4))))
                   WHERE (len((i.geographical_code)::text) = 4))
                  UNION ALL
                  SELECT DISTINCT p.pcd, i.mean_total_income
                  FROM (onsdata.income_and_tax_borough_district i
                         JOIN onsdata.onspd p ON (((i.geographical_code)::text = (p.oslaua)::text)))
                  WHERE (("left"((i.geographical_code)::text, 1) = 'E'::text) OR
                         ("left"((i.geographical_code)::text, 1) = 'W'::text))) i ON (((p.pcd)::text = (i.pcd)::text)));

alter table v_average_taxed_income_by_local_authority
  owner to ccdatawh;

