create view v_running_queries as
SELECT derived_table1.pid,
       derived_table1.btrim,
       derived_table1.starttime,
       (derived_table1.duration_sec / 3600)                                        AS hours,
       ((derived_table1.duration_sec - (derived_table1.duration_sec / 3600)) / 60) AS minutes,
       (derived_table1.duration_sec - ((derived_table1.duration_sec / 60) * 60))   AS seconds,
       derived_table1.query
FROM (SELECT stv_recents.pid,
             btrim(((stv_recents.user_name)::character varying)::text)                   AS btrim,
             stv_recents.starttime,
             date_diff(('s'::character varying)::text, stv_recents.starttime, getdate()) AS duration_sec,
             stv_recents.query
      FROM stv_recents
      WHERE (stv_recents.status = 'Running'::bpchar)
      ORDER BY stv_recents.duration DESC) derived_table1;

alter table v_running_queries
  owner to ccdatawh;

