create function "_pg_keysequal"(smallint[], smallint[]) returns boolean
  immutable
  language sql
as
$$
select information_schema._pg_keyissubset($1, $2) and information_schema._pg_keyissubset($2, $1)
$$;

