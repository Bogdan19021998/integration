create view v_monthly_investors_split_by_product_and_success as
SELECT a.year_month,
       a.attempted_equity_investments,
       a.attempted_equity_investment_amount,
       a.attempted_equity_investors,
       b.attempted_bond_investments,
       b.attempted_bond_investment_amount,
       b.attempted_bond_investors,
       c.successful_equity_investments,
       c.successful_equity_investment_amount,
       c.successful_equity_investors,
       d.successful_bond_investments,
       d.successful_bond_investment_amount,
       d.successful_bond_investors,
       e.attempted_total_investments,
       e.attempted_total_investment_amount,
       e.attempted_total_investors,
       f.successful_total_investments,
       f.successful_total_investment_amount,
       f.successful_total_investors
FROM ((((((SELECT d.year_month,
                  count(pi.user_key)          AS attempted_equity_investments,
                  sum(pi.amount)              AS attempted_equity_investment_amount,
                  count(DISTINCT pi.user_key) AS attempted_equity_investors
           FROM dim_users_static us,
                dim_dates d,
                fact_pitch_investments pi,
                dim_pitches_static ps,
                dim_pitches_changing pc
           WHERE ((((((((pi.pitch_key = ps.pitch_key) AND (pi.pitch_key = pc.pitch_key)) AND (pc.snapshot_date_key =
                                                                                              (SELECT dim_dates.date_key
                                                                                               FROM dim_dates
                                                                                               WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
                      ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND
                     ((ps.product_type)::text = ('Equity'::character varying)::text)) AND
                    (pi.user_key = us.user_key)) AND (pi.investment_date_key = d.date_key)) AND
                  ((us.portal)::text = ('crowdcube'::character varying)::text))
           GROUP BY d.year_month) a LEFT JOIN (SELECT d.year_month,
                                                      count(pi.user_key)          AS attempted_bond_investments,
                                                      sum(pi.amount)              AS attempted_bond_investment_amount,
                                                      count(DISTINCT pi.user_key) AS attempted_bond_investors
                                               FROM dim_users_static us,
                                                    dim_dates d,
                                                    fact_pitch_investments pi,
                                                    dim_pitches_static ps,
                                                    dim_pitches_changing pc
                                               WHERE ((((((((pi.pitch_key = ps.pitch_key) AND (pi.pitch_key = pc.pitch_key)) AND
                                                           (pc.snapshot_date_key = (SELECT dim_dates.date_key
                                                                                    FROM dim_dates
                                                                                    WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
                                                          ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND
                                                         ((ps.product_type)::text = ('Bonds'::character varying)::text)) AND
                                                        (pi.user_key = us.user_key)) AND
                                                       (pi.investment_date_key = d.date_key)) AND
                                                      ((us.portal)::text = ('crowdcube'::character varying)::text))
                                               GROUP BY d.year_month) b ON (((a.year_month)::text = (b.year_month)::text))) LEFT JOIN (SELECT d.year_month,
                                                                                                                                              count(pi.user_key)          AS successful_equity_investments,
                                                                                                                                              sum(pi.amount)              AS successful_equity_investment_amount,
                                                                                                                                              count(DISTINCT pi.user_key) AS successful_equity_investors
                                                                                                                                       FROM dim_users_static us,
                                                                                                                                            dim_dates d,
                                                                                                                                            fact_pitch_investments pi,
                                                                                                                                            dim_pitches_static ps,
                                                                                                                                            dim_pitches_changing pc
                                                                                                                                       WHERE ((((((((((pi.pitch_key = ps.pitch_key) AND (pi.pitch_key = pc.pitch_key)) AND
                                                                                                                                                     (pc.snapshot_date_key =
                                                                                                                                                      (SELECT dim_dates.date_key
                                                                                                                                                       FROM dim_dates
                                                                                                                                                       WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
                                                                                                                                                    ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND
                                                                                                                                                   ((ps.product_type)::text = ('Equity'::character varying)::text)) AND
                                                                                                                                                  (pi.user_key = us.user_key)) AND
                                                                                                                                                 (pi.investment_date_key = d.date_key)) AND
                                                                                                                                                ((pi.investment_status)::text <>
                                                                                                                                                 ('cancelled'::character varying)::text)) AND
                                                                                                                                               ((pc.pitch_status)::text = ('Funded'::character varying)::text)) AND
                                                                                                                                              ((us.portal)::text = ('crowdcube'::character varying)::text))
                                                                                                                                       GROUP BY d.year_month
                                                                                                                                       ORDER BY d.year_month) c ON (((a.year_month)::text = (c.year_month)::text))) LEFT JOIN (SELECT d.year_month,
                                                                                                                                                                                                                                      count(pi.user_key)          AS successful_bond_investments,
                                                                                                                                                                                                                                      sum(pi.amount)              AS successful_bond_investment_amount,
                                                                                                                                                                                                                                      count(DISTINCT pi.user_key) AS successful_bond_investors
                                                                                                                                                                                                                               FROM dim_users_static us,
                                                                                                                                                                                                                                    dim_dates d,
                                                                                                                                                                                                                                    fact_pitch_investments pi,
                                                                                                                                                                                                                                    dim_pitches_static ps,
                                                                                                                                                                                                                                    dim_pitches_changing pc
                                                                                                                                                                                                                               WHERE ((((((((((pi.pitch_key = ps.pitch_key) AND (pi.pitch_key = pc.pitch_key)) AND
                                                                                                                                                                                                                                             (pc.snapshot_date_key =
                                                                                                                                                                                                                                              (SELECT dim_dates.date_key
                                                                                                                                                                                                                                               FROM dim_dates
                                                                                                                                                                                                                                               WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
                                                                                                                                                                                                                                            ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND
                                                                                                                                                                                                                                           ((ps.product_type)::text = ('Bonds'::character varying)::text)) AND
                                                                                                                                                                                                                                          (pi.user_key = us.user_key)) AND
                                                                                                                                                                                                                                         (pi.investment_date_key = d.date_key)) AND
                                                                                                                                                                                                                                        ((pi.investment_status)::text <>
                                                                                                                                                                                                                                         ('cancelled'::character varying)::text)) AND
                                                                                                                                                                                                                                       ((pc.pitch_status)::text = ('Funded'::character varying)::text)) AND
                                                                                                                                                                                                                                      ((us.portal)::text = ('crowdcube'::character varying)::text))
                                                                                                                                                                                                                               GROUP BY d.year_month
                                                                                                                                                                                                                               ORDER BY d.year_month) d ON (((a.year_month)::text = (d.year_month)::text))) LEFT JOIN (SELECT d.year_month,
                                                                                                                                                                                                                                                                                                                              count(pi.user_key)          AS attempted_total_investments,
                                                                                                                                                                                                                                                                                                                              sum(pi.amount)              AS attempted_total_investment_amount,
                                                                                                                                                                                                                                                                                                                              count(DISTINCT pi.user_key) AS attempted_total_investors
                                                                                                                                                                                                                                                                                                                       FROM dim_users_static us,
                                                                                                                                                                                                                                                                                                                            dim_dates d,
                                                                                                                                                                                                                                                                                                                            fact_pitch_investments pi,
                                                                                                                                                                                                                                                                                                                            dim_pitches_static ps,
                                                                                                                                                                                                                                                                                                                            dim_pitches_changing pc
                                                                                                                                                                                                                                                                                                                       WHERE (((((((pi.pitch_key = ps.pitch_key) AND (pi.pitch_key = pc.pitch_key)) AND
                                                                                                                                                                                                                                                                                                                                  (pc.snapshot_date_key =
                                                                                                                                                                                                                                                                                                                                   (SELECT dim_dates.date_key
                                                                                                                                                                                                                                                                                                                                    FROM dim_dates
                                                                                                                                                                                                                                                                                                                                    WHERE ((dim_dates.year_month)::text =
                                                                                                                                                                                                                                                                                                                                           ((('now'::character varying)::date)::character varying)::text)))) AND
                                                                                                                                                                                                                                                                                                                                 ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND
                                                                                                                                                                                                                                                                                                                                (pi.user_key = us.user_key)) AND
                                                                                                                                                                                                                                                                                                                               (pi.investment_date_key = d.date_key)) AND
                                                                                                                                                                                                                                                                                                                              ((us.portal)::text = ('crowdcube'::character varying)::text))
                                                                                                                                                                                                                                                                                                                       GROUP BY d.year_month) e ON (((a.year_month)::text = (e.year_month)::text)))
       LEFT JOIN (SELECT d.year_month,
                         count(pi.user_key)          AS successful_total_investments,
                         sum(pi.amount)              AS successful_total_investment_amount,
                         count(DISTINCT pi.user_key) AS successful_total_investors
                  FROM dim_users_static us,
                       dim_dates d,
                       fact_pitch_investments pi,
                       dim_pitches_static ps,
                       dim_pitches_changing pc
                  WHERE (((((((((pi.pitch_key = ps.pitch_key) AND (pi.pitch_key = pc.pitch_key)) AND
                               (pc.snapshot_date_key = (SELECT dim_dates.date_key
                                                        FROM dim_dates
                                                        WHERE ((dim_dates.year_month)::text =
                                                               ((('now'::character varying)::date)::character varying)::text)))) AND
                              ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND
                             (pi.user_key = us.user_key)) AND (pi.investment_date_key = d.date_key)) AND
                           ((pi.investment_status)::text <> ('cancelled'::character varying)::text)) AND
                          ((pc.pitch_status)::text = ('Funded'::character varying)::text)) AND
                         ((us.portal)::text = ('crowdcube'::character varying)::text))
                  GROUP BY d.year_month
                  ORDER BY d.year_month) f ON (((a.year_month)::text = (f.year_month)::text)))
ORDER BY a.year_month;

alter table v_monthly_investors_split_by_product_and_success
  owner to ccdatawh;

