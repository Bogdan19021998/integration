create view v_session_rolling_30_day_average as
SELECT count_of_c.session_start_date_key AS the_date,
       count_of_c.count_of_sessions,
       calc_ave.rolling_avg_30_day_sessions
FROM (((SELECT dim_sessions.session_start_date_key, count(*) AS count_of_sessions
        FROM dim_sessions
        GROUP BY dim_sessions.session_start_date_key) count_of_c JOIN (SELECT tbl1.session_start_date_key,
                                                                              avg(tbl2.count_of_sessions) AS rolling_avg_30_day_sessions
                                                                       FROM ((SELECT dim_sessions.session_start_date_key,
                                                                                     count(*) AS count_of_sessions
                                                                              FROM dim_sessions
                                                                              GROUP BY dim_sessions.session_start_date_key
                                                                              ORDER BY dim_sessions.session_start_date_key)
                                                                             tbl1
                                                                              JOIN (SELECT s.session_start_date_key, count(*) AS count_of_sessions
                                                                                    FROM (dim_sessions s
                                                                                           JOIN (SELECT dim_dates.date_key
                                                                                                 FROM dim_dates
                                                                                                 WHERE (dim_dates.the_date = ('now'::character varying)::date)) cdate_1
                                                                                                ON ((s.session_start_date_key < cdate_1.date_key)))
                                                                                    GROUP BY s.session_start_date_key
                                                                                    ORDER BY s.session_start_date_key) tbl2
                                                                                   ON ((tbl2.session_start_date_key > (tbl1.session_start_date_key - 30))))
                                                                       GROUP BY tbl1.session_start_date_key
                                                                       ORDER BY tbl1.session_start_date_key) calc_ave ON ((calc_ave.session_start_date_key = count_of_c.session_start_date_key)))
       JOIN (SELECT dim_dates.date_key
             FROM dim_dates
             WHERE (dim_dates.the_date = ('now'::character varying)::date)) cdate2
            ON (((count_of_c.session_start_date_key > (cdate2.date_key - 30)) AND
                 (count_of_c.session_start_date_key <= cdate2.date_key))))
ORDER BY count_of_c.session_start_date_key;

alter table v_session_rolling_30_day_average
  owner to ccdatawh;

