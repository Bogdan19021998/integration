create view v_band_economic_activity as
SELECT ds.pcd,
       ds.perc_economically_active,
       onsdata.f_percent_band(ds.perc_economically_active, 6)                              AS economically_active_band,
       ds.perc_active_employee_part_time,
       onsdata.f_percent_band(ds.perc_active_employee_part_time, 6)                        AS active_employee_part_time_band,
       ds.perc__active_employee_full_time,
       onsdata.f_percent_band(ds.perc__active_employee_full_time, 6)                       AS active_employee_full_time_band,
       ds.perc_active_self_employed_part_time_with_employees,
       onsdata.f_percent_band(ds.perc_active_self_employed_part_time_with_employees,
                              6)                                                           AS active_self_employed_part_time_with_employees_band,
       ds.perc_active_self_employed_full_time_with_employees,
       onsdata.f_percent_band(ds.perc_active_self_employed_full_time_with_employees,
                              6)                                                           AS active_self_employed_full_time_with_employees_band,
       ds.perc_active_self_employed_part_time_without_employees,
       onsdata.f_percent_band(ds.perc_active_self_employed_part_time_without_employees,
                              6)                                                           AS active_self_employed_part_time_without_employees_band,
       ds.perc_active_self_employed_full_time_without_employees,
       onsdata.f_percent_band(ds.perc_active_self_employed_full_time_without_employees,
                              6)                                                           AS active_self_employed_full_time_without_employees_band,
       ds.perc_active_unemployed,
       onsdata.f_percent_band(ds.perc_active_unemployed, 6)                                AS active_unemployed_band,
       ds.perc_active_student_full,
       onsdata.f_percent_band(ds.perc_active_student_full, 6)                              AS active_student_full,
       ds.perc_economically_inactive,
       onsdata.f_percent_band(ds.perc_economically_inactive, 6)                            AS economically_inactive_band,
       ds.perc_inactive_retired,
       onsdata.f_percent_band(ds.perc_inactive_retired, 6)                                 AS inactive_retired_band,
       ds.perc_inactive_student_inclu_full_time,
       onsdata.f_percent_band(ds.perc_inactive_student_inclu_full_time, 6)                 AS inactive_student_inclu_full_time_band,
       ds.perc_inactive_looking_after_home_or_family,
       onsdata.f_percent_band(ds.perc_inactive_looking_after_home_or_family,
                              6)                                                           AS inactive_looking_after_home_or_family_band,
       ds.perc_inactive_long_term_sick_or_disabled,
       onsdata.f_percent_band(ds.perc_inactive_long_term_sick_or_disabled,
                              6)                                                           AS inactive_long_term_sick_or_disabled_band,
       ds.perc_inactive_other,
       onsdata.f_percent_band(ds.perc_inactive_other, 6)                                   AS inactive_other_band
FROM (SELECT (upper("replace"(btrim((onspd.pcd)::text), ' '::text, ''::text)))::character varying(8) AS pcd,
             ((economic_activity.economically_active_total)::double precision /
              ((economic_activity.economically_inactive_total +
                economic_activity.economically_active_total))::double precision)                     AS perc_economically_active,
             ((economic_activity.economically_active_employee_part_time)::double precision /
              (economic_activity.economically_active_total)::double precision)                       AS perc_active_employee_part_time,
             ((economic_activity.economically_active_employee_full_time)::double precision /
              (economic_activity.economically_active_total)::double precision)                       AS perc__active_employee_full_time,
             ((economic_activity.economically_active_self_employed_part_time_with_employees)::double precision /
              (economic_activity.economically_active_total)::double precision)                       AS perc_active_self_employed_part_time_with_employees,
             ((economic_activity.economically_active_self_employed_full_time_with_employees)::double precision /
              (economic_activity.economically_active_total)::double precision)                       AS perc_active_self_employed_full_time_with_employees,
             ((economic_activity.economically_active_self_employed_part_time_without_employees)::double precision /
              (economic_activity.economically_active_total)::double precision)                       AS perc_active_self_employed_part_time_without_employees,
             ((economic_activity.economically_active_self_employed_full_time_without_employees)::double precision /
              (economic_activity.economically_active_total)::double precision)                       AS perc_active_self_employed_full_time_without_employees,
             ((economic_activity.economically_active_unemployed)::double precision /
              (economic_activity.economically_active_total)::double precision)                       AS perc_active_unemployed,
             ((economic_activity.economically_active_student_full_time)::double precision /
              (economic_activity.economically_active_total)::double precision)                       AS perc_active_student_full,
             ((economic_activity.economically_inactive_total)::double precision /
              ((economic_activity.economically_inactive_total +
                economic_activity.economically_active_total))::double precision)                     AS perc_economically_inactive,
             ((economic_activity.economically_inactive_retired)::double precision /
              (economic_activity.economically_inactive_total)::double precision)                     AS perc_inactive_retired,
             ((economic_activity.economically_inactive_student_inclu_full_time)::double precision /
              (economic_activity.economically_inactive_total)::double precision)                     AS perc_inactive_student_inclu_full_time,
             ((economic_activity.economically_inactive_looking_after_home_or_family)::double precision /
              (economic_activity.economically_inactive_total)::double precision)                     AS perc_inactive_looking_after_home_or_family,
             ((economic_activity.economically_inactive_long_term_sick_or_disabled)::double precision /
              (economic_activity.economically_inactive_total)::double precision)                     AS perc_inactive_long_term_sick_or_disabled,
             ((economic_activity.economically_inactive_other)::double precision /
              (economic_activity.economically_inactive_total)::double precision)                     AS perc_inactive_other
      FROM (onsdata.onspd
             LEFT JOIN onsdata.economic_activity ON (((onspd.oa11)::text = (economic_activity.geography_code)::text)))
      WHERE (economic_activity.economically_active_total > 0)) ds;

alter table v_band_economic_activity
  owner to ccdatawh;

