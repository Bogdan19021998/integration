create view v_metric_post_registration_engagement_category as
SELECT uc.user_key,
       CASE WHEN (i.num_investments IS NULL) THEN (0)::bigint ELSE i.num_investments END AS num_investments,
       (uc.snapshot_date_key - u.registered_date_key)                                    AS num_days_registered_ago,
       CASE
         WHEN ((((uc.snapshot_date_key - u.registered_date_key) = 1) AND (i.num_investments IS NULL)) AND
               (uc.subscribed_newsletter = true)) THEN 'One day post registration'::text
         WHEN ((((uc.snapshot_date_key - u.registered_date_key) = 2) AND (i.num_investments IS NULL)) AND
               (uc.subscribed_newsletter = true)) THEN 'Two day post registration'::text
         WHEN ((((uc.snapshot_date_key - u.registered_date_key) = 3) AND (i.num_investments IS NULL)) AND
               (uc.subscribed_newsletter = true)) THEN 'Three day post registration'::text
         WHEN ((((uc.snapshot_date_key - u.registered_date_key) = 7) AND (i.num_investments IS NULL)) AND
               (uc.subscribed_newsletter = true)) THEN 'Seven day post registration'::text
         ELSE 'Excluded'::text END                                                       AS post_registration_engagement_category
FROM ((dim_users_static u JOIN dim_users_changing uc ON (((u.user_key = uc.user_key) AND (uc.snapshot_date_key =
                                                                                          (SELECT "max"(dim_users_changing.snapshot_date_key) AS "max"
                                                                                           FROM dim_users_changing)))))
       LEFT JOIN (SELECT fact_pitch_investments.user_key, count(*) AS num_investments
                  FROM fact_pitch_investments
                  GROUP BY fact_pitch_investments.user_key) i ON ((u.user_key = i.user_key)));

alter table v_metric_post_registration_engagement_category
  owner to ccdatawh;

