create view v_band_approximate_social_grade as
SELECT derived_table1.pcd,
       derived_table1.perc_upper_middle_class,
       derived_table1.perc_lower_middle_class,
       derived_table1.perc_skilled_working_class,
       derived_table1.perc_working_class_non_working,
       (CASE
          WHEN ((derived_table1.perc_upper_middle_class > (0)::double precision) AND
                (derived_table1.perc_upper_middle_class <= (0.35)::double precision)) THEN 'A'::text
          WHEN ((derived_table1.perc_upper_middle_class > (0.35)::double precision) AND
                (derived_table1.perc_upper_middle_class <= (0.45)::double precision)) THEN 'B'::text
          WHEN ((derived_table1.perc_upper_middle_class > (0.45)::double precision) AND
                (derived_table1.perc_upper_middle_class <= (0.55)::double precision)) THEN 'C'::text
          ELSE 'D'::text END)::character(1)                                     AS perc_upper_middle_class_band,
       onsdata.f_percent_band(derived_table1.perc_lower_middle_class, 5)        AS perc_lower_middle_class_band,
       onsdata.f_percent_band(derived_table1.perc_skilled_working_class, 5)     AS perc_skilled_working_class_band,
       onsdata.f_percent_band(derived_table1.perc_working_class_non_working, 5) AS perc_working_class_non_working_band
FROM (SELECT "replace"(btrim(upper((p.pcd)::text)), ' '::text, ''::text)       AS pcd,
             ((a.ab)::double precision / (a.all_categories)::double precision) AS perc_upper_middle_class,
             ((a.c1)::double precision / (a.all_categories)::double precision) AS perc_lower_middle_class,
             ((a.c2)::double precision / (a.all_categories)::double precision) AS perc_skilled_working_class,
             ((a.de)::double precision / (a.all_categories)::double precision) AS perc_working_class_non_working
      FROM (onsdata.onspd p
             LEFT JOIN onsdata.approximate_social_grade a ON (((p.oa11)::text = (a.geography_code)::text)))
      WHERE (a.all_categories > 0)) derived_table1;

alter table v_band_approximate_social_grade
  owner to ccdatawh;

