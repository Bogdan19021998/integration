create view v_selligent_engagement as
SELECT DISTINCT dt.the_date,
                camps.campaign_name,
                camps.user_group,
                camps.user_key,
                CASE
                  WHEN (csession.num_sessions IS NULL) THEN (0)::bigint
                  ELSE csession.num_sessions END                                                     AS num_sessions,
                CASE WHEN (inv.num_investment IS NULL) THEN (0)::bigint ELSE inv.num_investment END  AS num_investments,
                CASE WHEN (inv.val_investment IS NULL) THEN (0)::numeric ELSE inv.val_investment END AS val_investments,
                CASE WHEN (inv.fee_amount IS NULL) THEN (0)::numeric ELSE inv.fee_amount END         AS val_fee
FROM (((dim_dates dt LEFT JOIN (SELECT DISTINCT v_selligent_report_clicks.date_key,
                                                v_selligent_report_clicks.campaign_name,
                                                v_selligent_report_clicks.user_group,
                                                v_selligent_report_clicks.extrapolated_user_id AS user_key
                                FROM v_selligent_report_clicks) camps ON ((dt.date_key = camps.date_key))) LEFT JOIN (SELECT ds1.date_key,
                                                                                                                             ds1.campaign_name,
                                                                                                                             ds1.user_group,
                                                                                                                             ds1.user_key,
                                                                                                                             count(*) AS num_sessions
                                                                                                                      FROM (SELECT DISTINCT v_selligent_report_clicks.date_key,
                                                                                                                                            v_selligent_report_clicks.campaign_name,
                                                                                                                                            v_selligent_report_clicks.session_key,
                                                                                                                                            v_selligent_report_clicks.user_group,
                                                                                                                                            v_selligent_report_clicks.extrapolated_user_id AS user_key
                                                                                                                            FROM v_selligent_report_clicks) ds1
                                                                                                                      GROUP BY ds1.date_key,
                                                                                                                               ds1.campaign_name,
                                                                                                                               ds1.user_group,
                                                                                                                               ds1.user_key
                                                                                                                      ORDER BY ds1.date_key) csession ON ((
    (((dt.date_key = csession.date_key) AND ((camps.campaign_name)::text = (csession.campaign_name)::text)) AND
     (camps.user_group = csession.user_group)) AND (camps.user_key = csession.user_key))))
       LEFT JOIN (SELECT ds.date_key,
                         ds.campaign_name,
                         (ds.user_group)::character varying AS user_group,
                         ds.user_key,
                         count(*)                           AS num_investment,
                         sum(ds.amount_in_gbp)              AS val_investment,
                         sum(ds.fee_amount)                 AS fee_amount
                  FROM (SELECT pi.investment_date_key     AS date_key,
                               cd.campaign_name,
                               CASE
                                 WHEN (mod(pi.user_key, 2) = 0) THEN 'Group B'::text
                                 WHEN (mod(pi.user_key, 2) = 1) THEN 'Group A'::text
                                 ELSE 'Unknown'::text END AS user_group,
                               pi.user_key,
                               pi.amount_in_gbp,
                               pi.fee_amount
                        FROM (fact_pitch_investments pi
                               JOIN (SELECT DISTINCT c.session_key, c.campaign_name, cd.investment_id AS transaction_id
                                     FROM (v_selligent_report_clicks c
                                            JOIN fast.fact_pitch_investments_clickdata_web cd
                                                 ON (((c.session_key)::text = (cd.session_key)::text)))
                                     ORDER BY c.request_timestamp) cd ON ((pi.transaction_id = cd.transaction_id)))) ds
                  GROUP BY ds.date_key, ds.campaign_name, ds.user_group, ds.user_key
                  UNION ALL
                  SELECT initial_investment_values.date_key,
                         initial_investment_values.campaign_name,
                         initial_investment_values.user_group,
                         initial_investment_values.user_key,
                         initial_investment_values.num_investment,
                         initial_investment_values.val_investment,
                         initial_investment_values.val_fee
                  FROM selligent.initial_investment_values) inv ON ((
    (((dt.date_key = inv.date_key) AND ((camps.campaign_name)::text = (inv.campaign_name)::text)) AND
     (camps.user_group = (inv.user_group)::text)) AND (camps.user_key = inv.user_key))))
WHERE ((dt.the_date > '2016-08-01'::date) AND (dt.the_date <= ('now'::text)::date))
ORDER BY dt.the_date;

alter table v_selligent_engagement
  owner to ccdatawh;

