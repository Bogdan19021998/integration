create view v_trident_review_start_users as
SELECT l.crowdcube_user_id_c, l.id AS lead_id, min(fe.request_timestamp) AS request_timestamp
FROM ((((sfexperimental.leads l LEFT JOIN dim_anon_users_new au ON (((l.crowdcube_user_id_c)::text = (au.user_key)::text))) JOIN dim_sessions s ON (((au.anon_id)::text = (s.anonymousid)::text))) JOIN fact_engagement fe ON (((s.session_key)::text = (fe.session_key)::text)))
       JOIN dim_events e ON ((fe.event_key = e.event_key)))
WHERE (((e.event_name)::text = 'pitch_review_start'::text) AND (au.user_key > 0))
GROUP BY l.crowdcube_user_id_c, l.id;

alter table v_trident_review_start_users
  owner to ccdatawh;

