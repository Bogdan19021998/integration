create view svcs_query_summary as
  SELECT svcs_query_report.userid,
         svcs_query_report.query,
         svcs_stream_segs.stream                                                                                                                                           AS stm,
         svcs_query_report.segment                                                                                                                                         AS seg,
         svcs_query_report.step,
         "max"(svcs_query_report.elapsed_time)                                                                                                                             AS maxtime,
         avg(svcs_query_report.elapsed_time)                                                                                                                               AS avgtime,
         sum(svcs_query_report."rows")                                                                                                                                     AS "rows",
         sum(svcs_query_report.bytes)                                                                                                                                      AS bytes,
         round(((sum(svcs_query_report."rows") / CASE
                                                   WHEN (("date_part"('epoch'::text,
                                                                      "max"((svcs_query_report.end_time - svcs_query_report.start_time))))::bigint =
                                                         0) THEN NULL::bigint
                                                   ELSE ("date_part"('epoch'::text,
                                                                     "max"((svcs_query_report.end_time - svcs_query_report.start_time))))::bigint END))::double precision) AS rate_row,
         round(((sum(svcs_query_report.bytes) / CASE
                                                  WHEN (("date_part"('epoch'::text,
                                                                     "max"((svcs_query_report.end_time - svcs_query_report.start_time))))::bigint =
                                                        0) THEN NULL::bigint
                                                  ELSE ("date_part"('epoch'::text,
                                                                    "max"((svcs_query_report.end_time - svcs_query_report.start_time))))::bigint END))::double precision)  AS rate_byte,
         svcs_query_report."label",
         svcs_query_report.is_diskbased,
         sum(svcs_query_report.workmem)                                                                                                                                    AS workmem,
         svcs_query_report.is_rrscan,
         svcs_query_report.is_delayed_scan,
         sum(svcs_query_report.rows_pre_filter)                                                                                                                            AS rows_pre_filter
  FROM svcs_query_report,
       svcs_stream_segs
  WHERE ((svcs_query_report.query = svcs_stream_segs.query) AND (svcs_query_report.segment = svcs_stream_segs.segment))
  GROUP BY svcs_query_report.userid, svcs_query_report.query, svcs_stream_segs.stream, svcs_query_report.segment,
           svcs_query_report.step, svcs_query_report."label", svcs_query_report.is_diskbased,
           svcs_query_report.is_rrscan, svcs_query_report.is_delayed_scan
  UNION ALL
  SELECT svl_query_summary.userid,
         svl_query_summary.query,
         svl_query_summary.stm,
         svl_query_summary.seg,
         svl_query_summary.step,
         svl_query_summary.maxtime,
         svl_query_summary.avgtime,
         svl_query_summary."rows",
         svl_query_summary.bytes,
         svl_query_summary.rate_row,
         svl_query_summary.rate_byte,
         svl_query_summary."label",
         svl_query_summary.is_diskbased,
         svl_query_summary.workmem,
         svl_query_summary.is_rrscan,
         svl_query_summary.is_delayed_scan,
         svl_query_summary.rows_pre_filter
  FROM svl_query_summary;

alter table svcs_query_summary
  owner to rdsdb;

