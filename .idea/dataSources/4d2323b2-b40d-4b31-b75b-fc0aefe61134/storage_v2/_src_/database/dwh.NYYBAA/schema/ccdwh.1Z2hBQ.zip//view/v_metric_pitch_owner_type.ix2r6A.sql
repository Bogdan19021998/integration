create view v_metric_pitch_owner_type as
SELECT us.user_key,
       CASE
         WHEN (ds2.pitch_owner_type_classification IS NULL) THEN 'None'::text
         ELSE ds2.pitch_owner_type_classification END AS pitch_owner_type_classification
FROM (dim_users_static us
       LEFT JOIN (SELECT ds.user_key,
                         "substring"(ds.pitch_owner_type_classification, 4,
                                     len(ds.pitch_owner_type_classification)) AS pitch_owner_type_classification
                  FROM (SELECT derived_table1.user_key,
                               derived_table1.pitch_key,
                               derived_table1.pitch_owner_type_classification,
                               pg_catalog.row_number()
                               OVER ( PARTITION BY derived_table1.user_key ORDER BY derived_table1.pitch_owner_type_classification) AS row_num
                        FROM (SELECT us.user_key,
                                     ps.pitch_key,
                                     CASE
                                       WHEN ((pc.pitch_status)::text = 'Cancelled'::text) THEN '3. Unfunded Pitch(s)'::text
                                       WHEN ((pc.pitch_status)::text = 'Manual Pending'::text)
                                         THEN '4. Creation Attempted'::text
                                       WHEN ((pc.pitch_status)::text = 'Disapproved'::text) THEN '4. Creation Attempted'::text
                                       WHEN ((pc.pitch_status)::text = 'Approved'::text) THEN '1. Active Pitch'::text
                                       WHEN ((pc.pitch_status)::text = 'Expired'::text) THEN '3. Unfunded Pitch(s)'::text
                                       WHEN ((pc.pitch_status)::text = 'Pending'::text) THEN '4. Creation Attempted'::text
                                       WHEN ((pc.pitch_status)::text = 'Active'::text) THEN '1. Active Pitch'::text
                                       WHEN ((pc.pitch_status)::text = 'Publish Pending'::text)
                                         THEN '4. Creation Attempted'::text
                                       WHEN ((pc.pitch_status)::text = 'Incomplete'::text) THEN '4. Creation Attempted'::text
                                       WHEN ((pc.pitch_status)::text = 'Funded'::text) THEN '2. Funded Pitch(s)'::text
                                       ELSE NULL::text END AS pitch_owner_type_classification
                              FROM ((dim_pitches_changing pc JOIN dim_pitches_static ps ON ((pc.pitch_key = ps.pitch_key)))
                                     JOIN dim_users_static us ON (((us.user_key)::text = (ps.creating_user_id)::text)))
                              WHERE (pc.snapshot_date_key =
                                     (SELECT "max"(dim_pitches_changing.snapshot_date_key) AS "max"
                                      FROM dim_pitches_changing))) derived_table1
                        ORDER BY derived_table1.user_key) ds
                  WHERE (ds.row_num = 1)) ds2 ON ((us.user_key = ds2.user_key)));

alter table v_metric_pitch_owner_type
  owner to ccdatawh;

