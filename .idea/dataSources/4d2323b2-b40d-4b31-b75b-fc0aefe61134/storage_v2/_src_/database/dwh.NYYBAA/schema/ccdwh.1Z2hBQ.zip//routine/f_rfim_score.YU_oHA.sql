create function f_rfim_score(recency_count integer, frequency bigint, intensity_distinct_events bigint, intensity_browse_time_in_last_month bigint, intensity_monetary numeric) returns character
  stable
  language plpythonu
as
$$
       if recency_count < -400 :                                        return 'F'
       if recency_count >= -400 and recency_count < -200        :       return 'E'
       if recency_count >= -200 and recency_count < -100        :       return 'D'
       
       if recency_count >= -100 and recency_count < -50 and intensity_monetary < 500    : return 'C'
       if recency_count >= -100 and recency_count < -50 and intensity_monetary >= 500   : return 'B'
       
       
       if recency_count >= -50  and intensity_monetary < 100                            : return 'B'
       if recency_count >= -50  and intensity_monetary >= 100                           : return 'A'
       
       return 'U'
$$;

