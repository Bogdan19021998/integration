create view v_progress_through_quarter as
SELECT dim_dates.year_quarter,
       CASE
         WHEN ((dim_dates.year_quarter)::text =
               ((SELECT dim_dates.year_quarter FROM dim_dates WHERE (dim_dates.the_date = ('now'::text)::date)))::text)
           THEN ((SELECT dim_dates.date_key FROM dim_dates WHERE (dim_dates.the_date = ('now'::text)::date)) -
                 min(dim_dates.date_key))
         WHEN ((dim_dates.year_quarter)::text <
               ((SELECT dim_dates.year_quarter FROM dim_dates WHERE (dim_dates.the_date = ('now'::text)::date)))::text)
           THEN (("max"(dim_dates.date_key) - min(dim_dates.date_key)) + 1)
         ELSE 0 END                                                AS days_through_quarter,
       (("max"(dim_dates.date_key) - min(dim_dates.date_key)) + 1) AS days_in_quarter
FROM dim_dates
WHERE ((dim_dates."year" >= 2011) AND
       (dim_dates."year" <= (SELECT dim_dates."year" FROM dim_dates WHERE (dim_dates.the_date = ('now'::text)::date))))
GROUP BY dim_dates.year_quarter
ORDER BY dim_dates.year_quarter;

alter table v_progress_through_quarter
  owner to ccdatawh;

