create function email_valid(email character varying) returns boolean
  stable
  language plpythonu
as
$$
import re
return re.match(r'(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)', email, re.M|re.I)

$$;

