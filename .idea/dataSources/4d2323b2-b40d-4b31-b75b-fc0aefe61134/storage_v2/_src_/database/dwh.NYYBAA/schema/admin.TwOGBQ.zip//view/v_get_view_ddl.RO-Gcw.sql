create view v_get_view_ddl as
SELECT nc.nspname,
       ((((('create view '::text || ((nc.nspname)::information_schema.sql_identifier)::text) || '.'::text) ||
          ((c.relname)::information_schema.sql_identifier)::text) || ' as '::text) ||
        ((pg_get_viewdef(c.oid))::information_schema.character_data)::text) AS view_definition
FROM pg_namespace nc,
     pg_class c,
     pg_user u
WHERE (((c.relnamespace = nc.oid) AND (u.usesysid = c.relowner)) AND (c.relkind = 'v'::"char"));

alter table v_get_view_ddl
  owner to ccdatawh;

