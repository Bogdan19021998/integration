create view v_pitch_investments_with_investor_postcode_lookup as
SELECT pi.investment_id,
       pi.transaction_id,
       pi.investment_date_key,
       pi.investment_timestamp,
       pi.update_date_key,
       pi.update_timestamp,
       pi.pitch_key,
       pi.user_key,
       pi.amount,
       pi.currency_iso_code,
       pi.currency_symbol,
       pi.exchange_rate_to_gbp,
       pi.payment_method,
       pi.amount_in_gbp,
       pi.investor_count_key,
       pi.pitch_progress_key,
       pi.remaining_timespan_key,
       pi.session_key,
       pi.investment_status,
       dt.the_date,
       CASE
         WHEN (((((((((("substring"((us.private_address_post_code)::text, 1, 1) = ('0'::character varying)::text) OR
                       ("substring"((us.private_address_post_code)::text, 1, 1) = ('1'::character varying)::text)) OR
                      ("substring"((us.private_address_post_code)::text, 1, 1) = ('2'::character varying)::text)) OR
                     ("substring"((us.private_address_post_code)::text, 1, 1) = ('3'::character varying)::text)) OR
                    ("substring"((us.private_address_post_code)::text, 1, 1) = ('4'::character varying)::text)) OR
                   ("substring"((us.private_address_post_code)::text, 1, 1) = ('5'::character varying)::text)) OR
                  ("substring"((us.private_address_post_code)::text, 1, 1) = ('6'::character varying)::text)) OR
                 ("substring"((us.private_address_post_code)::text, 1, 1) = ('7'::character varying)::text)) OR
                ("substring"((us.private_address_post_code)::text, 1, 1) = ('8'::character varying)::text)) OR
               ("substring"((us.private_address_post_code)::text, 1, 1) = ('9'::character varying)::text))
           THEN ('overseas'::character varying)::text
         WHEN (((((((((("substring"((us.private_address_post_code)::text, 2, 1) = ('0'::character varying)::text) OR
                       ("substring"((us.private_address_post_code)::text, 2, 1) = ('1'::character varying)::text)) OR
                      ("substring"((us.private_address_post_code)::text, 2, 1) = ('2'::character varying)::text)) OR
                     ("substring"((us.private_address_post_code)::text, 2, 1) = ('3'::character varying)::text)) OR
                    ("substring"((us.private_address_post_code)::text, 2, 1) = ('4'::character varying)::text)) OR
                   ("substring"((us.private_address_post_code)::text, 2, 1) = ('5'::character varying)::text)) OR
                  ("substring"((us.private_address_post_code)::text, 2, 1) = ('6'::character varying)::text)) OR
                 ("substring"((us.private_address_post_code)::text, 2, 1) = ('7'::character varying)::text)) OR
                ("substring"((us.private_address_post_code)::text, 2, 1) = ('8'::character varying)::text)) OR
               ("substring"((us.private_address_post_code)::text, 2, 1) = ('9'::character varying)::text))
           THEN upper("substring"((us.private_address_post_code)::text, 1, 1))
         ELSE upper("substring"((us.private_address_post_code)::text, 1, 2)) END AS postcode_lookup,
       ps.portal_name
FROM dim_users_static us,
     ((fact_pitch_investments pi JOIN dim_pitches_static ps ON ((pi.pitch_key = ps.pitch_key)))
       JOIN dim_dates dt ON ((pi.investment_date_key = dt.date_key)))
WHERE (pi.user_key = us.user_key);

alter table v_pitch_investments_with_investor_postcode_lookup
  owner to ccdatawh;

