create view v_metric_visitor_new_repeat_month as
SELECT y.year_month,
       y.num_new_month,
       (y.num_unique_visitors - y.num_new_month) AS num_repeat_visitors,
       y.num_unique_visitors
FROM (SELECT x.year_month, sum(x.num_new) AS num_new_month, x.num_unique_visitors
      FROM (SELECT dt.date_key, dt.year_month, count(DISTINCT ds.anonymousid) AS num_new, vis.num_unique_visitors
            FROM ((dim_dates dt LEFT JOIN (SELECT DISTINCT s.anonymousid, min(s.session_start_date_key) AS first_session
                                           FROM dim_sessions s
                                           GROUP BY s.anonymousid) ds ON ((dt.date_key = ds.first_session)))
                   LEFT JOIN (SELECT v_metric_unique_visitors_month.year_month,
                                     v_metric_unique_visitors_month.num_unique_visitors
                              FROM v_metric_unique_visitors_month) vis
                             ON (((dt.year_month)::text = (vis.year_month)::text)))
            WHERE (dt.the_date < ('now'::text)::date)
            GROUP BY dt.date_key, vis.num_unique_visitors, dt.year_month
            ORDER BY dt.date_key, dt.year_month DESC) x
      GROUP BY x.year_month, x.num_unique_visitors
      ORDER BY x.year_month DESC) y
WHERE ((y.year_month)::text >= '2015/03'::text)
ORDER BY y.year_month DESC;

alter table v_metric_visitor_new_repeat_month
  owner to ccdatawh;

