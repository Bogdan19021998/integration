create view v_distil_user_sync as
SELECT c.user_key AS c_user_key,
       s.user_firstname,
       s.user_lastname,
       s.private_address_address_1,
       s.private_address_address_2,
       s.private_address_town,
       s.private_address_county,
       s.private_address_post_code,
       s.private_address_country,
       s.gender,
       c.user_category,
       c.aml_status_checked_count,
       c.aml_status_last_interpreted_result,
       c.users_email,
       c.crowdcube_active_user,
       c.investor_type_classification,
       c.pitch_owner_type,
       c.selligent_active_user
FROM (dim_users_changing c
       JOIN dim_users_static s ON ((c.user_key = s.user_key)))
WHERE ((c.snapshot_date_key = (SELECT "max"(dim_users_changing.snapshot_date_key) AS "max" FROM dim_users_changing)) AND
       (c.subscribed_marketing = 1))
ORDER BY c.user_key DESC;

alter table v_distil_user_sync
  owner to ccdatawh;

