create view v_pitch_investments_with_user_clusters as
SELECT pi.investment_date_key,
       ps.pitch_name,
       c.user_key,
       CASE
         WHEN (c."winner cluster" IS NULL) THEN 'Not assigned'::character varying
         ELSE c."winner cluster" END AS "winner cluster",
       pi.amount_in_gbp
FROM ((fact_pitch_investments pi JOIN dim_pitches_static ps ON ((pi.pitch_key = ps.pitch_key)))
       LEFT JOIN ccseg.tbl_user_cluster_assignments_non_geospatial c ON ((pi.user_key = c.user_key)))
WHERE ((pi.investment_date_key >=
        (SELECT dim_dates.date_key FROM dim_dates WHERE (dim_dates.the_date = '2014-01-01'::date))) AND
       ((ps.portal_name)::text = 'crowdcube'::text));

alter table v_pitch_investments_with_user_clusters
  owner to ccdatawh;

