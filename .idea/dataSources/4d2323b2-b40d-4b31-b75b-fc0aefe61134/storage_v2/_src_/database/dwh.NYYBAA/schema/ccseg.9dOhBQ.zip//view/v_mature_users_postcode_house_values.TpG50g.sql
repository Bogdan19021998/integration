create view v_mature_users_postcode_house_values as
SELECT u.user_key, u.sanitised_postcode, pd.postcode_area, pd.average_value AS average_house_value
FROM ((SELECT derived_table1.user_key,
              derived_table1.sanitised_postcode,
              CASE
                WHEN ((((((derived_table1.valid1 > 0) OR (derived_table1.valid2 > 0)) OR (derived_table1.valid3 > 0)) OR
                        (derived_table1.valid4 > 0)) OR (derived_table1.valid5 > 0)) OR (derived_table1.valid6 > 0))
                  THEN CASE
                         WHEN (len((derived_table1.sanitised_postcode)::text) = 7)
                           THEN "substring"((derived_table1.sanitised_postcode)::text, 1, 4)
                         WHEN (len((derived_table1.sanitised_postcode)::text) = 6)
                           THEN "substring"((derived_table1.sanitised_postcode)::text, 1, 3)
                         WHEN (len((derived_table1.sanitised_postcode)::text) = 5)
                           THEN "substring"((derived_table1.sanitised_postcode)::text, 1, 2)
                         ELSE ''::text END
                ELSE ''::text END AS pc_area
       FROM (SELECT u.user_key,
                    u.sanitised_postcode,
                    regexp_instr((u.sanitised_postcode)::text, '^[A-Z][0-9][0-9][A-Z][A-Z]$'::text)           AS valid1,
                    regexp_instr((u.sanitised_postcode)::text, '^[A-Z][0-9][0-9][0-9][A-Z][A-Z]$'::text)      AS valid2,
                    regexp_instr((u.sanitised_postcode)::text, '^[A-Z][A-Z][0-9][0-9][A-Z][A-Z]$'::text)      AS valid3,
                    regexp_instr((u.sanitised_postcode)::text, '^[A-Z][A-Z][0-9][0-9][0-9][A-Z][A-Z]$'::text) AS valid4,
                    regexp_instr((u.sanitised_postcode)::text, '^[A-Z][0-9][A-Z][0-9][A-Z][A-Z]$'::text)      AS valid5,
                    regexp_instr((u.sanitised_postcode)::text, '^[A-Z][A-Z][0-9][A-Z][0-9][A-Z][A-Z]$'::text) AS valid6
             FROM (ccseg.v_mature_user_accounts_for_cluster_training_set "ts"
                    JOIN ccseg.v_users u ON ((u.user_key = "ts".user_key)))) derived_table1) u
       LEFT JOIN ccseg.tbl_postcode_data pd ON (((pd.postcode_area)::text = u.pc_area)))
ORDER BY u.user_key;

alter table v_mature_users_postcode_house_values
  owner to ccdatawh;

