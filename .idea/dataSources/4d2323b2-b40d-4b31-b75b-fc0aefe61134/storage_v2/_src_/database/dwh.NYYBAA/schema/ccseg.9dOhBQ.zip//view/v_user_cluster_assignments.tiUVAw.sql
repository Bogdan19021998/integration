create view v_user_cluster_assignments as
SELECT uca.user_key,
       uca.user_name,
       uca.user_email,
       uca.investment_count,
       uca.investment_total_amount,
       uca.investment_avg_amount,
       uca.investment_max_amount,
       uca.investment_min_amount,
       uca.winner_cluster,
       uca.average_weekly_income,
       uca.perc_upper_middle_class,
       uca.perc_higher_managerial,
       uca.perc_full_time_student,
       uca.perc_level_4,
       uca.perc_shared_ownership,
       uca.sanitised_postcode,
       uca.run_code,
       uca.from_clustering,
       all_users_avg.investment_deviation_from_average,
       all_users_avg.investment_count_below_average,
       all_users_avg.investment_total_below_average,
       original_cluster_avg.investment_deviation_from_average AS investment_deviation_from_average_original_cluster,
       original_cluster_avg.investment_count_below_average    AS investment_count_below_average_original_cluster,
       original_cluster_avg.investment_total_below_average    AS investment_total_below_average_original_cluster,
       assigned_cluster_avg.investment_deviation_from_average AS investment_deviation_from_average_assigned_cluster,
       assigned_cluster_avg.investment_count_below_average    AS investment_count_below_average_assigned_cluster,
       assigned_cluster_avg.investment_total_below_average    AS investment_total_below_average_assigned_cluster,
       all_investors_avg.investment_deviation_from_average    AS investment_deviation_from_average_only_using_investors,
       all_investors_avg.investment_count_below_average       AS investment_count_below_average_only_using_investors,
       all_investors_avg.investment_total_below_average       AS investment_total_below_average_only_using_investors,
       marketing.unsubscribed_web,
       marketing.unsubscribed_email,
       marketing.invalid_email,
       marketing.no_email,
       marketing.deleted,
       marketing.suspended,
       marketing.no_recent_enagement,
       CASE
         WHEN ((((((marketing.unsubscribed_web = true) OR (marketing.invalid_email = true)) OR
                  (marketing.no_email = true)) OR (marketing.deleted = true)) OR (marketing.suspended = true)) OR
               (marketing.unsubscribed_email = true)) THEN 0
         ELSE 1 END                                           AS marketable
FROM (((((ccseg.v_all_cluster_results uca LEFT JOIN (SELECT u.run_code,
                                                            u.winner_cluster,
                                                            u.user_key,
                                                            u.from_clustering,
                                                            (n.avg_it - u.investment_total_amount)                             AS investment_deviation_from_average,
                                                            CASE WHEN (u.investment_count < n.avg_ic) THEN 1 ELSE 0 END        AS investment_count_below_average,
                                                            CASE WHEN (u.investment_total_amount < n.avg_it) THEN 1 ELSE 0 END AS investment_total_below_average
                                                     FROM (ccseg.v_all_cluster_results u
                                                            LEFT JOIN (SELECT v_all_cluster_results.run_code,
                                                                              v_all_cluster_results.winner_cluster,
                                                                              avg(v_all_cluster_results.investment_count)        AS avg_ic,
                                                                              avg(v_all_cluster_results.investment_total_amount) AS avg_it
                                                                       FROM ccseg.v_all_cluster_results
                                                                       WHERE (v_all_cluster_results.from_clustering = 1)
                                                                       GROUP BY v_all_cluster_results.run_code,
                                                                                v_all_cluster_results.winner_cluster
                                                                       ORDER BY v_all_cluster_results.run_code,
                                                                                v_all_cluster_results.winner_cluster) n
                                                                      ON ((((n.run_code)::text = (u.run_code)::text) AND
                                                                           ((n.winner_cluster)::text = (u.winner_cluster)::text))))
                                                     WHERE (u.from_clustering = 1)) original_cluster_avg ON ((
    ((((original_cluster_avg.run_code)::text = (uca.run_code)::text) AND
      ((original_cluster_avg.winner_cluster)::text = (uca.winner_cluster)::text)) AND
     (original_cluster_avg.user_key = uca.user_key)) AND
    (original_cluster_avg.from_clustering = uca.from_clustering)))) LEFT JOIN (SELECT u.run_code,
                                                                                      u.winner_cluster,
                                                                                      u.user_key,
                                                                                      u.from_clustering,
                                                                                      (n.avg_it - u.investment_total_amount)                             AS investment_deviation_from_average,
                                                                                      CASE WHEN (u.investment_count < n.avg_ic) THEN 1 ELSE 0 END        AS investment_count_below_average,
                                                                                      CASE WHEN (u.investment_total_amount < n.avg_it) THEN 1 ELSE 0 END AS investment_total_below_average
                                                                               FROM (ccseg.v_all_cluster_results u
                                                                                      LEFT JOIN (SELECT v_all_cluster_results.run_code,
                                                                                                        v_all_cluster_results.winner_cluster,
                                                                                                        avg(v_all_cluster_results.investment_count)        AS avg_ic,
                                                                                                        avg(v_all_cluster_results.investment_total_amount) AS avg_it
                                                                                                 FROM ccseg.v_all_cluster_results
                                                                                                 WHERE (v_all_cluster_results.from_clustering = 0)
                                                                                                 GROUP BY v_all_cluster_results.run_code,
                                                                                                          v_all_cluster_results.winner_cluster
                                                                                                 ORDER BY v_all_cluster_results.run_code,
                                                                                                          v_all_cluster_results.winner_cluster) n
                                                                                                ON ((
                                                                                                    ((n.run_code)::text = (u.run_code)::text) AND
                                                                                                    ((n.winner_cluster)::text = (u.winner_cluster)::text))))
                                                                               WHERE (u.from_clustering = 0)) assigned_cluster_avg ON ((
    ((((assigned_cluster_avg.run_code)::text = (uca.run_code)::text) AND
      ((assigned_cluster_avg.winner_cluster)::text = (uca.winner_cluster)::text)) AND
     (assigned_cluster_avg.user_key = uca.user_key)) AND
    (assigned_cluster_avg.from_clustering = uca.from_clustering)))) JOIN (SELECT u.run_code,
                                                                                 u.winner_cluster,
                                                                                 u.user_key,
                                                                                 (n.avg_it - u.investment_total_amount)                             AS investment_deviation_from_average,
                                                                                 CASE WHEN (u.investment_count < n.avg_ic) THEN 1 ELSE 0 END        AS investment_count_below_average,
                                                                                 CASE WHEN (u.investment_total_amount < n.avg_it) THEN 1 ELSE 0 END AS investment_total_below_average
                                                                          FROM (ccseg.v_all_cluster_results u
                                                                                 LEFT JOIN (SELECT v_all_cluster_results.run_code,
                                                                                                   v_all_cluster_results.winner_cluster,
                                                                                                   avg(v_all_cluster_results.investment_count)        AS avg_ic,
                                                                                                   avg(v_all_cluster_results.investment_total_amount) AS avg_it
                                                                                            FROM ccseg.v_all_cluster_results
                                                                                            GROUP BY v_all_cluster_results.run_code,
                                                                                                     v_all_cluster_results.winner_cluster
                                                                                            ORDER BY v_all_cluster_results.run_code,
                                                                                                     v_all_cluster_results.winner_cluster) n
                                                                                           ON ((
                                                                                               ((n.run_code)::text = (u.run_code)::text) AND
                                                                                               ((n.winner_cluster)::text = (u.winner_cluster)::text))))) all_users_avg ON ((
    (((all_users_avg.run_code)::text = (uca.run_code)::text) AND
     ((all_users_avg.winner_cluster)::text = (uca.winner_cluster)::text)) AND
    (all_users_avg.user_key = uca.user_key)))) JOIN (SELECT u.run_code,
                                                            u.winner_cluster,
                                                            u.user_key,
                                                            (n.avg_it - u.investment_total_amount)                             AS investment_deviation_from_average,
                                                            CASE WHEN (u.investment_count < n.avg_ic) THEN 1 ELSE 0 END        AS investment_count_below_average,
                                                            CASE WHEN (u.investment_total_amount < n.avg_it) THEN 1 ELSE 0 END AS investment_total_below_average
                                                     FROM (ccseg.v_all_cluster_results u
                                                            LEFT JOIN (SELECT v_all_cluster_results.run_code,
                                                                              v_all_cluster_results.winner_cluster,
                                                                              avg(v_all_cluster_results.investment_count)        AS avg_ic,
                                                                              avg(v_all_cluster_results.investment_total_amount) AS avg_it
                                                                       FROM ccseg.v_all_cluster_results
                                                                       WHERE (v_all_cluster_results.investment_count > (0)::numeric(30, 10))
                                                                       GROUP BY v_all_cluster_results.run_code,
                                                                                v_all_cluster_results.winner_cluster
                                                                       ORDER BY v_all_cluster_results.run_code,
                                                                                v_all_cluster_results.winner_cluster) n
                                                                      ON ((((n.run_code)::text = (u.run_code)::text) AND
                                                                           ((n.winner_cluster)::text = (u.winner_cluster)::text))))) all_investors_avg ON ((
    (((all_investors_avg.run_code)::text = (uca.run_code)::text) AND
     ((all_investors_avg.winner_cluster)::text = (uca.winner_cluster)::text)) AND
    (all_investors_avg.user_key = uca.user_key))))
       LEFT JOIN (SELECT us.user_key,
                         CASE WHEN (us.subscribed_newsletter = false) THEN true ELSE false END        AS unsubscribed_web,
                         CASE WHEN (unsub.user_key IS NOT NULL) THEN true ELSE false END              AS unsubscribed_email,
                         CASE WHEN (us.email_address_valid = false) THEN true ELSE false END          AS invalid_email,
                         CASE WHEN (btrim((us.user_email)::text) = ''::text) THEN true ELSE false END AS no_email,
                         CASE WHEN ((us.deleted)::text = 'Yes'::text) THEN true ELSE false END        AS deleted,
                         CASE WHEN ((us.suspended)::text = 'Yes'::text) THEN true ELSE false END      AS suspended,
                         CASE WHEN (no_engage.user_key IS NULL) THEN true ELSE false END              AS no_recent_enagement
                  FROM (((SELECT v_master_users_latest.user_key,
                                 v_master_users_latest.subscribed_newsletter,
                                 v_master_users_latest.email_address_valid,
                                 v_master_users_latest.user_email,
                                 v_master_users_latest.deleted,
                                 v_master_users_latest.suspended
                          FROM v_master_users_latest) us LEFT JOIN (((SELECT DISTINCT u.user_key
                                                                      FROM (dim_mailchimp_list_unsubscribes s
                                                                             JOIN v_master_users_static u ON ((
                                                                          btrim(lower((u.user_email)::text)) =
                                                                          btrim(lower((s.email_address)::text)))))
                                                                      UNION
                                                                      SELECT DISTINCT u.user_key
                                                                      FROM (fact_mailchimp_campaign_email_unsubscribes s
                                                                             JOIN v_master_users_static u ON ((
                                                                          btrim(lower((u.user_email)::text)) =
                                                                          btrim(lower((s.email_address)::text))))))
                                                                     UNION
                                                                     SELECT DISTINCT s.user_key
                                                                     FROM fact_mailchimp_campaign_user_unsubscribes s)
                                                                    UNION
                                                                    SELECT DISTINCT suppressed_users.user_id AS user_key
                                                                    FROM selligent.suppressed_users) unsub ON ((us.user_key = unsub.user_key)))
                         LEFT JOIN (SELECT DISTINCT au.user_key
                                    FROM (dim_sessions s
                                           JOIN dim_anon_users_new au ON (((s.anonymousid)::text = (au.anon_id)::text)))
                                    WHERE (s.session_start_date_key > (SELECT (dim_dates.date_key - 350)
                                                                       FROM dim_dates
                                                                       WHERE (dim_dates.the_date = ('now'::text)::date)))) no_engage
                                   ON ((us.user_key = no_engage.user_key)))) marketing
                 ON ((marketing.user_key = uca.user_key)))
WHERE (((uca.sanitised_postcode)::text <> 'EX44RN'::text) AND (uca.user_key <> 90998));

alter table v_user_cluster_assignments
  owner to ccdatawh;

