create view v_user_agent_device_type as
SELECT dim_user_agents.user_agent_key,
       CASE
         WHEN ((dim_user_agents.browser)::text ~~ '%iPhone%'::text) THEN 'mobile'::text
         WHEN ((dim_user_agents.browser)::text ~~ '%iPad%'::text) THEN 'mobile'::text
         WHEN ((dim_user_agents.operating_system)::text ~~ '%Android%'::text) THEN 'mobile'::text
         WHEN ((dim_user_agents.operating_system)::text ~~ '%Nokia%'::text) THEN 'mobile'::text
         WHEN ((dim_user_agents.browser)::text ~~ '%BlackBerry%'::text) THEN 'mobile'::text
         WHEN ((dim_user_agents.operating_system)::text ~~ '%BlackBerry%'::text) THEN 'mobile'::text
         WHEN ((dim_user_agents.operating_system)::text ~~ '%BB10%'::text) THEN 'mobile'::text
         WHEN ((dim_user_agents.operating_system)::text ~~ '%Opera Mini%'::text) THEN 'mobile'::text
         WHEN ((dim_user_agents.operating_system)::text ~~ '%Symbian%'::text) THEN 'mobile'::text
         WHEN ((dim_user_agents.browser)::text ~~ '%Playstation%'::text) THEN 'tv'::text
         WHEN ((dim_user_agents.operating_system)::text ~~ '%PlayStation%'::text) THEN 'tv'::text
         WHEN ((dim_user_agents.operating_system)::text ~~ '%Nintendo%'::text) THEN 'tv'::text
         WHEN ((dim_user_agents.operating_system)::text ~~ '%NetCast%'::text) THEN 'tv'::text
         WHEN ((dim_user_agents.operating_system)::text ~~ '%Unix%'::text) THEN 'desktop'::text
         WHEN ((dim_user_agents.operating_system)::text ~~ '%Windows%'::text) THEN 'desktop'::text
         WHEN ((dim_user_agents.operating_system)::text ~~ '%Mac%'::text) THEN 'desktop'::text
         ELSE 'unknown or bot'::text END AS device_type
FROM dim_user_agents;

alter table v_user_agent_device_type
  owner to ccdatawh;

