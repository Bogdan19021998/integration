create view v_time_to_complete_by_stage_by_close_month as
SELECT a.closed_month,
       count(*)                                                           AS num_pitches_closed_in_month,
       avg(a.days_from_close_to_upload_article)                           AS avg_days_from_close_to_upload_article,
       count(a.days_from_close_to_upload_article)                         AS num_pitches_upload_article,
       avg(a.days_from_upload_article_to_seven_day_email)                 AS avg_days_from_upload_article_to_seven_day_email,
       count(a.days_from_upload_article_to_seven_day_email)               AS num_pitches_seven_day_email,
       avg(a.days_from_seven_day_email_to_complete_special_resolutions)   AS avg_days_from_seven_day_email_to_complete_special_resolutions,
       count(a.days_from_seven_day_email_to_complete_special_resolutions) AS num_pitches_complete_special_resolutions,
       avg(a.days_from_special_res_complete_to_start_funds_drawdown)      AS avg_days_from_special_res_complete_to_start_funds_drawdown,
       count(a.days_from_special_res_complete_to_start_funds_drawdown)    AS num_pitches_start_funds_drawdown,
       avg(a.days_from_start_to_complete_funds_drawdown)                  AS avg_days_from_start_to_complete_funds_drawdown,
       count(a.days_from_start_to_complete_funds_drawdown)                AS num_pitches_complete_funds_drawdown,
       avg(a.days_from_complete_drawdown_to_share_numbers_generated)      AS avg_days_from_complete_drawdown_to_share_numbers_generated,
       count(a.days_from_complete_drawdown_to_share_numbers_generated)    AS num_pitches_share_numbers_generated,
       avg(a.days_from_share_nums_gen_to_certs_generated)                 AS avg_days_from_share_nums_gen_to_certs_generated,
       count(a.days_from_share_nums_gen_to_certs_generated)               AS num_pitches_certs_generated,
       avg(a.days_from_gen_certs_to_send_certs)                           AS avg_days_from_gen_certs_to_send_certs,
       count(a.days_from_gen_certs_to_send_certs)                         AS num_pitches_send_certs,
       avg(a.days_from_closed_to_raise_invoice)                           AS avg_days_from_closed_to_raise_invoice,
       count(a.days_from_closed_to_raise_invoice)                         AS num_pitches_raise_invoice
FROM (SELECT ps.pitch_key,
             ps.pitch_name,
             d.year_month             AS closed_month,
             d.date_key               AS closed_date_key,
             CASE
               WHEN (ps.articles_uploaded_date_key <> 1) THEN (ps.articles_uploaded_date_key - pc.closed_date_key)
               ELSE NULL::integer END AS days_from_close_to_upload_article,
             CASE
               WHEN (ps.seven_day_email_sent_date_key <> 1)
                 THEN (ps.seven_day_email_sent_date_key - ps.articles_uploaded_date_key)
               ELSE NULL::integer END AS days_from_upload_article_to_seven_day_email,
             CASE
               WHEN (ps.special_resolutions_completed_date_key <> 1) THEN (ps.special_resolutions_completed_date_key -
                                                                           ps.seven_day_email_sent_date_key)
               ELSE NULL::integer END AS days_from_seven_day_email_to_complete_special_resolutions,
             CASE
               WHEN (ps.captured_date_key <> 1) THEN (ps.captured_date_key - ps.special_resolutions_completed_date_key)
               ELSE NULL::integer END AS days_from_special_res_complete_to_start_funds_drawdown,
             CASE
               WHEN (ps.captured_complete_date_key <> 1) THEN (ps.captured_complete_date_key - ps.captured_date_key)
               ELSE NULL::integer END AS days_from_start_to_complete_funds_drawdown,
             CASE
               WHEN (ps.share_numbers_generated_key <> 1)
                 THEN (ps.share_numbers_generated_key - ps.captured_complete_date_key)
               ELSE NULL::integer END AS days_from_complete_drawdown_to_share_numbers_generated,
             CASE
               WHEN (ps.certs_gen_date_key <> 1) THEN (ps.certs_gen_date_key - ps.share_numbers_generated_key)
               ELSE NULL::integer END AS days_from_share_nums_gen_to_certs_generated,
             CASE
               WHEN (ps.certs_sent_date_key <> 1) THEN (ps.certs_sent_date_key - ps.certs_gen_date_key)
               ELSE NULL::integer END AS days_from_gen_certs_to_send_certs,
             CASE
               WHEN ((pcom.commission_invoice_date_key IS NOT NULL) AND (pcom.commission_invoice_date_key <> 1))
                 THEN (pcom.commission_invoice_date_key - d.date_key)
               ELSE NULL::integer END AS days_from_closed_to_raise_invoice
      FROM dim_dates d,
           dim_pitches_changing pc,
           (dim_pitches_static ps
             LEFT JOIN fact_pitch_commission pcom ON ((ps.pitch_key = pcom.pitch_key)))
      WHERE ((((((pc.snapshot_date_key = (SELECT dim_dates.date_key
                                          FROM dim_dates
                                          WHERE (dim_dates.the_date = ('now'::character varying)::date))) AND
                 (pc.closed_date_key = d.date_key)) AND (pc.pitch_key = ps.pitch_key)) AND
               ((pc.pitch_status)::text = ('Funded'::character varying)::text)) AND
              ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND (ps.pitch_key <> 14190))
      ORDER BY d.date_key) a
GROUP BY a.closed_month
ORDER BY a.closed_month;

alter table v_time_to_complete_by_stage_by_close_month
  owner to ccdatawh;

