create view v_mailchimp_sync_list_neil as
SELECT ds.user_key,
       ds.user_email,
       ds.user_firstname,
       ds.user_lastname,
       ds.user_unsubsribed_email,
       ds.email_unsubsribed_email,
       ds.num_investments,
       ds.opt_in_newsletter,
       ds.subscribed_newsletter,
       ds.deleted,
       ds.user_type,
       ds.non_investor_newsletter_category,
       ds.post_registration_engagement_category,
       ds.num_days_registered_ago,
       ds.subscribed_summary
FROM (SELECT uc.user_key,
             lower((u.user_email)::text)                    AS user_email,
             u.user_firstname,
             u.user_lastname,
             u_unsubs.user_unsubsribed_email,
             e_unsubs.email_unsubsribed_email,
             i.num_investments,
             uc.subscribed_newsletter                       AS opt_in_newsletter,
             CASE
               WHEN (uc.subscribed_newsletter = false) THEN false
               WHEN (u_unsubs.user_unsubsribed_email IS NOT NULL) THEN false
               WHEN (e_unsubs.email_unsubsribed_email IS NOT NULL) THEN false
               ELSE true END                                AS subscribed_newsletter,
             uc.deleted,
             uc.user_type,
             CASE
               WHEN (uc.non_investor_newsletter_category IS NULL) THEN 'Excluded'::character varying
               WHEN (uc.subscribed_newsletter = false) THEN 'Excluded'::character varying
               WHEN (u_unsubs.user_unsubsribed_email IS NOT NULL) THEN 'Excluded'::character varying
               WHEN (e_unsubs.email_unsubsribed_email IS NOT NULL) THEN 'Excluded'::character varying
               ELSE uc.non_investor_newsletter_category END AS non_investor_newsletter_category,
             CASE
               WHEN ((((((uc.snapshot_date_key - u.registered_date_key) = 1) AND (i.num_investments IS NULL)) AND
                       (uc.subscribed_newsletter = true)) AND (u_unsubs.user_unsubsribed_email IS NULL)) AND
                     (e_unsubs.email_unsubsribed_email IS NULL)) THEN 'One day post registration'::character varying
               WHEN ((((((uc.snapshot_date_key - u.registered_date_key) = 2) AND (i.num_investments IS NULL)) AND
                       (uc.subscribed_newsletter = true)) AND (u_unsubs.user_unsubsribed_email IS NULL)) AND
                     (e_unsubs.email_unsubsribed_email IS NULL)) THEN 'Two day post registration'::character varying
               WHEN ((((((uc.snapshot_date_key - u.registered_date_key) = 3) AND (i.num_investments IS NULL)) AND
                       (uc.subscribed_newsletter = true)) AND (u_unsubs.user_unsubsribed_email IS NULL)) AND
                     (e_unsubs.email_unsubsribed_email IS NULL)) THEN 'Three day post registration'::character varying
               WHEN ((((((uc.snapshot_date_key - u.registered_date_key) = 7) AND (i.num_investments IS NULL)) AND
                       (uc.subscribed_newsletter = true)) AND (u_unsubs.user_unsubsribed_email IS NULL)) AND
                     (e_unsubs.email_unsubsribed_email IS NULL)) THEN 'Seven day post registration'::character varying
               ELSE 'Excluded'::character varying END       AS post_registration_engagement_category,
             (uc.snapshot_date_key - u.registered_date_key) AS num_days_registered_ago,
             uc.subscribed_summary
      FROM (((((ccdwh_test.dim_users_changing uc JOIN (SELECT dim_users_changing.user_key,
                                                              "max"(dim_users_changing.snapshot_date_key) AS date_key
                                                       FROM ccdwh_test.dim_users_changing
                                                       GROUP BY dim_users_changing.user_key) udk ON ((
          (uc.user_key = udk.user_key) AND
          (uc.snapshot_date_key = udk.date_key)))) JOIN ccdwh_test.dim_users_static u ON ((uc.user_key = u.user_key))) LEFT JOIN (SELECT lower((u.user_email)::text) AS user_unsubsribed_email
                                                                                                                                  FROM (ccdwh_test.fact_mailchimp_campaign_user_unsubscribes s
                                                                                                                                         JOIN ccdwh_test.dim_users_static u ON ((u.user_key = s.user_key)))) u_unsubs ON ((
          lower((u.user_email)::text) =
          lower(u_unsubs.user_unsubsribed_email)))) LEFT JOIN (SELECT lower((s.email_address)::text) AS email_unsubsribed_email
                                                               FROM ccdwh_test.fact_mailchimp_campaign_email_unsubscribes s) e_unsubs ON ((
          lower((u.user_email)::text) = lower(e_unsubs.email_unsubsribed_email))))
             LEFT JOIN (SELECT fact_pitch_investments.user_key, count(*) AS num_investments
                        FROM ccdwh_test.fact_pitch_investments
                        GROUP BY fact_pitch_investments.user_key) i ON ((u.user_key = i.user_key)))
      WHERE ((uc.snapshot_date_key - u.registered_date_key) < 365)
      ORDER BY (uc.snapshot_date_key - u.registered_date_key)) ds
WHERE (NOT (lower(ds.user_email) IN (SELECT lower(v_master_unsubscribe_emails_neil.email_address) AS lower
                                     FROM ccdwh_test.v_master_unsubscribe_emails_neil)));

alter table v_mailchimp_sync_list_neil
  owner to ccdatawh;

