create view v_num_sessions_per_day as
SELECT d.the_date, count(*) AS count_of_sessions
FROM (dim_sessions s
       JOIN dim_dates d ON ((s.session_start_date_key = d.date_key)))
GROUP BY d.the_date
ORDER BY d.the_date;

alter table v_num_sessions_per_day
  owner to ccdatawh;

