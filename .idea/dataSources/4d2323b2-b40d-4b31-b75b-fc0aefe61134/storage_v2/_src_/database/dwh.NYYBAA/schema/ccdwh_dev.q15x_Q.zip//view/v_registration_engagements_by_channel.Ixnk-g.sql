create view v_registration_engagements_by_channel as
SELECT DISTINCT dt.the_date,
                dt.year_month,
                dt.year_quarter,
                dt.year_calendar_week,
                refer.channel,
                refer.source,
                refer.user_key,
                CASE WHEN ((pit.pitch_key IS NULL) OR (pit.pitch_key = 0)) THEN 0 ELSE pit.pitch_key END AS pitch_key
FROM (((SELECT dim_dates.date_key,
               dim_dates.the_date,
               dim_dates."year",
               dim_dates."month",
               dim_dates.month_name,
               dim_dates."day",
               dim_dates.day_of_year,
               dim_dates.day_name,
               dim_dates.calendar_week,
               dim_dates.formatted_date,
               dim_dates.quarter,
               dim_dates.year_quarter,
               dim_dates.year_month,
               dim_dates.year_calendar_week,
               dim_dates.weekend,
               dim_dates.period,
               dim_dates.calendar_week_start,
               dim_dates.calendar_week_end,
               dim_dates.month_start,
               dim_dates.month_end
        FROM dim_dates
        WHERE ((dim_dates.the_date >= '2016-07-01'::date) AND
               (dim_dates.the_date <= ('now'::text)::date))) dt LEFT JOIN (SELECT ds.session_key,
                                                                                  ds.request_date_key,
                                                                                  ds.anonymousid,
                                                                                  ds.user_key,
                                                                                  ds.registered_date_key,
                                                                                  ds.channel,
                                                                                  ds.source,
                                                                                  ds.medium
                                                                           FROM (SELECT sa.session_key,
                                                                                        min(sa.request_date_date_key) AS request_date_key,
                                                                                        sa.anonymousid,
                                                                                        sa.user_key,
                                                                                        all_reg_eng.registered_date_key,
                                                                                        sa.channel,
                                                                                        sa.source,
                                                                                        sa.medium
                                                                                 FROM (materialised_views.fact_session_attribution_last_non_direct_30_days sa
                                                                                        JOIN (SELECT eng.session_key,
                                                                                                     eng.user_key,
                                                                                                     us.registered_date_key,
                                                                                                     eng.event_name,
                                                                                                     eng.pitch_key,
                                                                                                     eng.request_timestamp,
                                                                                                     eng.request_date_date_key,
                                                                                                     eng.session_start_timestamp
                                                                                              FROM ((SELECT fe.session_key,
                                                                                                            au.user_key,
                                                                                                            e.event_name,
                                                                                                            fe.pitch_key,
                                                                                                            fe.request_timestamp,
                                                                                                            fe.request_date_date_key,
                                                                                                            s.session_start_timestamp
                                                                                                     FROM (((fact_engagement fe JOIN dim_sessions s ON (((fe.session_key)::text = (s.session_key)::text))) JOIN dim_anon_users_new au ON (((s.anonymousid)::text = (au.anon_id)::text)))
                                                                                                            JOIN dim_events e ON ((fe.event_key = e.event_key)))
                                                                                                     WHERE (fe.pitch_key <> 0))
                                                                                                    eng
                                                                                                     JOIN dim_users_static us ON ((eng.user_key = us.user_key)))
                                                                                              WHERE (((((((eng.event_name)::text = 'registration_complete'::text) OR
                                                                                                         ((eng.event_name)::text = 'Registration complete google'::text)) OR
                                                                                                        ((eng.event_name)::text = 'registration_completed'::text)) OR
                                                                                                       ((eng.event_name)::text = 'Registration complete linkedin'::text)) OR
                                                                                                      ((eng.event_name)::text = 'Registration complete email'::text)) OR
                                                                                                     ((eng.event_name)::text = 'Registration complete facebook'::text))) all_reg_eng
                                                                                             ON (((all_reg_eng.session_key)::text = (sa.session_key)::text)))
                                                                                 GROUP BY sa.session_key,
                                                                                          sa.anonymousid, sa.channel,
                                                                                          sa.source, sa.medium,
                                                                                          sa.user_key,
                                                                                          all_reg_eng.registered_date_key) ds
                                                                           WHERE (ds.registered_date_key = ds.request_date_key)) refer ON ((dt.date_key = refer.request_date_key)))
       LEFT JOIN (SELECT ds.user_key,
                         ds.final_request,
                         ds.final_date_key,
                         CASE WHEN (ds.within_30 = 1) THEN dm.pitch_key ELSE 0 END AS pitch_key
                  FROM ((SELECT z.user_key,
                                z.pitch_key,
                                z.registered_date_key,
                                z.final_request,
                                z.final_date_key,
                                CASE
                                  WHEN (z.final_date_key >= (z.registered_date_key - 30)) THEN 1
                                  ELSE 0 END AS within_30
                         FROM (SELECT x.user_key,
                                      x.pitch_key,
                                      x.registered_date_key,
                                      "max"(y.request_timestamp)     AS final_request,
                                      "max"(y.request_date_date_key) AS final_date_key
                               FROM ((SELECT eng.session_key,
                                             eng.user_key,
                                             us.registered_date_key,
                                             eng.event_name,
                                             eng.pitch_key,
                                             eng.request_timestamp,
                                             eng.request_date_date_key,
                                             eng.session_start_timestamp
                                      FROM ((SELECT fe.session_key,
                                                    au.user_key,
                                                    e.event_name,
                                                    fe.pitch_key,
                                                    fe.request_timestamp,
                                                    fe.request_date_date_key,
                                                    s.session_start_timestamp
                                             FROM (((fact_engagement fe JOIN dim_sessions s ON (((fe.session_key)::text = (s.session_key)::text))) JOIN dim_anon_users_new au ON (((s.anonymousid)::text = (au.anon_id)::text)))
                                                    JOIN dim_events e ON ((fe.event_key = e.event_key)))
                                             WHERE (fe.pitch_key <> 0)) eng
                                             JOIN dim_users_static us ON ((eng.user_key = us.user_key)))
                                      WHERE (((((((eng.event_name)::text = 'registration_complete'::text) OR
                                                 ((eng.event_name)::text = 'Registration complete google'::text)) OR
                                                ((eng.event_name)::text = 'registration_completed'::text)) OR
                                               ((eng.event_name)::text = 'Registration complete linkedin'::text)) OR
                                              ((eng.event_name)::text = 'Registration complete email'::text)) OR
                                             ((eng.event_name)::text = 'Registration complete facebook'::text))) x
                                      LEFT JOIN (SELECT fe.session_key,
                                                        au.user_key,
                                                        e.event_name,
                                                        fe.pitch_key,
                                                        fe.request_timestamp,
                                                        fe.request_date_date_key,
                                                        s.session_start_timestamp
                                                 FROM (((fact_engagement fe JOIN dim_sessions s ON (((fe.session_key)::text = (s.session_key)::text))) JOIN dim_anon_users_new au ON (((s.anonymousid)::text = (au.anon_id)::text)))
                                                        JOIN dim_events e ON ((fe.event_key = e.event_key)))
                                                 WHERE (fe.pitch_key <> 0)) y ON (((x.user_key = y.user_key) AND
                                                                                   (y.request_timestamp < x.request_timestamp))))
                               WHERE (x.request_date_date_key = x.registered_date_key)
                               GROUP BY x.user_key, x.registered_date_key, x.pitch_key) z) ds
                         LEFT JOIN (SELECT fe.session_key,
                                           au.user_key,
                                           e.event_name,
                                           fe.pitch_key,
                                           fe.request_timestamp,
                                           fe.request_date_date_key,
                                           s.session_start_timestamp
                                    FROM (((fact_engagement fe JOIN dim_sessions s ON (((fe.session_key)::text = (s.session_key)::text))) JOIN dim_anon_users_new au ON (((s.anonymousid)::text = (au.anon_id)::text)))
                                           JOIN dim_events e ON ((fe.event_key = e.event_key)))
                                    WHERE (fe.pitch_key <> 0)) dm
                                   ON (((ds.user_key = dm.user_key) AND (ds.final_request = dm.request_timestamp))))
                  WHERE (ds.user_key > 0)) pit ON ((refer.user_key = pit.user_key)));

alter table v_registration_engagements_by_channel
  owner to ccdatawh;

