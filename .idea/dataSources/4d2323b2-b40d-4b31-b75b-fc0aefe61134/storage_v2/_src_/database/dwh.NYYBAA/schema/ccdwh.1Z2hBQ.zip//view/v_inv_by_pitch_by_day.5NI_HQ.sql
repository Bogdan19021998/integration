create view v_inv_by_pitch_by_day as
SELECT d.pitch_key,
       d.pitch_name,
       d.product_type,
       d.target_funding,
       d.pitch_status,
       d.created_date,
       d.investment_date_key,
       d.inv_day,
       d.amount                                              AS daily_amount,
       sum(e.amount)                                         AS sum,
       ((sum(e.amount) * (100)::numeric) / d.target_funding) AS perc_raised,
       d.investments                                         AS daily_investments,
       sum(e.investments)                                    AS cumulative_investments,
       d.investors                                           AS daily_investors,
       sum(e.investors)                                      AS cumulative_investors
FROM ((SELECT x.pitch_key,
              x.pitch_name,
              x.product_type,
              x.target_funding,
              x.pitch_status,
              x.created_date,
              x.investment_date_key,
              x.inv_day,
              (x.daily_amount + CASE WHEN (c.daily_amount IS NULL) THEN (0)::numeric ELSE c.daily_amount END)         AS amount,
              (x.daily_investments + CASE
                                       WHEN (c.daily_investments IS NULL) THEN (0)::bigint
                                       ELSE c.daily_investments END)                                                  AS investments,
              (x.daily_investors + CASE
                                     WHEN (c.daily_investors IS NULL) THEN (0)::bigint
                                     ELSE c.daily_investors END)                                                      AS investors
       FROM ((SELECT pi.pitch_key,
                     ps.pitch_name,
                     ps.product_type,
                     pc.target_funding,
                     pc.pitch_status,
                     pc.created_date_key                                  AS created_date,
                     pi.investment_date_key,
                     ((pi.investment_date_key - pc.created_date_key) + 1) AS inv_day,
                     sum(pi.amount)                                       AS daily_amount,
                     count(pi.user_key)                                   AS daily_investments,
                     count(DISTINCT pi.user_key)                          AS daily_investors
              FROM fact_pitch_investments pi,
                   dim_pitches_changing pc,
                   dim_pitches_static ps
              WHERE (((((pi.pitch_key = pc.pitch_key) AND (pi.pitch_key = ps.pitch_key)) AND
                       ((ps.portal_name)::text = 'crowdcube'::text)) AND (pc.snapshot_date_key =
                                                                          (SELECT dim_dates.date_key
                                                                           FROM dim_dates
                                                                           WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
                     (((((pc.pitch_status)::text = 'Cancelled'::text) OR ((pc.pitch_status)::text = 'Active'::text)) OR
                       ((pc.pitch_status)::text = 'Expired'::text)) OR ((pc.pitch_status)::text = 'Funded'::text)))
              GROUP BY pi.pitch_key, ps.pitch_name, ps.product_type, pc.target_funding, pc.pitch_status,
                       pc.created_date_key, pi.investment_date_key
              ORDER BY pi.pitch_key, ((pi.investment_date_key - pc.created_date_key) + 1)) x
              LEFT JOIN (SELECT pi.pitch_key,
                                ((pi.update_date_key - pc.created_date_key) + 1) AS inv_day,
                                ((-1)::numeric * sum(pi.amount))                 AS daily_amount,
                                (-1 * count(pi.user_key))                        AS daily_investments,
                                (-1 * count(DISTINCT pi.user_key))               AS daily_investors
                         FROM fact_pitch_investments pi,
                              dim_pitches_changing pc,
                              dim_pitches_static ps
                         WHERE ((((((pi.pitch_key = pc.pitch_key) AND (pi.pitch_key = ps.pitch_key)) AND
                                   ((ps.portal_name)::text = 'crowdcube'::text)) AND (pc.snapshot_date_key =
                                                                                      (SELECT dim_dates.date_key
                                                                                       FROM dim_dates
                                                                                       WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
                                 ((pi.investment_status)::text = 'cancelled'::text)) AND
                                (((((pc.pitch_status)::text = 'Cancelled'::text) OR
                                   ((pc.pitch_status)::text = 'Active'::text)) OR
                                  ((pc.pitch_status)::text = 'Expired'::text)) OR
                                 ((pc.pitch_status)::text = 'Funded'::text)))
                         GROUP BY pi.pitch_key, pc.created_date_key, pi.update_date_key
                         ORDER BY pi.pitch_key, ((pi.update_date_key - pc.created_date_key) + 1)) c
                        ON (((x.pitch_key = c.pitch_key) AND (x.inv_day = c.inv_day))))
       GROUP BY x.pitch_key, x.pitch_name, x.product_type, x.target_funding, x.pitch_status, x.created_date,
                x.investment_date_key, x.inv_day, x.daily_amount, c.daily_amount, x.daily_investments,
                c.daily_investments, x.daily_investors, c.daily_investors
       ORDER BY x.pitch_key, x.inv_day) d
       JOIN (SELECT x.pitch_key,
                    x.pitch_name,
                    x.product_type,
                    x.target_funding,
                    x.pitch_status,
                    x.created_date,
                    x.investment_date_key,
                    x.inv_day,
                    (x.daily_amount +
                     CASE WHEN (c.daily_amount IS NULL) THEN (0)::numeric ELSE c.daily_amount END)          AS amount,
                    (x.daily_investments + CASE
                                             WHEN (c.daily_investments IS NULL) THEN (0)::bigint
                                             ELSE c.daily_investments END)                                  AS investments,
                    (x.daily_investors +
                     CASE WHEN (c.daily_investors IS NULL) THEN (0)::bigint ELSE c.daily_investors END)     AS investors
             FROM ((SELECT pi.pitch_key,
                           ps.pitch_name,
                           ps.product_type,
                           pc.target_funding,
                           pc.pitch_status,
                           pc.created_date_key                                  AS created_date,
                           pi.investment_date_key,
                           ((pi.investment_date_key - pc.created_date_key) + 1) AS inv_day,
                           sum(pi.amount)                                       AS daily_amount,
                           count(pi.user_key)                                   AS daily_investments,
                           count(DISTINCT pi.user_key)                          AS daily_investors
                    FROM fact_pitch_investments pi,
                         dim_pitches_changing pc,
                         dim_pitches_static ps
                    WHERE (((((pi.pitch_key = pc.pitch_key) AND (pi.pitch_key = ps.pitch_key)) AND
                             ((ps.portal_name)::text = 'crowdcube'::text)) AND (pc.snapshot_date_key =
                                                                                (SELECT dim_dates.date_key
                                                                                 FROM dim_dates
                                                                                 WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
                           (((((pc.pitch_status)::text = 'Cancelled'::text) OR
                              ((pc.pitch_status)::text = 'Active'::text)) OR
                             ((pc.pitch_status)::text = 'Expired'::text)) OR
                            ((pc.pitch_status)::text = 'Funded'::text)))
                    GROUP BY pi.pitch_key, ps.pitch_name, ps.product_type, pc.target_funding, pc.pitch_status,
                             pc.created_date_key, pi.investment_date_key
                    ORDER BY pi.pitch_key, ((pi.investment_date_key - pc.created_date_key) + 1)) x
                    LEFT JOIN (SELECT pi.pitch_key,
                                      ((pi.update_date_key - pc.created_date_key) + 1) AS inv_day,
                                      ((-1)::numeric * sum(pi.amount))                 AS daily_amount,
                                      (-1 * count(pi.user_key))                        AS daily_investments,
                                      (-1 * count(DISTINCT pi.user_key))               AS daily_investors
                               FROM fact_pitch_investments pi,
                                    dim_pitches_changing pc,
                                    dim_pitches_static ps
                               WHERE ((((((pi.pitch_key = pc.pitch_key) AND (pi.pitch_key = ps.pitch_key)) AND
                                         ((ps.portal_name)::text = 'crowdcube'::text)) AND (pc.snapshot_date_key =
                                                                                            (SELECT dim_dates.date_key
                                                                                             FROM dim_dates
                                                                                             WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
                                       ((pi.investment_status)::text = 'cancelled'::text)) AND
                                      (((((pc.pitch_status)::text = 'Cancelled'::text) OR
                                         ((pc.pitch_status)::text = 'Active'::text)) OR
                                        ((pc.pitch_status)::text = 'Expired'::text)) OR
                                       ((pc.pitch_status)::text = 'Funded'::text)))
                               GROUP BY pi.pitch_key, pc.created_date_key, pi.update_date_key
                               ORDER BY pi.pitch_key, ((pi.update_date_key - pc.created_date_key) + 1)) c
                              ON (((x.pitch_key = c.pitch_key) AND (x.inv_day = c.inv_day))))
             GROUP BY x.pitch_key, x.pitch_name, x.product_type, x.target_funding, x.pitch_status, x.created_date,
                      x.investment_date_key, x.inv_day, x.daily_amount, c.daily_amount, x.daily_investments,
                      c.daily_investments, x.daily_investors, c.daily_investors
             ORDER BY x.pitch_key, x.inv_day) e ON (((d.pitch_key = e.pitch_key) AND (d.inv_day >= e.inv_day))))
GROUP BY d.pitch_key, d.pitch_name, d.product_type, d.target_funding, d.pitch_status, d.created_date,
         d.investment_date_key, d.inv_day, d.amount, d.investments, d.investors
ORDER BY d.pitch_key, d.inv_day;

alter table v_inv_by_pitch_by_day
  owner to ccdatawh;

