create view v_metric_reengagement as
SELECT ds2.the_date,
       sum(ds2.reengagement_inactive_to_active)   AS reengagement_inactive_to_active,
       sum(ds2.reengagement_30daychurn_to_active) AS reengagement_30daychurn_to_active,
       sum(ds2.reengagement_60daychurn_to_active) AS reengagement_60daychurn_to_active
FROM (SELECT dt.the_date,
             ds.user_key,
             CASE
               WHEN (((ds.active_status_previous)::text = 'Inactive'::text) AND
                     ((ds.active_status_current)::text = 'Active'::text)) THEN 1
               ELSE 0 END AS reengagement_inactive_to_active,
             CASE
               WHEN (((ds.active_status_previous)::text = '30-day churn'::text) AND
                     ((ds.active_status_current)::text = 'Active'::text)) THEN 1
               ELSE 0 END AS reengagement_30daychurn_to_active,
             CASE
               WHEN (((ds.active_status_previous)::text = '60-day churn'::text) AND
                     ((ds.active_status_current)::text = 'Active'::text)) THEN 1
               ELSE 0 END AS reengagement_60daychurn_to_active
      FROM ((SELECT uc.user_key,
                    uc_p.crowdcube_active_user AS active_status_previous,
                    uc.crowdcube_active_user   AS active_status_current,
                    '-'::character varying     AS blank,
                    uc_p.snapshot_date_key     AS snapshot_date_key_previous,
                    uc.snapshot_date_key       AS snapshot_date_key_current
             FROM ((dim_users_changing uc JOIN dim_users_static us ON ((uc.user_key = us.user_key)))
                    JOIN dim_users_changing uc_p
                         ON (((uc.user_key = uc_p.user_key) AND ((uc.snapshot_date_key - 1) = uc_p.snapshot_date_key))))
             WHERE (((uc.user_key > 0) AND (uc.crowdcube_active_user IS NOT NULL)) AND
                    ((us.portal)::text = 'crowdcube'::text))
             ORDER BY uc.user_key, uc.snapshot_date_key) ds
             JOIN dim_dates dt ON ((ds.snapshot_date_key_current = dt.date_key)))
      WHERE ((ds.active_status_current)::text <> (ds.active_status_previous)::text)) ds2
GROUP BY ds2.the_date
ORDER BY ds2.the_date DESC;

alter table v_metric_reengagement
  owner to ccdatawh;

