create view v_cluster_geospatial_investment as
SELECT u.user_key,
       u.user_name,
       u.user_email,
       cl."winner cluster" AS winner_cluster,
       u.sanitised_postcode,
       sg.investment_count,
       sg.investment_total_amount,
       sg.investment_avg_amount,
       sg.investment_max_amount,
       sg.investment_min_amount,
       hp.average_house_value,
       pcd.lat,
       pcd.long
FROM ((((ccseg.v_users u JOIN ccseg.v_user_investment_segmentation_raw sg ON ((u.user_key = sg.user_key))) JOIN ccseg.tbl_user_cluster_assignments_non_geospatial cl ON ((u.user_key = cl.user_key))) JOIN ccseg.v_mature_users_postcode_house_values hp ON ((u.user_key = hp.user_key)))
       JOIN onsdata.onspd pcd ON ((upper(btrim((u.sanitised_postcode)::text)) =
                                   upper(btrim("replace"((pcd.pcd)::text, ' '::text, ''::text))))))
WHERE (hp.average_house_value <> 0);

alter table v_cluster_geospatial_investment
  owner to ccdatawh;

