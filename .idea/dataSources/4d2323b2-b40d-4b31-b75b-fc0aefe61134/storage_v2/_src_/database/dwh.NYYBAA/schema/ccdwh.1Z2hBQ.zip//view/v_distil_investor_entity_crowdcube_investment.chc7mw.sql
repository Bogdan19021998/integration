create view v_distil_investor_entity_crowdcube_investment as
SELECT i.user_key, count(*) AS investment_crowdcube_count, sum(i.amount_in_gbp) AS investment_crowdcube_value
FROM (fact_pitch_investments i
       JOIN dim_pitches_static ps ON ((ps.pitch_key = i.pitch_key)))
WHERE ((i.pitch_key IN (SELECT dim_pitches_static.pitch_key
                        FROM dim_pitches_static
                        WHERE (((lower((dim_pitches_static.pitch_name)::text) ~~ '%crowdcube%'::text) AND
                                (lower((dim_pitches_static.pitch_name)::text) !~~ '%test%'::text)) AND
                               ((dim_pitches_static.portal_name)::text = 'crowdcube'::text))
                        ORDER BY dim_pitches_static.pitch_key)) AND
       ((((i.investment_status)::text = 'paid'::text) OR ((i.investment_status)::text = 'withdrawn'::text)) OR
        ((i.investment_status)::text = 'captured'::text)))
GROUP BY i.user_key;

alter table v_distil_investor_entity_crowdcube_investment
  owner to ccdatawh;

