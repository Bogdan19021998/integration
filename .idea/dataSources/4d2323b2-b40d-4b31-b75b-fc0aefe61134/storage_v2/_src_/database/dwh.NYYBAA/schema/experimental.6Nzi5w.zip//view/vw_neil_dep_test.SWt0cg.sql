create view vw_neil_dep_test as
SELECT neil_dep_test.col1, neil_dep_test.col2
FROM experimental.neil_dep_test
WHERE (neil_dep_test.col2 < 10);

alter table vw_neil_dep_test
  owner to ccdatawh;

