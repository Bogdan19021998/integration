create view v_time_to_prepare_and_complete as
SELECT a.year_month,
       a.num_pitches_requested,
       b.num_pitches_created,
       b.avg_days_to_prepare,
       c.num_pitches_closing,
       d.num_pitches_certs_sent,
       d.avg_days_to_complete
FROM ((((SELECT d.year_month, count(ps.pitch_key) AS num_pitches_requested
         FROM dim_dates d,
              dim_pitches_static ps
         WHERE ((((d."year" >= 2011) AND ((d.year_month)::text <= ((SELECT dim_dates.year_month
                                                                    FROM dim_dates
                                                                    WHERE (dim_dates.the_date = ('now'::text)::date)))::text)) AND
                 (ps.pitch_requested_date_key = d.date_key)) AND ((ps.portal_name)::text = 'crowdcube'::text))
         GROUP BY d.year_month
         ORDER BY d.year_month) a LEFT JOIN (SELECT d.year_month,
                                                    count(pc.pitch_key)                                      AS num_pitches_created,
                                                    avg((pc.created_date_key - ps.pitch_requested_date_key)) AS avg_days_to_prepare
                                             FROM dim_dates d,
                                                  dim_pitches_changing pc,
                                                  dim_pitches_static ps
                                             WHERE (((((((d."year" >= 2011) AND ((d.year_month)::text <=
                                                                                 ((SELECT dim_dates.year_month
                                                                                   FROM dim_dates
                                                                                   WHERE (dim_dates.the_date = ('now'::text)::date)))::text)) AND
                                                        (pc.snapshot_date_key = (SELECT dim_dates.date_key
                                                                                 FROM dim_dates
                                                                                 WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
                                                       (ps.pitch_requested_date_key = d.date_key)) AND
                                                      (pc.pitch_key = ps.pitch_key)) AND
                                                     ((ps.portal_name)::text = 'crowdcube'::text)) AND
                                                    (pc.created_date_key <> 1))
                                             GROUP BY d.year_month
                                             ORDER BY d.year_month) b ON (((a.year_month)::text = (b.year_month)::text))) LEFT JOIN (SELECT d.year_month, count(pc.pitch_key) AS num_pitches_closing
                                                                                                                                     FROM dim_dates d,
                                                                                                                                          dim_pitches_changing pc,
                                                                                                                                          dim_pitches_static ps
                                                                                                                                     WHERE (((((((d."year" >= 2011) AND
                                                                                                                                                 ((d.year_month)::text <=
                                                                                                                                                  ((SELECT dim_dates.year_month
                                                                                                                                                    FROM dim_dates
                                                                                                                                                    WHERE (dim_dates.the_date = ('now'::text)::date)))::text)) AND
                                                                                                                                                (pc.snapshot_date_key =
                                                                                                                                                 (SELECT dim_dates.date_key
                                                                                                                                                  FROM dim_dates
                                                                                                                                                  WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
                                                                                                                                               (pc.closed_date_key = d.date_key)) AND
                                                                                                                                              ((pc.pitch_status)::text = 'Funded'::text)) AND
                                                                                                                                             (pc.pitch_key = ps.pitch_key)) AND
                                                                                                                                            ((ps.portal_name)::text = 'crowdcube'::text))
                                                                                                                                     GROUP BY d.year_month
                                                                                                                                     ORDER BY d.year_month) c ON (((a.year_month)::text = (c.year_month)::text)))
       LEFT JOIN (SELECT x.closed_month,
                         count(x.pitch_key)                              AS num_pitches_certs_sent,
                         avg((x.cert_sent_date_key - x.closed_date_key)) AS avg_days_to_complete
                  FROM (SELECT ps.pitch_key,
                               d.year_month AS closed_month,
                               pc.closed_date_key,
                               d2.date_key  AS cert_sent_date_key
                        FROM dim_dates d,
                             dim_pitches_changing pc,
                             dim_pitches_static ps,
                             dim_dates d2
                        WHERE (((((((pc.snapshot_date_key = (SELECT dim_dates.date_key
                                                             FROM dim_dates
                                                             WHERE (dim_dates.the_date = ('now'::text)::date))) AND
                                    (pc.closed_date_key = d.date_key)) AND (pc.pitch_key = ps.pitch_key)) AND
                                  ((pc.pitch_status)::text = 'Funded'::text)) AND
                                 ((ps.portal_name)::text = 'crowdcube'::text)) AND
                                (d2.date_key = ps.certs_sent_date_key)) AND (ps.certs_sent_date_key <> 1))) x
                  GROUP BY x.closed_month) d ON (((a.year_month)::text = (d.closed_month)::text)))
ORDER BY a.year_month;

alter table v_time_to_prepare_and_complete
  owner to ccdatawh;

