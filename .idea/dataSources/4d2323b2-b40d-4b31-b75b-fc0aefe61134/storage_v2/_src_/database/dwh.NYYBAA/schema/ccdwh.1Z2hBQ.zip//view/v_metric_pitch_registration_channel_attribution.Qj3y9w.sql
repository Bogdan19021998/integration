create view v_metric_pitch_registration_channel_attribution as
SELECT DISTINCT dt.the_date,
                refer.channel,
                refer.source,
                refer.medium,
                refer.user_key,
                CASE WHEN ((pit.pitch_key IS NULL) OR (pit.pitch_key = 0)) THEN 0 ELSE pit.pitch_key END AS pitch_key
FROM ((dim_dates dt LEFT JOIN (SELECT x.session_key,
                                      x.request_date_key,
                                      x.anonymousid,
                                      x.user_key,
                                      x.registered_date,
                                      x.channel,
                                      x.source,
                                      x.medium,
                                      x.request_date,
                                      x.register_or_not
                               FROM (SELECT ds.session_key,
                                            ds.request_date_key,
                                            ds.anonymousid,
                                            ds.user_key,
                                            ds.registered_date,
                                            ds.channel,
                                            ds.source,
                                            ds.medium,
                                            dt.the_date                                                    AS request_date,
                                            CASE WHEN (dt.the_date = ds.registered_date) THEN 1 ELSE 0 END AS register_or_not
                                     FROM ((SELECT sa.session_key,
                                                   min(sa.request_date_date_key) AS request_date_key,
                                                   sa.anonymousid,
                                                   sa.user_key,
                                                   dt.the_date                   AS registered_date,
                                                   sa.channel,
                                                   sa.source,
                                                   sa.medium
                                            FROM ((((materialised_views.fact_session_attribution_last_non_direct_30_days sa JOIN fact_engagement fe ON (((sa.session_key)::text = (fe.session_key)::text))) JOIN v_master_registration_events e ON ((fe.event_key = e.event_key))) JOIN v_master_users_latest ul ON ((sa.user_key = ul.user_key)))
                                                   JOIN dim_dates dt ON ((ul.registered_date_key = dt.date_key)))
                                            GROUP BY sa.session_key, sa.anonymousid, sa.channel, sa.source, sa.medium,
                                                     sa.user_key, dt.the_date) ds
                                            JOIN dim_dates dt ON ((ds.request_date_key = dt.date_key)))) x
                               WHERE (x.register_or_not = 1)) refer ON ((dt.date_key = refer.request_date_key)))
       LEFT JOIN (SELECT ds.user_key,
                         ds.final_request,
                         ds.final_date_key,
                         CASE WHEN (ds.within_30 = 1) THEN dm.pitch_key ELSE 0 END AS pitch_key
                  FROM ((SELECT z.user_key,
                                z.pitch_key,
                                z.registered_date,
                                z.final_request,
                                z.final_date_key,
                                dt.the_date                                                           AS final_request_date,
                                CASE WHEN (dt.the_date >= (z.registered_date - 30)) THEN 1 ELSE 0 END AS within_30
                         FROM ((SELECT x.user_key,
                                       x.pitch_key,
                                       x.registered_date,
                                       "max"(y.request_timestamp)     AS final_request,
                                       "max"(y.request_date_date_key) AS final_date_key
                                FROM ((SELECT z.session_key,
                                              z.user_key,
                                              z.registered_date,
                                              z.pitch_key,
                                              z.request_timestamp,
                                              z.request_date,
                                              z.session_start_timestamp,
                                              z.register_or_not
                                       FROM (SELECT fe.session_key,
                                                    au.user_key,
                                                    dt.the_date                                              AS registered_date,
                                                    fe.pitch_key,
                                                    fe.request_timestamp,
                                                    dt2.the_date                                             AS request_date,
                                                    s.session_start_timestamp,
                                                    CASE WHEN (dt.the_date = dt2.the_date) THEN 1 ELSE 0 END AS register_or_not
                                             FROM ((((((fact_engagement fe JOIN dim_sessions s ON (((s.session_key)::text = (fe.session_key)::text))) JOIN dim_anon_users_new au ON (((s.anonymousid)::text = (au.anon_id)::text))) JOIN v_master_registration_events e ON ((fe.event_key = e.event_key))) JOIN dim_dates dt2 ON ((fe.request_date_date_key = dt2.date_key))) LEFT JOIN v_master_users_latest ul ON ((au.user_key = ul.user_key)))
                                                    JOIN dim_dates dt ON ((ul.registered_date_key = dt.date_key)))) z
                                       WHERE (z.register_or_not = 1)) x
                                       LEFT JOIN (SELECT fe.session_key,
                                                         au.user_key,
                                                         fe.pitch_key,
                                                         fe.request_timestamp,
                                                         fe.request_date_date_key,
                                                         s.session_start_timestamp
                                                  FROM (((fact_engagement fe JOIN dim_sessions s ON (((fe.session_key)::text = (s.session_key)::text))) JOIN dim_anon_users_new au ON (((s.anonymousid)::text = (au.anon_id)::text)))
                                                         JOIN dim_events e ON ((fe.event_key = e.event_key)))
                                                  WHERE (fe.pitch_key <> 0)
                                                  ORDER BY fe.request_timestamp) y ON (((x.user_key = y.user_key) AND
                                                                                        (y.request_timestamp < x.request_timestamp))))
                                GROUP BY x.user_key, x.registered_date, x.pitch_key) z
                                JOIN dim_dates dt ON ((z.final_date_key = dt.date_key)))
                         ORDER BY z.user_key) ds
                         LEFT JOIN (SELECT fe.session_key,
                                           au.user_key,
                                           fe.pitch_key,
                                           fe.request_timestamp,
                                           s.session_start_timestamp
                                    FROM (((fact_engagement fe JOIN dim_sessions s ON (((fe.session_key)::text = (s.session_key)::text))) JOIN dim_anon_users_new au ON (((s.anonymousid)::text = (au.anon_id)::text)))
                                           JOIN dim_events e ON ((fe.event_key = e.event_key)))
                                    WHERE (fe.pitch_key <> 0)
                                    ORDER BY fe.request_timestamp) dm
                                   ON (((ds.user_key = dm.user_key) AND (ds.final_request = dm.request_timestamp))))
                  WHERE (ds.user_key > 0)
                  ORDER BY ds.user_key) pit ON ((refer.user_key = pit.user_key)))
WHERE ((dt.the_date >= '2016-07-01'::date) AND (dt.the_date <= ('now'::text)::date))
ORDER BY dt.the_date;

alter table v_metric_pitch_registration_channel_attribution
  owner to ccdatawh;

