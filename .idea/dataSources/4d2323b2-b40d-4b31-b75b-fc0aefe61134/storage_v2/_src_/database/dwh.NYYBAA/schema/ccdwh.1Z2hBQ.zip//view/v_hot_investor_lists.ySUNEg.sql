create view v_hot_investor_lists as
SELECT DISTINCT a.pitch_key,
                a.pitch_name,
                ((((a.pitch_name)::text || ' ('::text) || (a.pitch_key)::text) || ')'::text) AS pitch_name_key,
                a.pitch_status,
                a.user_key,
                a.user_email,
                a.user_firstname,
                a.user_lastname,
                CASE
                  WHEN (a.subscribed_newsletter = false) THEN false
                  WHEN (b.user_unsubscribed_email IS NOT NULL) THEN false
                  WHEN (c.email_unsubscribed_email IS NOT NULL) THEN false
                  ELSE true END                                                              AS subscribed_newsletter
FROM ((((SELECT fe.pitch_key,
                ps.pitch_name,
                pc.pitch_status,
                us.user_key,
                lower((us.user_email)::text) AS user_email,
                us.user_firstname,
                us.user_lastname,
                uc.subscribed_newsletter
         FROM dim_users_static us,
              dim_users_changing uc,
              fact_engagement fe,
              dim_pitches_static ps,
              dim_pitches_changing pc,
              dim_sessions s,
              zzz_dim_anon_users au
         WHERE (((((((((us.user_key = uc.user_key) AND (uc.snapshot_date_key = (SELECT dim_dates.date_key
                                                                                FROM dim_dates
                                                                                WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
                      ((fe.session_key)::text = (s.session_key)::text)) AND
                     ((s.anonymousid)::text = (au.anon_id)::text)) AND (au.user_key = us.user_key)) AND
                   (fe.pitch_key = ps.pitch_key)) AND (ps.pitch_key = pc.pitch_key)) AND
                 (((pc.pitch_status)::text = 'Active'::text) OR ((pc.pitch_status)::text = 'Funded'::text))) AND
                (pc.snapshot_date_key = (SELECT dim_dates.date_key
                                         FROM dim_dates
                                         WHERE (dim_dates.the_date = ('now'::text)::date))))) a LEFT JOIN (SELECT lower((us.user_email)::text) AS user_unsubscribed_email
                                                                                                           FROM fact_mailchimp_campaign_user_unsubscribes uu,
                                                                                                                dim_users_static us
                                                                                                           WHERE (us.user_key = uu.user_key)) b ON ((a.user_email = b.user_unsubscribed_email))) LEFT JOIN (SELECT lower((s.email_address)::text) AS email_unsubscribed_email
                                                                                                                                                                                                            FROM fact_mailchimp_campaign_email_unsubscribes s) c ON ((a.user_email = c.email_unsubscribed_email)))
       LEFT JOIN (SELECT pi.pitch_key, pi.user_key, count(pi.user_key) AS num_invs
                  FROM fact_pitch_investments pi
                  GROUP BY pi.pitch_key, pi.user_key) d ON (((d.pitch_key = a.pitch_key) AND (d.user_key = a.user_key))))
WHERE ((((d.num_invs IS NULL) AND (b.user_unsubscribed_email IS NULL)) AND (c.email_unsubscribed_email IS NULL)) AND
       (a.subscribed_newsletter = true));

alter table v_hot_investor_lists
  owner to ccdatawh;

