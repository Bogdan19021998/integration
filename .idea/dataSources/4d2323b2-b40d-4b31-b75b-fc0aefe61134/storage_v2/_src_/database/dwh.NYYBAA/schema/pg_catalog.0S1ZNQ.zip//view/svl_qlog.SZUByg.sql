create view svl_qlog as
SELECT sq.userid,
       sq.query,
       sq.xid,
       sq.pid,
       sq.starttime,
       sq.endtime,
       date_diff('microseconds'::text, sq.starttime, sq.endtime) AS elapsed,
       sq.aborted,
       sq."label",
       "substring"((sq.querytxt)::text, 1, 60)                   AS "substring",
       sr.source_query,
       CASE
         WHEN (sq.concurrency_scaling_status = 1) THEN '1 - Ran on a Concurrency Scaling cluster'::text
         ELSE '0 - Ran on the main cluster'::text END            AS concurrency_scaling_status_txt,
       ss.from_sp_call
FROM (((stl_query sq LEFT JOIN stl_result_cache_history sr ON ((sq.query = sr.cache_hit_query))) LEFT JOIN stl_wlm_query sw ON ((
    ((sq.query = sw.query) AND (sq.userid = sw.userid)) AND (sq.xid = sw.xid))))
       LEFT JOIN stl_stored_proc_call_map ss ON ((sq.query = ss.query)));

alter table svl_qlog
  owner to rdsdb;

