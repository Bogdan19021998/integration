create view svv_query_inflight as
SELECT b.userid,
       a.slice,
       a.query,
       a.pid,
       a.starttime,
       a.suspended,
       b.text,
       b."sequence"
FROM stv_inflight a,
     stl_querytext b
WHERE (a.query = b.query);

alter table svv_query_inflight
  owner to rdsdb;

