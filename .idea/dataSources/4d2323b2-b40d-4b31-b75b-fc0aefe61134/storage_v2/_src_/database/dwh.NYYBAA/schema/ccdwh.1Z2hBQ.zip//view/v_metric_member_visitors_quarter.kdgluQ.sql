create view v_metric_member_visitors_quarter as
SELECT dt.year_quarter, count(DISTINCT au.user_key) AS num_unique_members
FROM ((dim_sessions s JOIN dim_dates dt ON ((s.session_start_date_key = dt.date_key)))
       JOIN dim_anon_users_new au ON (((s.anonymousid)::text = (au.anon_id)::text)))
WHERE ((dt.the_date < (('now'::text)::date + 1)) AND (au.user_key <> 0))
GROUP BY dt.year_quarter
ORDER BY dt.year_quarter DESC;

alter table v_metric_member_visitors_quarter
  owner to ccdatawh;

