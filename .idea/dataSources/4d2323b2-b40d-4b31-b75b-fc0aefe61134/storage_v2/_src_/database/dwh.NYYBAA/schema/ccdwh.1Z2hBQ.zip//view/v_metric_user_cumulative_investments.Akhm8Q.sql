create view v_metric_user_cumulative_investments as
SELECT ds.date_key,
       ds.user_key,
       sum(ds.inv_count)
           OVER ( PARTITION BY ds.user_key ORDER BY ds.date_key ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cume
FROM (SELECT uc.snapshot_date_key                                      AS date_key,
             uc.user_key,
             CASE WHEN (inv.c IS NULL) THEN (0)::bigint ELSE inv.c END AS inv_count
      FROM (dim_users_changing uc
             LEFT JOIN (SELECT i.investment_date_key, i.user_key, count(*) AS c
                        FROM (SELECT i.investment_date_key, i.user_key, i.pitch_key, f_i.pitch_key AS first_pitch_key
                              FROM (fact_pitch_investments i
                                     JOIN (SELECT DISTINCT pi.user_key, pi.pitch_key
                                           FROM (fact_pitch_investments pi
                                                  JOIN (SELECT fact_pitch_investments.user_key,
                                                               min(fact_pitch_investments.investment_id) AS investment_id
                                                        FROM fact_pitch_investments
                                                        GROUP BY fact_pitch_investments.user_key) first_inv
                                                       ON (((pi.user_key = first_inv.user_key) AND
                                                            (pi.investment_id = first_inv.investment_id))))) f_i
                                          ON ((i.user_key = f_i.user_key)))) i
                        GROUP BY i.investment_date_key, i.user_key
                        ORDER BY i.investment_date_key) inv
                       ON (((uc.snapshot_date_key = inv.investment_date_key) AND (uc.user_key = inv.user_key))))
      ORDER BY uc.snapshot_date_key, uc.user_key) ds
ORDER BY ds.date_key;

alter table v_metric_user_cumulative_investments
  owner to ccdatawh;

