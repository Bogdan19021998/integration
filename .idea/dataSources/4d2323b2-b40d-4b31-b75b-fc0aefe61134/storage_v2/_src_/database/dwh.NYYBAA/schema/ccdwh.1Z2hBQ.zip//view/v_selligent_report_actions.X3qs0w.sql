create view v_selligent_report_actions as
SELECT f.dt                  AS action_date,
       c.name                AS campaign_name,
       c.campaignid,
       f.user_id             AS user_key,
       f.mail                AS user_email,
       CASE
         WHEN (f.probeid = 0) THEN 'Send'::text
         WHEN (f.probeid = -1) THEN 'Open'::text
         WHEN (f.probeid = -10) THEN 'View Web Version'::text
         WHEN (f.probeid > 100) THEN 'Click'::text
         ELSE NULL::text END AS "action"
FROM (selligent.flags f
       JOIN selligent.campaigns c ON ((f.campaignid = c.campaignid)));

alter table v_selligent_report_actions
  owner to ccdatawh;

