create view v_selligent_engagement_combined_view as
SELECT derived_table1.the_date,
       derived_table1.campaign_name,
       derived_table1.user_group,
       derived_table1.user_key,
       sum(derived_table1.opens)           AS opens,
       sum(derived_table1.clicks)          AS clicks,
       sum(derived_table1.view_web)        AS view_web,
       sum(derived_table1.send)            AS send,
       sum(derived_table1.unknown_action)  AS unknown_actions,
       sum(derived_table1.num_sessions)    AS num_sessions,
       sum(derived_table1.num_investments) AS num_investments,
       sum(derived_table1.val_investments) AS val_investments,
       sum(derived_table1.val_fee)         AS val_fee
FROM (SELECT v_selligent_engagement_actions.the_date,
             CASE
               WHEN (((v_selligent_engagement_actions.selligent_campaign)::text ~~ 'Personalised Summary%'::text) OR
                     ((v_selligent_engagement_actions.selligent_campaign)::text ~~ 'weekly_summary%'::text))
                 THEN 'weekly_summary'::character varying
               ELSE v_selligent_engagement_actions.selligent_campaign END   AS campaign_name,
             (v_selligent_engagement_actions.user_group)::character varying AS user_group,
             v_selligent_engagement_actions.user_key,
             v_selligent_engagement_actions.opens,
             v_selligent_engagement_actions.clicks,
             v_selligent_engagement_actions.view_web,
             v_selligent_engagement_actions.send,
             v_selligent_engagement_actions.unknown_action,
             0                                                              AS num_sessions,
             0                                                              AS num_investments,
             0                                                              AS val_investments,
             0                                                              AS val_fee
      FROM v_selligent_engagement_actions
      WHERE (v_selligent_engagement_actions.the_date >= '2016-09-01'::date)
      UNION ALL
      SELECT v_selligent_engagement.the_date,
             CASE
               WHEN ((v_selligent_engagement.campaign_name)::text ~~ 'weekly_summary%'::text)
                 THEN 'weekly_summary'::character varying
               ELSE v_selligent_engagement.campaign_name END        AS campaign_name,
             (v_selligent_engagement.user_group)::character varying AS user_group,
             v_selligent_engagement.user_key,
             0,
             0,
             0,
             0,
             0,
             v_selligent_engagement.num_sessions,
             v_selligent_engagement.num_investments,
             v_selligent_engagement.val_investments,
             v_selligent_engagement.val_fee
      FROM v_selligent_engagement
      WHERE (v_selligent_engagement.the_date >= '2016-09-01'::date)) derived_table1
GROUP BY derived_table1.the_date, derived_table1.campaign_name, derived_table1.user_group, derived_table1.user_key
ORDER BY derived_table1.the_date, derived_table1.campaign_name, derived_table1.user_group, derived_table1.user_key;

alter table v_selligent_engagement_combined_view
  owner to ccdatawh;

