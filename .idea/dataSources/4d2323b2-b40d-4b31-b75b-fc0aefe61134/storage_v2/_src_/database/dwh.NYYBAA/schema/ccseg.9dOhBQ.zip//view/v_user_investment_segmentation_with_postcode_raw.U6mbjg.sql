create view v_user_investment_segmentation_with_postcode_raw as
SELECT us.user_key,
       us.user_name,
       us.user_email,
       sp.cardaddresszip                                                                                      AS postcode,
       CASE
         WHEN (inv.investment_count IS NULL) THEN (0)::bigint
         ELSE inv.investment_count END                                                                        AS investment_count,
       CASE
         WHEN (inv.investment_total_amount IS NULL) THEN (0)::numeric
         ELSE inv.investment_total_amount END                                                                 AS investment_total_amount,
       CASE
         WHEN (inv.investment_avg_amount IS NULL) THEN (0)::numeric
         ELSE inv.investment_avg_amount END                                                                   AS investment_avg_amount,
       CASE
         WHEN (inv.investment_max_amount IS NULL) THEN (0)::numeric
         ELSE inv.investment_max_amount END                                                                   AS investment_max_amount,
       CASE
         WHEN (inv.investment_min_amount IS NULL) THEN (0)::numeric
         ELSE inv.investment_min_amount END                                                                   AS investment_min_amount
FROM ((ccseg.tbl_stripe_payments sp LEFT JOIN dim_users_static us ON ((lower((sp.email)::text) = lower((us.user_email)::text))))
       LEFT JOIN (SELECT fact_pitch_investments.user_key,
                         count(*)                                    AS investment_count,
                         sum(fact_pitch_investments.amount_in_gbp)   AS investment_total_amount,
                         avg(fact_pitch_investments.amount_in_gbp)   AS investment_avg_amount,
                         "max"(fact_pitch_investments.amount_in_gbp) AS investment_max_amount,
                         min(fact_pitch_investments.amount_in_gbp)   AS investment_min_amount
                  FROM fact_pitch_investments
                  GROUP BY fact_pitch_investments.user_key) inv ON ((us.user_key = inv.user_key)))
WHERE ((us.user_key IS NOT NULL) AND (inv.investment_total_amount IS NOT NULL));

alter table v_user_investment_segmentation_with_postcode_raw
  owner to ccdatawh;

