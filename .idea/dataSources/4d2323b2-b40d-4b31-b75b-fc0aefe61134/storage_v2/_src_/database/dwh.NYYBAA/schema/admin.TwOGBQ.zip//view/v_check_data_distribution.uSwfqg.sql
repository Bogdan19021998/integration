create view v_check_data_distribution as
SELECT perm.slice,
       pgn.oid                                                                                              AS schema_oid,
       pgn.nspname                                                                                          AS schemaname,
       perm.id                                                                                              AS tbl_oid,
       perm.name                                                                                            AS tablename,
       stv."diststyle",
       stv.sortkey1                                                                                         AS "sortkey",
       perm."rows"                                                                                          AS rowcount_on_slice,
       sum(perm."rows")
           OVER ( PARTITION BY perm.name, perm.id ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS total_rowcount,
       CASE
         WHEN ((perm."rows" IS NULL) OR (perm."rows" = 0)) THEN (0)::double precision
         ELSE round((((perm."rows")::double precision / (sum(perm."rows")
                                                             OVER ( PARTITION BY perm.id ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING))::double precision) *
                     (100)::double precision),
                    ((3)::numeric)::numeric(18, 0)) END                                                     AS distrib_pct,
       CASE
         WHEN ((perm."rows" IS NULL) OR (perm."rows" = 0)) THEN (0)::double precision
         ELSE round((((min(perm."rows")
                           OVER ( PARTITION BY perm.id ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING))::double precision /
                      (sum(perm."rows")
                           OVER ( PARTITION BY perm.id ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING))::double precision) *
                     (100)::double precision),
                    ((3)::numeric)::numeric(18, 0)) END                                                     AS min_distrib_pct,
       CASE
         WHEN ((perm."rows" IS NULL) OR (perm."rows" = 0)) THEN (0)::double precision
         ELSE round(((("max"(perm."rows")
                             OVER ( PARTITION BY perm.id ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING))::double precision /
                      (sum(perm."rows")
                           OVER ( PARTITION BY perm.id ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING))::double precision) *
                     (100)::double precision),
                    ((3)::numeric)::numeric(18, 0)) END                                                     AS max_distrib_pct
FROM (((stv_tbl_perm perm JOIN pg_class pgc ON ((pgc.oid = (perm.id)::oid))) JOIN pg_namespace pgn ON ((pgn.oid = pgc.relnamespace)))
       JOIN svv_table_info stv ON (((stv."schema" = ((pgn.nspname)::character varying)::text) AND
                                    (stv."table" = ((perm.name)::character varying)::text))))
WHERE ((perm.slice < 3201) AND (pgc.relowner > 1));

alter table v_check_data_distribution
  owner to ccdatawh;

