create view svl_s3catalog as
SELECT stl_external_catalog_calls.query,
       stl_external_catalog_calls.segment,
       stl_external_catalog_calls.node,
       stl_external_catalog_calls.slice,
       stl_external_catalog_calls.eventtime,
       stl_external_catalog_calls."call",
       stl_external_catalog_calls.objects,
       stl_external_catalog_calls.duration
FROM stl_external_catalog_calls;

alter table svl_s3catalog
  owner to rdsdb;

