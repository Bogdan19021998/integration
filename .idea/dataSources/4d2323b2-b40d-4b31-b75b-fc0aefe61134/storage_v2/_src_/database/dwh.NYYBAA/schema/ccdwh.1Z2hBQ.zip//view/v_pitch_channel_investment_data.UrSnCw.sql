create or replace view ccdwh.v_pitch_channel_investment_data
as

select distinct channeldata.pitch_key
              , pitches.pitch_name
              , channeldata.user_key
              , inv.investment_date_key as request_date_key
              , channeldata.channel
              , channeldata.source
              , inv.amount
              , inv.investment_timestamp
from (
       select distinct fe.pitch_key
                     , fe.request_timestamp
                     , sa.user_key
                     , sa.anonymousid
                     , sa.request_date_date_key as request_date_key
                     , sa.channel
                     , sa.source
       from materialised_views.fact_session_attribution_last_non_direct_30_days sa
              inner join ccdwh.fact_engagement fe on sa.session_key = fe.session_key
              inner join ccdwh.dim_events e on fe.event_key = e.event_key
              inner join ccdwh.dim_sessions s on sa.session_key = s.session_key
       where e.event_name in ('Completed Order', 'investment_completed', 'Investment completed')
         and sa.user_key > 0
         and sa.user_key not in (431094, 436557, 528356, 582970)----Brewdog and SeedInvest user keys
         and fe.pitch_key > 0
         and s.duration_seconds >= 9
       order by fe.pitch_key
     ) channeldata
       inner join
     (
       select distinct pi.user_key
                     , pi.amount
                     , pi.pitch_key
                     , pi.investment_date_key
                     , pi.investment_status
                     , pi.investment_timestamp
       from ccdwh.fact_pitch_investments pi
       where pi.user_key not in (431094, 436557, 528356, 582970)
         and pi.investment_status in ('paid', 'live', 'captured', 'withdrawn')
     ) inv on inv.user_key = channeldata.user_key
       and inv.pitch_key = channeldata.pitch_key
       and abs(datediff(minute, inv.investment_timestamp, channeldata.request_timestamp)) < 3
       join ccdwh.dim_pitches_static pitches on pitches.pitch_key = channeldata.pitch_key
  WITH NO SCHEMA BINDING;

alter table v_pitch_channel_investment_data
  owner to ccdatawh;

