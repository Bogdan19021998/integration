create view v_top_five_sectors_by_amount_last_30_days as
SELECT sum(pi.amount_in_gbp) AS sum, count(pi.transaction_id) AS frequency, s.sector_name
FROM ccdwh_dev.fact_pitch_investments pi,
     ccdwh_dev.dim_pitches_static ps,
     ccdwh_dev.dim_sectors s,
     ccdwh_dev.fact_pitch_sectors psec
WHERE ((((((pi.pitch_key = ps.pitch_key) AND (pi.pitch_key = psec.pitch_key)) AND (psec.sector_key = s.sector_key)) AND
         ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND
        (pi.investment_date_key >= (SELECT (dim_dates.date_key - 31)
                                    FROM ccdwh_dev.dim_dates
                                    WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
       (pi.investment_date_key < (SELECT dim_dates.date_key
                                  FROM ccdwh_dev.dim_dates
                                  WHERE (dim_dates.the_date = ('now'::character varying)::date))))
GROUP BY s.sector_name
ORDER BY sum(pi.amount_in_gbp) DESC
LIMIT 5;

alter table v_top_five_sectors_by_amount_last_30_days
  owner to ccdatawh;

