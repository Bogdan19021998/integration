create view v_distil_sahara_funded_companies as
SELECT raise.company_name,
       raise.company_number,
       raise.total,
       raise.num_raises,
       raise.raise_band,
       CASE
         WHEN (failed.registered_company_number IS NOT NULL) THEN 'Failed'::text
         WHEN (indistress.company_number IS NOT NULL) THEN 'In Distress'::text
         ELSE 'Active / Unknown'::text END                                    AS company_status,
       CASE WHEN (bh.companies_house_number IS NULL) THEN false ELSE true END AS in_beahurst
FROM ((((SELECT cnp.company_number, cnp.total, cnp.num_raises, cnp.raise_band, ap.company_key, ap.company_name
         FROM ((SELECT p.company_number,
                       sum(p.reached_amount) AS total,
                       count(*)              AS num_raises,
                       CASE
                         WHEN (sum(p.reached_amount) <= (100000)::numeric) THEN '0-100k'::text
                         WHEN (sum(p.reached_amount) <= (250000)::numeric) THEN '101-250k'::text
                         WHEN (sum(p.reached_amount) <= (500000)::numeric) THEN '251-500k'::text
                         WHEN (sum(p.reached_amount) <= (750000)::numeric) THEN '501-750k'::text
                         WHEN ((751000)::numeric < sum(p.reached_amount)) THEN '751+'::text
                         ELSE NULL::text END AS raise_band
                FROM (SELECT pl.reached_amount,
                             pl.company_key,
                             pcn.company_number,
                             pl.company_name,
                             pg_catalog.row_number()
                             OVER ( PARTITION BY pcn.company_number ORDER BY pl.pitch_expiry_date_key DESC) AS rn
                      FROM (v_master_pitches_latest pl
                             JOIN v_master_pitch_companynumber pcn ON ((pl.pitch_key = pcn.pitch_key)))
                      WHERE ((((pl.pitch_status)::text = 'Funded'::text) AND (NOT (pl.pitch_key IN
                                                                                   (SELECT fact_test_pitch_exclude.pitch_key
                                                                                    FROM fact_test_pitch_exclude)))) AND
                             (pcn.company_number IS NOT NULL))) p
                GROUP BY p.company_number) cnp
                JOIN (SELECT pl.reached_amount,
                             pl.company_key,
                             pcn.company_number,
                             pl.company_name,
                             pg_catalog.row_number()
                             OVER ( PARTITION BY pcn.company_number ORDER BY pl.pitch_expiry_date_key DESC) AS rn
                      FROM (v_master_pitches_latest pl
                             JOIN v_master_pitch_companynumber pcn ON ((pl.pitch_key = pcn.pitch_key)))
                      WHERE ((((pl.pitch_status)::text = 'Funded'::text) AND (NOT (pl.pitch_key IN
                                                                                   (SELECT fact_test_pitch_exclude.pitch_key
                                                                                    FROM fact_test_pitch_exclude)))) AND
                             (pcn.company_number IS NOT NULL))) ap
                     ON (((cnp.company_number)::text = (ap.company_number)::text)))
         WHERE (ap.rn = 1)) raise LEFT JOIN fact_failed_company_dates failed ON (((raise.company_number)::text =
                                                                                  (failed.registered_company_number)::text))) LEFT JOIN (SELECT DISTINCT pcn.company_number
                                                                                                                                         FROM (((dim_pitches_static p JOIN dim_companies_static cs ON ((cs.company_key = p.company_key))) JOIN (SELECT dim_companies_changing.company_key
                                                                                                                                                                                                                                                FROM dim_companies_changing
                                                                                                                                                                                                                                                WHERE ((dim_companies_changing.snapshot_date_key =
                                                                                                                                                                                                                                                        (SELECT "max"(dim_companies_changing.snapshot_date_key) AS "max"
                                                                                                                                                                                                                                                         FROM dim_companies_changing)) AND
                                                                                                                                                                                                                                                       ((((((dim_companies_changing.company_status)::text = 'Dissolved'::text) OR
                                                                                                                                                                                                                                                           ((dim_companies_changing.company_status)::text =
                                                                                                                                                                                                                                                            'Voluntary Arrangement'::text)) OR
                                                                                                                                                                                                                                                          ((dim_companies_changing.company_status)::text = 'Liquidation'::text)) OR
                                                                                                                                                                                                                                                         ((dim_companies_changing.company_status)::text =
                                                                                                                                                                                                                                                          'Active - Proposal to Strike off'::text)) OR
                                                                                                                                                                                                                                                        ((dim_companies_changing.company_status)::text =
                                                                                                                                                                                                                                                         'In Administration'::text)))) cc ON ((cc.company_key = cs.company_key)))
                                                                                                                                                JOIN v_master_pitch_companynumber pcn ON ((p.pitch_key = pcn.pitch_key)))) indistress ON (((indistress.company_number)::text = (raise.company_number)::text)))
       LEFT JOIN (SELECT DISTINCT beauhurst_data_import_monthly.companies_house_number
                  FROM sahara.beauhurst_data_import_monthly) bh
                 ON (((bh.companies_house_number)::text = (raise.company_number)::text)));

alter table v_distil_sahara_funded_companies
  owner to ccdatawh;

