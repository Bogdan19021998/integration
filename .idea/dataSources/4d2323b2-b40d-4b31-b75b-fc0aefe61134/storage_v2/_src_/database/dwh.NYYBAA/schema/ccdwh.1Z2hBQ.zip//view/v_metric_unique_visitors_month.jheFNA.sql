create view v_metric_unique_visitors_month as
SELECT dt.year_month, count(DISTINCT s.anonymousid) AS num_unique_visitors
FROM (dim_sessions s
       JOIN dim_dates dt ON ((s.session_start_date_key = dt.date_key)))
WHERE ((dt.the_date < (('now'::text)::date + 1)) AND ((dt.year_month)::text >= '2015/03'::text))
GROUP BY dt.year_month
ORDER BY dt.year_month DESC;

alter table v_metric_unique_visitors_month
  owner to ccdatawh;

