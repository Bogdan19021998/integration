create view v_number_of_investments_by_company_region_last_30_days as
SELECT count(y.transaction_id) AS frequency, y."location"
FROM (SELECT x.amount,
             x.transaction_id,
             CASE
               WHEN ("position"(x."location", (','::character varying)::text) = 0) THEN x."location"
               ELSE "substring"(x."location",
                                ("position"(x."location", (','::character varying)::text) + 2)) END AS "location"
      FROM (SELECT pi.amount_in_gbp                                                                                AS amount,
                   pi.transaction_id,
                   CASE
                     WHEN ("position"((ps."location")::text, (','::character varying)::text) = 0) THEN (ps."location")::text
                     ELSE "substring"((ps."location")::text,
                                      ("position"((ps."location")::text, (','::character varying)::text) +
                                       2)) END                                                                     AS "location"
            FROM ccdwh_dev.fact_pitch_investments pi,
                 ccdwh_dev.dim_pitches_static ps
            WHERE ((((pi.pitch_key = ps.pitch_key) AND
                     ((ps.portal_name)::text = ('crowdcube'::character varying)::text)) AND
                    (pi.investment_date_key >= (SELECT (dim_dates.date_key - 31)
                                                FROM ccdwh_dev.dim_dates
                                                WHERE (dim_dates.the_date = ('now'::character varying)::date)))) AND
                   (pi.investment_date_key < (SELECT dim_dates.date_key
                                              FROM ccdwh_dev.dim_dates
                                              WHERE (dim_dates.the_date = ('now'::character varying)::date))))) x) y
GROUP BY y."location"
ORDER BY count(y.transaction_id) DESC;

alter table v_number_of_investments_by_company_region_last_30_days
  owner to ccdatawh;

