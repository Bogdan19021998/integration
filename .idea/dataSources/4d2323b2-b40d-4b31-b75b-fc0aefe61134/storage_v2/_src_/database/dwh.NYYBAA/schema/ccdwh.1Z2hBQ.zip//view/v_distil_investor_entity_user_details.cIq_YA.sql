create view v_distil_investor_entity_user_details as
SELECT c.user_key,
       s.user_name,
       s.encrypted_user_id,
       s.user_firstname                                                                                           AS firstname,
       s.user_lastname                                                                                            AS lastname,
       c.users_email                                                                                              AS email,
       (((s.user_firstname)::text + ' '::text) + (s.user_lastname)::text)                                         AS fullname,
       s.private_address_town                                                                                     AS address_town,
       CASE
         WHEN (s.private_address_county IS NULL) THEN s.private_address_town
         ELSE s.private_address_county END                                                                        AS address_county,
       s.private_address_post_code                                                                                AS address_postcode,
       s.private_address_country                                                                                  AS address_country,
       s.gender,
       c.user_category                                                                                            AS investor_category_selfcertified,
       c.investor_type_classification                                                                             AS investor_category_from_behaviour,
       c.aml_status_checked_count,
       c.aml_status_last_interpreted_result,
       c.crowdcube_active_user                                                                                    AS active_user,
       c.pitch_owner_type,
       c.selligent_active_user,
       c.subscribed_marketing,
       (d.date_key - COALESCE(s.registered_date_key, 0))                                                          AS registered_days_ago,
       s.portal
FROM ((dim_users_static s JOIN (SELECT dim_users_changing.user_key,
                                       dim_users_changing.users_email,
                                       dim_users_changing.user_category,
                                       dim_users_changing.investor_type_classification,
                                       dim_users_changing.aml_status_checked_count,
                                       dim_users_changing.aml_status_last_interpreted_result,
                                       dim_users_changing.crowdcube_active_user,
                                       dim_users_changing.pitch_owner_type,
                                       dim_users_changing.selligent_active_user,
                                       dim_users_changing.subscribed_marketing
                                FROM dim_users_changing
                                WHERE (dim_users_changing.snapshot_date_key =
                                       (SELECT "max"(dim_users_changing.snapshot_date_key) AS "max"
                                        FROM dim_users_changing))) c ON ((c.user_key = s.user_key)))
       JOIN (SELECT dim_dates.date_key FROM dim_dates WHERE (dim_dates.the_date = ('now'::text)::date)) d ON ((1 = 1)))
ORDER BY c.user_key;

alter table v_distil_investor_entity_user_details
  owner to ccdatawh;

