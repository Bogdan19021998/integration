create view v_mailchimp_sync_list as
SELECT uc.user_key,
       lower((u.user_email)::text)                    AS lower,
       u.user_firstname,
       u.user_lastname,
       uc.subscribed_newsletter,
       uc.subscribed_summary,
       uc.deleted,
       uc.user_type,
       CASE
         WHEN (uc.non_investor_newsletter_category IS NULL) THEN 'Excluded'::character varying
         ELSE uc.non_investor_newsletter_category END AS non_investor_newsletter_category,
       CASE
         WHEN ((uc.snapshot_date_key - u.registered_date_key) = 1) THEN 'One day post registration'::text
         WHEN ((uc.snapshot_date_key - u.registered_date_key) = 2) THEN 'Two day post registration'::text
         ELSE 'Excluded'::text END                    AS post_registration_engagement_category,
       (uc.snapshot_date_key - u.registered_date_key) AS num_days_registered_ago
FROM ((dim_users_changing uc JOIN (SELECT dim_users_changing.user_key,
                                          "max"(dim_users_changing.snapshot_date_key) AS date_key
                                   FROM dim_users_changing
                                   GROUP BY dim_users_changing.user_key) udk ON (((uc.user_key = udk.user_key) AND
                                                                                  (uc.snapshot_date_key = udk.date_key))))
       JOIN dim_users_static u ON ((uc.user_key = u.user_key)))
WHERE ((uc.snapshot_date_key - u.registered_date_key) < 40)
ORDER BY (uc.snapshot_date_key - u.registered_date_key) DESC;

alter table v_mailchimp_sync_list
  owner to ccdatawh;

