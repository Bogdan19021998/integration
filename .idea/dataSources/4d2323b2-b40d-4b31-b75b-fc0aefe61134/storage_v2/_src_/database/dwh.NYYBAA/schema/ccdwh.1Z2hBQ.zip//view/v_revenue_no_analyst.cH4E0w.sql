create view v_revenue_no_analyst as
  (((((SELECT d.the_date,
              d.year_month,
              d.year_quarter,
              'Invoiced'        AS pitch_status,
              ps.product_type,
              fpc.pitch_key,
              ps.pitch_name,
              pc.progress_percent,
              pc.reached_amount AS investment_amount,
              fpc.commission_amount,
              1                 AS funded_pitch
       FROM fact_pitch_commission fpc,
            dim_dates d,
            dim_pitches_changing pc,
            dim_pitches_static ps
       WHERE ((((fpc.pitch_key = ps.pitch_key) AND (ps.pitch_key = pc.pitch_key)) AND (pc.snapshot_date_key =
                                                                                       (SELECT dim_dates.date_key
                                                                                        FROM dim_dates
                                                                                        WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
              CASE
                WHEN ((((((((((ps.pitch_key = 19325) OR (ps.pitch_key = 20660)) OR (ps.pitch_key = 20725)) OR
                            (ps.pitch_key = 20721)) OR (ps.pitch_key = 20655)) OR (ps.pitch_key = 20656)) OR
                         (ps.pitch_key = 21100)) OR (ps.pitch_key = 21019)) OR (ps.pitch_key = 21030)) OR
                      (ps.pitch_key = 20830)) THEN ((pc.closed_date_key - 1) = d.date_key)
                ELSE (pc.closed_date_key = d.date_key) END)
       UNION
       SELECT d.the_date,
              d.year_month,
              d.year_quarter,
              'Closed not yet invoiced' AS pitch_status,
              ps.product_type,
              pi.pitch_key,
              ps.pitch_name,
              pc.progress_percent,
              sum(pi.amount)            AS investment_amount,
              sum(pi.fee_amount)        AS commission_amount,
              1                         AS funded_pitch
       FROM fact_pitch_investments pi,
            dim_pitches_changing pc,
            dim_dates d,
            dim_pitches_static ps
       WHERE ((((((((((pi.pitch_key = ps.pitch_key) AND
                      (NOT (pi.pitch_key IN (SELECT fact_pitch_commission.pitch_key FROM fact_pitch_commission)))) AND
                     (pi.pitch_key <> 14190)) AND (ps.pitch_key = pc.pitch_key)) AND (pc.snapshot_date_key =
                                                                                      (SELECT dim_dates.date_key
                                                                                       FROM dim_dates
                                                                                       WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
                  ((((pc.pitch_status)::text = 'Active'::text) OR ((pc.pitch_status)::text = 'Funded'::text)) OR
                   ((pc.pitch_status)::text = 'Active Hidden Private'::text))) AND (pc.closed_date_key <> 1)) AND CASE
                                                                                                                    WHEN (
                                                                                                                        (((((((((ps.pitch_key = 19325) OR (ps.pitch_key = 20660)) OR
                                                                                                                               (ps.pitch_key = 20725)) OR
                                                                                                                              (ps.pitch_key = 20721)) OR
                                                                                                                             (ps.pitch_key = 20655)) OR
                                                                                                                            (ps.pitch_key = 20656)) OR
                                                                                                                           (ps.pitch_key = 21100)) OR
                                                                                                                          (ps.pitch_key = 21019)) OR
                                                                                                                         (ps.pitch_key = 21030)) OR
                                                                                                                        (ps.pitch_key = 20830))
                                                                                                                      THEN ((pc.closed_date_key - 1) = d.date_key)
                                                                                                                    ELSE (pc.closed_date_key = d.date_key) END) AND
               ((ps.portal_name)::text = 'crowdcube'::text)) AND
              (((pi.investment_status)::text <> 'cancelled'::text) AND
               ((pi.investment_status)::text <> 'refunded'::text)))
       GROUP BY d.the_date, d.year_month, d.year_quarter, pi.pitch_key, ps.pitch_name, ps.product_type,
                pc.progress_percent)
      UNION
      SELECT d.the_date,
             d.year_month,
             d.year_quarter,
             'Funded not yet closed' AS pitch_status,
             ps.product_type,
             pi.pitch_key,
             ps.pitch_name,
             pc.progress_percent,
             sum(pi.amount)          AS investment_amount,
             sum(pi.fee_amount)      AS commission_amount,
             0                       AS funded_pitch
      FROM fact_pitch_investments pi,
           dim_pitches_changing pc,
           dim_dates d,
           dim_pitches_static ps
      WHERE ((((((((pi.pitch_key = ps.pitch_key) AND (ps.pitch_key = pc.pitch_key)) AND (pc.snapshot_date_key =
                                                                                         (SELECT dim_dates.date_key
                                                                                          FROM dim_dates
                                                                                          WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
                 ((pc.pitch_status)::text = 'Active'::text)) AND (pc.closed_date_key = 1)) AND
               ((ps.portal_name)::text = 'crowdcube'::text)) AND (d.date_key = pc.snapshot_date_key)) AND
             (pc.progress_percent >= (100)::numeric))
      GROUP BY d.the_date, d.year_month, d.year_quarter, pi.pitch_key, ps.pitch_name, ps.product_type,
               pc.progress_percent)
     UNION
     SELECT d.the_date,
            d.year_month,
            d.year_quarter,
            'Active not yet funded' AS pitch_status,
            ps.product_type,
            pi.pitch_key,
            ps.pitch_name,
            pc.progress_percent,
            sum(pi.amount)          AS investment_amount,
            sum(pi.fee_amount)      AS commission_amount,
            0                       AS funded_pitch
     FROM fact_pitch_investments pi,
          dim_pitches_changing pc,
          dim_dates d,
          dim_pitches_static ps
     WHERE ((((((((pi.pitch_key = ps.pitch_key) AND (ps.pitch_key = pc.pitch_key)) AND (pc.snapshot_date_key =
                                                                                        (SELECT dim_dates.date_key
                                                                                         FROM dim_dates
                                                                                         WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
                ((pc.pitch_status)::text = 'Active'::text)) AND (pc.closed_date_key = 1)) AND
              ((ps.portal_name)::text = 'crowdcube'::text)) AND (d.date_key = pc.snapshot_date_key)) AND
            (pc.progress_percent < (100)::numeric))
     GROUP BY d.the_date, d.year_month, d.year_quarter, pi.pitch_key, ps.pitch_name, ps.product_type,
              pc.progress_percent)
    UNION
    SELECT d.the_date,
           d.year_month,
           d.year_quarter,
           'Did not fund' AS pitch_status,
           ps.product_type,
           ps.pitch_key,
           ps.pitch_name,
           pc.progress_percent,
           0              AS investment_amount,
           0              AS commission_amount,
           0              AS funded_pitch
    FROM dim_pitches_changing pc,
         dim_dates d,
         dim_pitches_static ps
    WHERE ((((((ps.pitch_key = pc.pitch_key) AND (pc.snapshot_date_key = (SELECT dim_dates.date_key
                                                                          FROM dim_dates
                                                                          WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
              (((pc.pitch_status)::text = 'Cancelled'::text) OR ((pc.pitch_status)::text = 'Expired'::text))) AND
             ((ps.portal_name)::text = 'crowdcube'::text)) AND (d.date_key = pc.snapshot_date_key)) AND
           (pc.progress_percent < (100)::numeric)))
   UNION
   SELECT d.the_date,
          d.year_month,
          d.year_quarter,
          'Active - no commission' AS pitch_status,
          ps.product_type,
          pi.pitch_key,
          ps.pitch_name,
          pc.progress_percent,
          0                        AS investment_amount,
          0                        AS commission_amount,
          0                        AS funded_pitch
   FROM fact_pitch_investments pi,
        dim_pitches_changing pc,
        dim_dates d,
        dim_pitches_static ps
   WHERE ((((((((pi.pitch_key = ps.pitch_key) AND (ps.pitch_key = pc.pitch_key)) AND (pc.snapshot_date_key =
                                                                                      (SELECT dim_dates.date_key
                                                                                       FROM dim_dates
                                                                                       WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
              ((pc.pitch_status)::text = 'Active'::text)) AND (pc.closed_date_key = 1)) AND
            ((ps.portal_name)::text = 'crowdcube'::text)) AND (d.date_key = pc.snapshot_date_key)) AND
          (pc.progress_percent < (100)::numeric))
   GROUP BY d.the_date, d.year_month, d.year_quarter, pi.pitch_key, ps.pitch_name, ps.product_type, pc.progress_percent)
  UNION
  SELECT d.the_date,
         d.year_month,
         d.year_quarter,
         'Pending' AS pitch_status,
         ps.product_type,
         ps.pitch_key,
         ps.pitch_name,
         pc.progress_percent,
         0         AS investment_amount,
         0         AS commission_amount,
         0         AS funded_pitch
  FROM dim_pitches_changing pc,
       dim_dates d,
       dim_pitches_static ps
  WHERE (((((((ps.pitch_key = pc.pitch_key) AND (pc.snapshot_date_key = (SELECT dim_dates.date_key
                                                                         FROM dim_dates
                                                                         WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
             (((((pc.pitch_status)::text = 'Pending'::text) OR ((pc.pitch_status)::text = 'Approved'::text)) OR
               ((pc.pitch_status)::text = 'Manual Pending'::text)) OR
              ((pc.pitch_status)::text = 'Publish Pending'::text))) AND (pc.closed_date_key = 1)) AND
           ((ps.portal_name)::text = 'crowdcube'::text)) AND (d.date_key = pc.snapshot_date_key)) AND
         (pc.progress_percent < (100)::numeric))
  GROUP BY d.the_date, d.year_month, d.year_quarter, ps.pitch_key, ps.pitch_name, ps.product_type, pc.progress_percent
  ORDER BY 1, 4;

alter table v_revenue_no_analyst
  owner to ccdatawh;

