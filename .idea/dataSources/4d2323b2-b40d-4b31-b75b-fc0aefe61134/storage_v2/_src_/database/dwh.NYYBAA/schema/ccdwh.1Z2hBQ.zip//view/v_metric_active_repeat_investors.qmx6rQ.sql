create view v_metric_active_repeat_investors as
SELECT dt.the_date,
       num30.repeat_active_investor_30_day,
       num60.repeat_active_investor_60_day,
       num90.repeat_active_investor_90_day
FROM (((dim_dates dt LEFT JOIN (SELECT dt.the_date, count(DISTINCT us.user_key) AS repeat_active_investor_30_day
                                FROM (((dim_dates dt JOIN (SELECT i.investment_id,
                                                                  i.transaction_id,
                                                                  i.investment_date_key,
                                                                  i.investment_timestamp,
                                                                  i.update_date_key,
                                                                  i.update_timestamp,
                                                                  i.pitch_key,
                                                                  i.user_key,
                                                                  i.amount,
                                                                  i.currency_iso_code,
                                                                  i.currency_symbol,
                                                                  i.exchange_rate_to_gbp,
                                                                  i.payment_method,
                                                                  i.amount_in_gbp,
                                                                  i.investor_count_key,
                                                                  i.pitch_progress_key,
                                                                  i.remaining_timespan_key,
                                                                  i.session_key,
                                                                  i.investment_status,
                                                                  i.fee_percentage,
                                                                  i.fee_amount,
                                                                  i.investment_source
                                                           FROM ((fact_pitch_investments i JOIN dim_users_static us ON ((us.user_key = i.user_key)))
                                                                  JOIN (SELECT DISTINCT pi.user_key, pi.pitch_key
                                                                        FROM (fact_pitch_investments pi
                                                                               JOIN (SELECT fact_pitch_investments.user_key,
                                                                                            min(fact_pitch_investments.investment_id) AS investment_id
                                                                                     FROM fact_pitch_investments
                                                                                     GROUP BY fact_pitch_investments.user_key) first_inv
                                                                                    ON ((
                                                                                        (pi.user_key = first_inv.user_key) AND
                                                                                        (pi.investment_id = first_inv.investment_id))))) f_i
                                                                       ON ((i.user_key = f_i.user_key)))
                                                           WHERE (((us.portal)::text = 'crowdcube'::text) AND
                                                                  (i.pitch_key <> f_i.pitch_key))
                                                           ORDER BY i.investment_date_key) i ON ((
                                    (i.investment_date_key >= (dt.date_key - 30)) AND
                                    (i.investment_date_key <= dt.date_key)))) JOIN dim_users_static us ON ((i.user_key = us.user_key)))
                                       JOIN dim_pitches_static ps ON ((i.pitch_key = ps.pitch_key)))
                                WHERE ((((us.portal)::text = 'crowdcube'::text) AND
                                        ((ps.portal_name)::text = 'crowdcube'::text)) AND
                                       (dt.the_date <= ('now'::text)::date))
                                GROUP BY dt.the_date) num30 ON ((dt.the_date = num30.the_date))) LEFT JOIN (SELECT dt.the_date,
                                                                                                                   count(DISTINCT us.user_key) AS repeat_active_investor_60_day
                                                                                                            FROM (((dim_dates dt JOIN (SELECT i.investment_id,
                                                                                                                                              i.transaction_id,
                                                                                                                                              i.investment_date_key,
                                                                                                                                              i.investment_timestamp,
                                                                                                                                              i.update_date_key,
                                                                                                                                              i.update_timestamp,
                                                                                                                                              i.pitch_key,
                                                                                                                                              i.user_key,
                                                                                                                                              i.amount,
                                                                                                                                              i.currency_iso_code,
                                                                                                                                              i.currency_symbol,
                                                                                                                                              i.exchange_rate_to_gbp,
                                                                                                                                              i.payment_method,
                                                                                                                                              i.amount_in_gbp,
                                                                                                                                              i.investor_count_key,
                                                                                                                                              i.pitch_progress_key,
                                                                                                                                              i.remaining_timespan_key,
                                                                                                                                              i.session_key,
                                                                                                                                              i.investment_status,
                                                                                                                                              i.fee_percentage,
                                                                                                                                              i.fee_amount,
                                                                                                                                              i.investment_source
                                                                                                                                       FROM ((fact_pitch_investments i JOIN dim_users_static us ON ((us.user_key = i.user_key)))
                                                                                                                                              JOIN (SELECT DISTINCT pi.user_key, pi.pitch_key
                                                                                                                                                    FROM (fact_pitch_investments pi
                                                                                                                                                           JOIN (SELECT fact_pitch_investments.user_key,
                                                                                                                                                                        min(fact_pitch_investments.investment_id) AS investment_id
                                                                                                                                                                 FROM fact_pitch_investments
                                                                                                                                                                 GROUP BY fact_pitch_investments.user_key) first_inv
                                                                                                                                                                ON ((
                                                                                                                                                                    (pi.user_key = first_inv.user_key) AND
                                                                                                                                                                    (pi.investment_id = first_inv.investment_id))))) f_i
                                                                                                                                                   ON ((i.user_key = f_i.user_key)))
                                                                                                                                       WHERE (((us.portal)::text = 'crowdcube'::text) AND
                                                                                                                                              (i.pitch_key <> f_i.pitch_key))
                                                                                                                                       ORDER BY i.investment_date_key) i ON ((
                                                                                                                (i.investment_date_key >= (dt.date_key - 60)) AND
                                                                                                                (i.investment_date_key <= dt.date_key)))) JOIN dim_users_static us ON ((i.user_key = us.user_key)))
                                                                                                                   JOIN dim_pitches_static ps ON ((i.pitch_key = ps.pitch_key)))
                                                                                                            WHERE ((((us.portal)::text = 'crowdcube'::text) AND
                                                                                                                    ((ps.portal_name)::text = 'crowdcube'::text)) AND
                                                                                                                   (dt.the_date <= ('now'::text)::date))
                                                                                                            GROUP BY dt.the_date) num60 ON ((dt.the_date = num60.the_date)))
       LEFT JOIN (SELECT dt.the_date, count(DISTINCT us.user_key) AS repeat_active_investor_90_day
                  FROM (((dim_dates dt JOIN (SELECT i.investment_id,
                                                    i.transaction_id,
                                                    i.investment_date_key,
                                                    i.investment_timestamp,
                                                    i.update_date_key,
                                                    i.update_timestamp,
                                                    i.pitch_key,
                                                    i.user_key,
                                                    i.amount,
                                                    i.currency_iso_code,
                                                    i.currency_symbol,
                                                    i.exchange_rate_to_gbp,
                                                    i.payment_method,
                                                    i.amount_in_gbp,
                                                    i.investor_count_key,
                                                    i.pitch_progress_key,
                                                    i.remaining_timespan_key,
                                                    i.session_key,
                                                    i.investment_status,
                                                    i.fee_percentage,
                                                    i.fee_amount,
                                                    i.investment_source
                                             FROM ((fact_pitch_investments i JOIN dim_users_static us ON ((us.user_key = i.user_key)))
                                                    JOIN (SELECT DISTINCT pi.user_key, pi.pitch_key
                                                          FROM (fact_pitch_investments pi
                                                                 JOIN (SELECT fact_pitch_investments.user_key,
                                                                              min(fact_pitch_investments.investment_id) AS investment_id
                                                                       FROM fact_pitch_investments
                                                                       GROUP BY fact_pitch_investments.user_key) first_inv
                                                                      ON (((pi.user_key = first_inv.user_key) AND
                                                                           (pi.investment_id = first_inv.investment_id))))) f_i
                                                         ON ((i.user_key = f_i.user_key)))
                                             WHERE (((us.portal)::text = 'crowdcube'::text) AND
                                                    (i.pitch_key <> f_i.pitch_key))
                                             ORDER BY i.investment_date_key) i ON ((
                      (i.investment_date_key >= (dt.date_key - 90)) AND
                      (i.investment_date_key <= dt.date_key)))) JOIN dim_users_static us ON ((i.user_key = us.user_key)))
                         JOIN dim_pitches_static ps ON ((i.pitch_key = ps.pitch_key)))
                  WHERE ((((us.portal)::text = 'crowdcube'::text) AND ((ps.portal_name)::text = 'crowdcube'::text)) AND
                         (dt.the_date <= ('now'::text)::date))
                  GROUP BY dt.the_date) num90 ON ((dt.the_date = num90.the_date)))
WHERE ((dt.the_date > (('now'::text)::date - 366)) AND (dt.the_date <= ('now'::text)::date))
ORDER BY dt.the_date;

alter table v_metric_active_repeat_investors
  owner to ccdatawh;

