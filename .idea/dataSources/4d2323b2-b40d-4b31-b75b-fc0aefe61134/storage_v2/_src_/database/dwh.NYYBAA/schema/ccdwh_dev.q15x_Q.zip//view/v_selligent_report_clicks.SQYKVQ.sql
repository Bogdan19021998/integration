create view v_selligent_report_clicks as
SELECT s.session_start_date_key   AS date_key,
       c.campaign_source,
       c.campaign_name,
       c.campaign_term,
       expuser.extrapolated_user_id,
       CASE
         WHEN (mod(expuser.extrapolated_user_id, 2) = 0) THEN 'Group B'::text
         WHEN (mod(expuser.extrapolated_user_id, 2) = 1) THEN 'Group A'::text
         ELSE 'Unknown'::text END AS user_group,
       ev.event_name,
       e.session_key,
       e.request_date_date_key,
       e.request_timestamp,
       e.event_key,
       e.page_key,
       e.referer_key,
       e.campaign_key,
       e.pitch_key,
       e.engagement_key,
       e.form_key,
       e.formfield_key,
       e.user_journey_key,
       e.document_key,
       e.mobile_screen_key,
       e.mobile_app_version_key,
       e.mobile_carrier_key,
       e.mobile_device_setting_key,
       e.mobile_timeszone_key
FROM ((((ccdwh_dev.fact_engagement e LEFT JOIN ccdwh_dev.dim_sessions s ON (((e.session_key)::text = (s.session_key)::text))) LEFT JOIN ccdwh_dev.dim_campaigns c ON ((e.campaign_key = c.campaign_key))) LEFT JOIN (SELECT dim_anon_users.anon_id,
                                                                                                                                                                                                                            "max"(dim_anon_users.user_key) AS extrapolated_user_id
                                                                                                                                                                                                                     FROM ccdwh_dev.dim_anon_users
                                                                                                                                                                                                                     GROUP BY dim_anon_users.anon_id) expuser ON (((s.anonymousid)::text = (expuser.anon_id)::text)))
       JOIN ccdwh_dev.dim_events ev ON ((e.event_key = ev.event_key)))
WHERE (((c.campaign_source)::text = 'selligent'::text) AND ((c.campaign_name)::text <> ''::text))
ORDER BY e.request_timestamp DESC;

alter table v_selligent_report_clicks
  owner to ccdatawh;

