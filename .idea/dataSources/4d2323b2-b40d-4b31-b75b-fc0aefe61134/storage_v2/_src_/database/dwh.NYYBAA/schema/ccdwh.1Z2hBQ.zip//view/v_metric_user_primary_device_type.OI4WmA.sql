create view v_metric_user_primary_device_type as
SELECT us.user_key, CASE WHEN (ds3.device_type IS NULL) THEN 'unknown'::text ELSE ds3.device_type END AS device_type
FROM (dim_users_static us
       LEFT JOIN (SELECT ds2.user_key, ds2.device_type
                  FROM (SELECT ds.user_key,
                               ds.device_type,
                               ds.cnt,
                               pg_catalog.row_number() OVER ( PARTITION BY ds.user_key ORDER BY ds.cnt) AS row_number
                        FROM (SELECT au.user_key, d.device_type, count(*) AS cnt
                              FROM ((dim_sessions s JOIN v_user_agent_device_type d ON ((s.user_agent_key = d.user_agent_key)))
                                     JOIN dim_anon_users_new au ON (((au.anon_id)::text = (s.anonymousid)::text)))
                              GROUP BY au.user_key, d.device_type) ds) ds2
                  WHERE (ds2.row_number = 1)) ds3 ON ((us.user_key = ds3.user_key)));

alter table v_metric_user_primary_device_type
  owner to ccdatawh;

