create view v_invnum_rolling_30_day_average as
SELECT count_of_c.investment_date_key AS the_date,
       count_of_c.count_of_investments_total,
       count_of_c.amount_in_gbp_total,
       calc_ave.rolling_avg_30_day_investments,
       calc_ave.rolling_avg_30_day_investments_value
FROM (((SELECT i.investment_date_key,
               count(*)             AS count_of_investments_total,
               sum(i.amount_in_gbp) AS amount_in_gbp_total
        FROM (ccdwh_dev.fact_pitch_investments i
               JOIN ccdwh_dev.dim_pitches_static p ON ((p.pitch_key = i.pitch_key)))
        GROUP BY i.investment_date_key
        ORDER BY i.investment_date_key) count_of_c JOIN (SELECT tbl1.investment_date_key,
                                                                avg(tbl2.count_of_investments_total) AS rolling_avg_30_day_investments,
                                                                avg(tbl2.amount_in_gbp_total)        AS rolling_avg_30_day_investments_value
                                                         FROM ((SELECT i.investment_date_key,
                                                                       count(*)             AS count_of_investments_total,
                                                                       sum(i.amount_in_gbp) AS amount_in_gbp_total
                                                                FROM (ccdwh_dev.fact_pitch_investments i
                                                                       JOIN ccdwh_dev.dim_pitches_static p ON ((p.pitch_key = i.pitch_key)))
                                                                GROUP BY i.investment_date_key
                                                                ORDER BY i.investment_date_key) tbl1
                                                                JOIN (SELECT i.investment_date_key,
                                                                             count(*)             AS count_of_investments_total,
                                                                             sum(i.amount_in_gbp) AS amount_in_gbp_total
                                                                      FROM ((ccdwh_dev.fact_pitch_investments i JOIN ccdwh_dev.dim_pitches_static p ON ((p.pitch_key = i.pitch_key)))
                                                                             JOIN (SELECT dim_dates.date_key
                                                                                   FROM ccdwh_dev.dim_dates
                                                                                   WHERE (dim_dates.the_date = ('now'::character varying)::date)) cdate_1
                                                                                  ON ((i.investment_date_key < cdate_1.date_key)))
                                                                      GROUP BY i.investment_date_key
                                                                      ORDER BY i.investment_date_key) tbl2
                                                                     ON ((tbl2.investment_date_key > (tbl1.investment_date_key - 31))))
                                                         GROUP BY tbl1.investment_date_key
                                                         ORDER BY tbl1.investment_date_key) calc_ave ON ((calc_ave.investment_date_key = count_of_c.investment_date_key)))
       JOIN (SELECT dim_dates.date_key
             FROM ccdwh_dev.dim_dates
             WHERE (dim_dates.the_date = ('now'::character varying)::date)) cdate2
            ON (((count_of_c.investment_date_key > (cdate2.date_key - 31)) AND
                 (count_of_c.investment_date_key <= cdate2.date_key))))
ORDER BY count_of_c.investment_date_key;

alter table v_invnum_rolling_30_day_average
  owner to ccdatawh;

