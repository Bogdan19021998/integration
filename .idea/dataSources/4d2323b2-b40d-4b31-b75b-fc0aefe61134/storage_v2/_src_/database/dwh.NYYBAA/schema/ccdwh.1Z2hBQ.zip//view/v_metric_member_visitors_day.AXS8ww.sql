create view v_metric_member_visitors_day as
SELECT dt.the_date, count(DISTINCT au.user_key) AS num_unique_members
FROM ((dim_sessions s JOIN dim_dates dt ON ((s.session_start_date_key = dt.date_key)))
       JOIN dim_anon_users_new au ON (((s.anonymousid)::text = (au.anon_id)::text)))
WHERE ((dt.the_date < (('now'::text)::date + 1)) AND (au.user_key <> 0))
GROUP BY dt.the_date
ORDER BY dt.the_date DESC;

alter table v_metric_member_visitors_day
  owner to ccdatawh;

