create function f_rfim_score(recency_investment integer, frequency_investments bigint, intensity_monetary numeric) returns character
  stable
  language plpythonu
as
$$
        #-- Rule 1: if there is no visit, return a -
       if(recency_investment is None)                                                                                   : return '-' 
       
       #-- Rule 2: If the visit is less than 400 days ago (i.e. over a year, consider them F
       if recency_investment < -400                                                                                     : return 'F'
       
       #-- Rule 3: If the visit last visit was over half a year ago.. Score is either F for low intensity of E for higher intensity
       if recency_investment >= -400 and recency_investment < -180 and intensity_monetary < 1000                        : return 'F'
       if recency_investment >= -400 and recency_investment < -180 and intensity_monetary > 1000                        : return 'E'
       
       #-- Rule 4: If the visit last visit was over 3 months a year ago.. Score is either E for low intensity of D for higher intensity
       if recency_investment >= -180 and recency_investment < -60 and intensity_monetary < 1000                         : return 'E'
       if recency_investment >= -180 and recency_investment < -60 and intensity_monetary > 1000                         : return 'D'
       if recency_investment >= -180 and recency_investment < -60 and intensity_monetary > 10000                        : return 'C'
       
       #-- Rule 5: If the visit last visit was in the past 2 months a year ago.. Score is either E for low intensity of D for higher intensity
       if recency_investment >= -60 and recency_investment < -30 and intensity_monetary < 1000                          : return 'C'
       if recency_investment >= -60 and recency_investment < -30 and intensity_monetary >= 1000 and intensity_monetary < 10000  : return 'B'
       if recency_investment >= -60 and recency_investment < -30 and intensity_monetary >= 10000                        : return 'A'
       
       #-- Rule 6: If the visit last visit was in the past month a year ago.. Score is either E for low intensity of D for higher intensity
       if recency_investment >= -30 and intensity_monetary < 1000                                                       : return 'B'
       if recency_investment >= -30 and intensity_monetary >= 1000                                                      : return 'A'
       
       #-- Un-caught condition. This should not occur
       return 'U'
       
       
       return 'U'
$$;

