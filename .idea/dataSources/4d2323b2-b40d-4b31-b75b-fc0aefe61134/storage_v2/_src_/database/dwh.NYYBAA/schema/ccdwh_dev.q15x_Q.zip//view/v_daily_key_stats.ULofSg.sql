create view v_daily_key_stats as
SELECT derived_table1.the_date,
       derived_table1.count_of_sessions,
       derived_table1.rolling_avg_30_day_sessions,
       derived_table1.count_of_unique_users,
       derived_table1.rolling_avg_30_day_users,
       derived_table1.count_of_signups,
       derived_table1.rolling_avg_30_day_signups,
       CASE
         WHEN (derived_table1.count_of_investments_bonds IS NULL) THEN (0)::bigint
         ELSE derived_table1.count_of_investments_bonds END       AS count_of_investments_bonds,
       CASE
         WHEN (derived_table1.amount_in_gbp_bonds IS NULL) THEN ((0)::numeric)::numeric(18, 0)
         ELSE derived_table1.amount_in_gbp_bonds END              AS amount_in_gbp_bonds,
       CASE
         WHEN (derived_table1.count_of_investments_equity IS NULL) THEN (0)::bigint
         ELSE derived_table1.count_of_investments_equity END      AS count_of_investments_equity,
       CASE
         WHEN (derived_table1.amount_in_gbp_equity IS NULL) THEN ((0)::numeric)::numeric(18, 0)
         ELSE derived_table1.amount_in_gbp_equity END             AS amount_in_gbp_equity,
       CASE
         WHEN (derived_table1.sign_up_conversion >= (30)::double precision) THEN (0)::double precision
         ELSE derived_table1.sign_up_conversion END               AS sign_up_conversion,
       CASE
         WHEN (derived_table1.investment_conversion >= (30)::double precision) THEN (0)::double precision
         ELSE CASE
                WHEN (derived_table1.investment_conversion IS NULL) THEN (0)::double precision
                ELSE derived_table1.investment_conversion END END AS investment_conversion,
       derived_table1.count_of_investments_total,
       derived_table1.amount_in_gbp_total,
       derived_table1.rolling_avg_30_day_investments,
       derived_table1.rolling_avg_30_day_investments_value
FROM (SELECT num_sessions.the_date,
             num_sessions.count_of_sessions,
             num_sessions.rolling_avg_30_day_sessions,
             num_unique_users.count_of_unique_users,
             num_unique_users.rolling_avg_30_day_users,
             num_sign_ups.count_of_signups,
             num_sign_ups.rolling_avg_30_day_signups,
             num_investments_bonds.count_of_investments_bonds,
             num_investments_bonds.amount_in_gbp_bonds,
             num_investments_equity.count_of_investments_equity,
             num_investments_equity.amount_in_gbp_equity,
             invnum.count_of_investments_total,
             invnum.amount_in_gbp_total,
             invnum.rolling_avg_30_day_investments,
             invnum.rolling_avg_30_day_investments_value,
             (((num_sign_ups.count_of_signups)::double precision /
               (num_unique_users.count_of_unique_users)::double precision) *
              (100)::double precision)                                                                AS sign_up_conversion,
             ((((num_investments_bonds.count_of_investments_bonds +
                 num_investments_equity.count_of_investments_equity))::double precision /
               (num_unique_users.count_of_unique_users)::double precision) *
              (100)::double precision)                                                                AS investment_conversion
      FROM ((((((SELECT v_session_rolling_30_day_average.the_date,
                        v_session_rolling_30_day_average.count_of_sessions,
                        v_session_rolling_30_day_average.rolling_avg_30_day_sessions
                 FROM ccdwh_dev.v_session_rolling_30_day_average) num_sessions LEFT JOIN (SELECT v_user_rolling_30_day_average.the_date,
                                                                                                 v_user_rolling_30_day_average.count_of_unique_users,
                                                                                                 v_user_rolling_30_day_average.rolling_avg_30_day_users
                                                                                          FROM ccdwh_dev.v_user_rolling_30_day_average) num_unique_users ON ((num_sessions.the_date = num_unique_users.the_date))) LEFT JOIN (SELECT v_signup_rolling_30_day_average.the_date,
                                                                                                                                                                                                                                     v_signup_rolling_30_day_average.count_of_signups,
                                                                                                                                                                                                                                     v_signup_rolling_30_day_average.rolling_avg_30_day_signups
                                                                                                                                                                                                                              FROM ccdwh_dev.v_signup_rolling_30_day_average) num_sign_ups ON ((num_sessions.the_date = num_sign_ups.the_date))) LEFT JOIN (SELECT i.investment_date_key,
                                                                                                                                                                                                                                                                                                                                                                   count(*)             AS count_of_investments_bonds,
                                                                                                                                                                                                                                                                                                                                                                   sum(i.amount_in_gbp) AS amount_in_gbp_bonds
                                                                                                                                                                                                                                                                                                                                                            FROM (ccdwh_dev.fact_pitch_investments i
                                                                                                                                                                                                                                                                                                                                                                   JOIN ccdwh_dev.dim_pitches_static p ON ((p.pitch_key = i.pitch_key)))
                                                                                                                                                                                                                                                                                                                                                            WHERE (((p.product_type)::text = ('Bonds'::character varying)::text) AND
                                                                                                                                                                                                                                                                                                                                                                   ((p.portal_name)::text = ('crowdcube'::character varying)::text))
                                                                                                                                                                                                                                                                                                                                                            GROUP BY i.investment_date_key
                                                                                                                                                                                                                                                                                                                                                            ORDER BY i.investment_date_key) num_investments_bonds ON ((num_investments_bonds.investment_date_key = num_sessions.the_date))) LEFT JOIN (SELECT i.investment_date_key,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              count(*)             AS count_of_investments_equity,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              sum(i.amount_in_gbp) AS amount_in_gbp_equity
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       FROM (ccdwh_dev.fact_pitch_investments i
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              JOIN ccdwh_dev.dim_pitches_static p ON ((p.pitch_key = i.pitch_key)))
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       WHERE (((p.product_type)::text = ('Equity'::character varying)::text) AND
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ((p.portal_name)::text = ('crowdcube'::character varying)::text))
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       GROUP BY i.investment_date_key
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ORDER BY i.investment_date_key) num_investments_equity ON ((num_investments_equity.investment_date_key = num_sessions.the_date)))
             LEFT JOIN (SELECT v_invnum_rolling_30_day_average.the_date,
                               v_invnum_rolling_30_day_average.count_of_investments_total,
                               v_invnum_rolling_30_day_average.amount_in_gbp_total,
                               v_invnum_rolling_30_day_average.rolling_avg_30_day_investments,
                               v_invnum_rolling_30_day_average.rolling_avg_30_day_investments_value
                        FROM ccdwh_dev.v_invnum_rolling_30_day_average) invnum
                       ON ((invnum.the_date = num_sessions.the_date)))) derived_table1;

alter table v_daily_key_stats
  owner to ccdatawh;

