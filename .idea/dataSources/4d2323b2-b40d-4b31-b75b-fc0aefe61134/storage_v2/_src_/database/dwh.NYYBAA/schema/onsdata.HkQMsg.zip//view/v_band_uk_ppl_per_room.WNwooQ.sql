create view v_band_uk_ppl_per_room as
SELECT ds.pcd,
       ds.perc_up_to_half,
       onsdata.f_percent_band(ds.perc_up_to_half, 4)              AS up_to_half_band,
       ds.perc_over_half,
       onsdata.f_percent_band(ds.perc_over_half, 4)               AS over_half_band,
       ds.perc_over_one_up_to_one_half,
       onsdata.f_percent_band(ds.perc_over_one_up_to_one_half, 4) AS over_one_up_to_one_half_band,
       ds.perc_over_one_half,
       onsdata.f_percent_band(ds.perc_over_one_half, 4)           AS over_one_half_band
FROM (SELECT (upper("replace"(btrim((onspd.pcd)::text), ' '::text, ''::text)))::character varying(8) AS pcd,
             ((uk_ppl_per_room.ppl_per_room_up_to_half)::double precision /
              (uk_ppl_per_room.ppl_per_room_all)::double precision)                                  AS perc_up_to_half,
             ((uk_ppl_per_room.ppl_per_room_over_half)::double precision /
              (uk_ppl_per_room.ppl_per_room_all)::double precision)                                  AS perc_over_half,
             ((uk_ppl_per_room.ppl_per_room_over_one_up_to_one_half)::double precision /
              (uk_ppl_per_room.ppl_per_room_all)::double precision)                                  AS perc_over_one_up_to_one_half,
             ((uk_ppl_per_room.ppl_per_room_over_one_half)::double precision /
              (uk_ppl_per_room.ppl_per_room_all)::double precision)                                  AS perc_over_one_half
      FROM (onsdata.onspd
             LEFT JOIN onsdata.uk_ppl_per_room ON (((onspd.oa11)::text = (uk_ppl_per_room.geography_code)::text)))
      WHERE (uk_ppl_per_room.ppl_per_room_all > 0)) ds;

alter table v_band_uk_ppl_per_room
  owner to ccdatawh;

