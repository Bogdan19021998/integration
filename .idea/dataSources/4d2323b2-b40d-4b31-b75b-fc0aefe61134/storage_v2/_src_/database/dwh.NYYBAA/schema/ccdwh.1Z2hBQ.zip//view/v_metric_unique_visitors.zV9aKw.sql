create view v_metric_unique_visitors as
SELECT dt.the_date, count(DISTINCT s.anonymousid) AS num_unique_visitors
FROM (dim_sessions s
       JOIN dim_dates dt ON ((s.session_start_date_key = dt.date_key)))
WHERE (dt.the_date < (('now'::text)::date + 1))
GROUP BY dt.the_date
ORDER BY dt.the_date DESC;

alter table v_metric_unique_visitors
  owner to ccdatawh;

