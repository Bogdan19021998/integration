create view v_mature_user_accounts_for_cluster_training_set as
SELECT v_users.user_key,
       v_users.user_name,
       v_users.user_email,
       ((SELECT dim_dates.date_key FROM dim_dates WHERE (dim_dates.the_date = ('now'::text)::date)) -
        v_users.registered_date_key) AS num_days_registered,
       v_users.sanitised_postcode
FROM ccseg.v_users
WHERE ((v_users.registered_date_key <=
        (SELECT (dim_dates.date_key - (30 * 9)) FROM dim_dates WHERE (dim_dates.the_date = ('now'::text)::date))) AND
       (v_users.user_key IN (SELECT DISTINCT pi.user_key
                             FROM fact_pitch_investments pi
                             WHERE (pi.investment_date_key >= (SELECT dim_dates.date_key
                                                               FROM dim_dates
                                                               WHERE (dim_dates.the_date = '2014-01-01'::date))))));

alter table v_mature_user_accounts_for_cluster_training_set
  owner to ccdatawh;

