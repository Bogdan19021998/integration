create view v_key_metrics_last_30_days as
SELECT avg(ab.count_of_sessions)                                                                              AS avg_sessions,
       "max"(ab.count_of_sessions)                                                                            AS peak_sessions,
       sum(ab.count_of_sessions)                                                                              AS total_sessions,
       avg(ab.count_of_unique_users)                                                                          AS avg_users,
       "max"(ab.count_of_unique_users)                                                                        AS peak_users,
       sum(ab.count_of_unique_users)                                                                          AS total_users,
       avg(ab.count_of_signups)                                                                               AS avg_signups,
       "max"(ab.count_of_signups)                                                                             AS peak_signups,
       sum(ab.count_of_signups)                                                                               AS total_signups,
       avg(ab.count_of_investments_bonds)                                                                     AS avg_bond_invs,
       "max"(ab.count_of_investments_bonds)                                                                   AS peak_bond_invs,
       sum(ab.count_of_investments_bonds)                                                                     AS total_bond_invs,
       avg(ab.count_of_investments_equity)                                                                    AS avg_equity_invs,
       "max"(ab.count_of_investments_equity)                                                                  AS peak_equity_invs,
       sum(ab.count_of_investments_equity)                                                                    AS total_equity_invs,
       avg(ab.count_of_investments_total)                                                                     AS avg_total_invs,
       "max"(ab.count_of_investments_total)                                                                   AS peak_total_invs,
       sum(ab.count_of_investments_total)                                                                     AS total_total_invs,
       avg(ab.amount_in_gbp_bonds)                                                                            AS avg_bond_invs_amount,
       "max"(ab.amount_in_gbp_bonds)                                                                          AS peak_bond_invs_amount,
       sum(ab.amount_in_gbp_bonds)                                                                            AS total_bond_invs_amount,
       avg(ab.amount_in_gbp_equity)                                                                           AS avg_equity_invs_amount,
       "max"(ab.amount_in_gbp_equity)                                                                         AS peak_equity_invs_amount,
       sum(ab.amount_in_gbp_equity)                                                                           AS total_equity_invs_amount,
       avg(ab.amount_in_gbp_total)                                                                            AS avg_total_invs_amount,
       "max"(ab.amount_in_gbp_total)                                                                          AS peak_total_invs_amount,
       sum(ab.amount_in_gbp_total)                                                                            AS total_total_invs_amount,
       avg(ab.avg_amount_in_bonds)                                                                            AS avg_avg_bonds_amount,
       avg(ab.avg_amount_in_equity)                                                                           AS avg_avg_equity_amount,
       avg(ab.avg_amount_total)                                                                               AS avg_avg_total_amount,
       "max"(ab.avg_amount_in_bonds)                                                                          AS peak_avg_bonds_amount,
       "max"(ab.avg_amount_in_equity)                                                                         AS peak_avg_equity_amount,
       "max"(ab.avg_amount_total)                                                                             AS peak_avg_total_amount,
       CASE
         WHEN (sum(ab.count_of_investments_bonds) > 0) THEN (sum(ab.amount_in_gbp_equity) /
                                                             (sum(ab.count_of_investments_equity))::numeric)
         ELSE (0)::numeric END                                                                                AS total_avg_bonds_amount,
       CASE
         WHEN (sum(ab.count_of_investments_equity) > 0) THEN (sum(ab.amount_in_gbp_equity) /
                                                              (sum(ab.count_of_investments_equity))::numeric)
         ELSE (0)::numeric END                                                                                AS total_avg_equity_amount,
       CASE
         WHEN (sum(ab.count_of_investments_total) > 0) THEN (sum(ab.amount_in_gbp_total) /
                                                             (sum(ab.count_of_investments_total))::numeric)
         ELSE (0)::numeric END                                                                                AS total_avg_total_amount,
       avg(ab.count_page_views)                                                                               AS avg_page_views,
       "max"(ab.count_page_views)                                                                             AS peak_page_views,
       sum(ab.count_page_views)                                                                               AS total_page_views,
       avg(ab.pages_per_session)                                                                              AS avg_pages_per_session,
       "max"(ab.pages_per_session)                                                                            AS max_pages_per_session,
       (((1.00 * (sum(ab.count_page_views))::numeric) /
         (sum(ab.count_of_sessions))::numeric))::numeric(5, 2)                                                AS total_pages_per_session,
       avg(ab.investors)                                                                                      AS avg_investors,
       "max"(ab.investors)                                                                                    AS peak_investors,
       sum(ab.investors)                                                                                      AS total_investors,
       avg(ab.count_of_anons_first_sessions)                                                                  AS avg_new_users,
       "max"(ab.count_of_anons_first_sessions)                                                                AS peak_new_users,
       sum(ab.count_of_anons_first_sessions)                                                                  AS total_new_users,
       avg(ab.percentage_new_sessions)                                                                        AS avg_perc_new_sessions,
       "max"(ab.percentage_new_sessions)                                                                      AS peak_perc_new_sessions,
       (((100.00 * (sum(ab.count_of_anons_first_sessions))::numeric) /
         (sum(ab.count_of_sessions))::numeric))::numeric(5, 1)                                                AS total_perc_new_sessions
FROM (SELECT x.date_key,
             x.the_date,
             x.count_of_sessions,
             x.count_of_unique_users,
             x.count_of_signups,
             x.count_of_investments_bonds,
             x.count_of_investments_equity,
             x.count_of_investments_total,
             x.amount_in_gbp_bonds,
             x.amount_in_gbp_equity,
             x.amount_in_gbp_total,
             x.avg_amount_in_bonds,
             x.avg_amount_in_equity,
             x.avg_amount_total,
             y.count_page_views,
             (((1.00 * (y.count_page_views)::numeric) /
               (x.count_of_sessions)::numeric))::numeric(5, 2) AS pages_per_session,
             z.investors,
             aa.count_of_anons_first_sessions,
             (((100.00 * (aa.count_of_anons_first_sessions)::numeric) /
               (x.count_of_sessions)::numeric))::numeric(5, 1) AS percentage_new_sessions
      FROM ((((SELECT v_headline_stats.date_key,
                      v_headline_stats.the_date,
                      v_headline_stats.count_of_sessions,
                      v_headline_stats.count_of_unique_users,
                      v_headline_stats.members                            AS count_of_signups,
                      v_headline_stats.attempted_bond_investments         AS count_of_investments_bonds,
                      v_headline_stats.attempted_equity_investments       AS count_of_investments_equity,
                      v_headline_stats.attempted_total_investments        AS count_of_investments_total,
                      v_headline_stats.attempted_bond_investment_amount   AS amount_in_gbp_bonds,
                      v_headline_stats.attempted_equity_investment_amount AS amount_in_gbp_equity,
                      v_headline_stats.attempted_total_investment_amount  AS amount_in_gbp_total,
                      CASE
                        WHEN (v_headline_stats.attempted_bond_investments > 0) THEN (
                            v_headline_stats.attempted_bond_investment_amount /
                            (v_headline_stats.attempted_bond_investments)::numeric)
                        ELSE (0)::numeric END                             AS avg_amount_in_bonds,
                      CASE
                        WHEN (v_headline_stats.attempted_equity_investments > 0) THEN (
                            v_headline_stats.attempted_equity_investment_amount /
                            (v_headline_stats.attempted_equity_investments)::numeric)
                        ELSE (0)::numeric END                             AS avg_amount_in_equity,
                      CASE
                        WHEN (v_headline_stats.attempted_total_investments > 0) THEN (
                            v_headline_stats.attempted_total_investment_amount /
                            (v_headline_stats.attempted_total_investments)::numeric)
                        ELSE (0)::numeric END                             AS avg_amount_total
               FROM v_headline_stats
               WHERE ((v_headline_stats.date_key >= (SELECT (dim_dates.date_key - 30)
                                                     FROM dim_dates
                                                     WHERE (dim_dates.the_date = ('now'::text)::date))) AND
                      (v_headline_stats.date_key <
                       (SELECT dim_dates.date_key FROM dim_dates WHERE (dim_dates.the_date = ('now'::text)::date))))
               ORDER BY v_headline_stats.the_date) x LEFT JOIN (SELECT fact_engagement.request_date_date_key,
                                                                       count(*) AS count_page_views
                                                                FROM fact_engagement
                                                                WHERE (((fact_engagement.event_key = 122) AND
                                                                        (fact_engagement.request_date_date_key >=
                                                                         (SELECT (dim_dates.date_key - 30)
                                                                          FROM dim_dates
                                                                          WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
                                                                       (fact_engagement.request_date_date_key <
                                                                        (SELECT dim_dates.date_key
                                                                         FROM dim_dates
                                                                         WHERE (dim_dates.the_date = ('now'::text)::date))))
                                                                GROUP BY fact_engagement.request_date_date_key
                                                                ORDER BY fact_engagement.request_date_date_key DESC) y ON ((x.date_key = y.request_date_date_key))) LEFT JOIN (SELECT pi.investment_date_key,
                                                                                                                                                                                      count(DISTINCT pi.user_key) AS investors
                                                                                                                                                                               FROM (fact_pitch_investments pi
                                                                                                                                                                                      JOIN dim_pitches_static ps ON ((ps.pitch_key = pi.pitch_key)))
                                                                                                                                                                               WHERE ((((pi.investment_date_key >=
                                                                                                                                                                                         (SELECT (dim_dates.date_key - 30)
                                                                                                                                                                                          FROM dim_dates
                                                                                                                                                                                          WHERE (dim_dates.the_date = ('now'::text)::date))) AND
                                                                                                                                                                                        (pi.investment_date_key <
                                                                                                                                                                                         (SELECT dim_dates.date_key
                                                                                                                                                                                          FROM dim_dates
                                                                                                                                                                                          WHERE (dim_dates.the_date = ('now'::text)::date)))) AND
                                                                                                                                                                                       ((pi.currency_iso_code)::text = 'GBP'::text)) AND
                                                                                                                                                                                      ((ps.portal_name)::text = 'crowdcube'::text))
                                                                                                                                                                               GROUP BY pi.investment_date_key) z ON ((x.date_key = z.investment_date_key)))
             LEFT JOIN (SELECT derived_table1.first_session_date_key, count(*) AS count_of_anons_first_sessions
                        FROM (SELECT s.anonymousid, min(s.session_start_date_key) AS first_session_date_key
                              FROM dim_sessions s
                              GROUP BY s.anonymousid) derived_table1
                        WHERE ((derived_table1.first_session_date_key >= (SELECT (dim_dates.date_key - 30)
                                                                          FROM dim_dates
                                                                          WHERE (dim_dates.the_date = ('now'::text)::date))) AND
                               (derived_table1.first_session_date_key < (SELECT dim_dates.date_key
                                                                         FROM dim_dates
                                                                         WHERE (dim_dates.the_date = ('now'::text)::date))))
                        GROUP BY derived_table1.first_session_date_key
                        ORDER BY derived_table1.first_session_date_key DESC) aa
                       ON ((x.date_key = aa.first_session_date_key)))) ab;

alter table v_key_metrics_last_30_days
  owner to ccdatawh;

