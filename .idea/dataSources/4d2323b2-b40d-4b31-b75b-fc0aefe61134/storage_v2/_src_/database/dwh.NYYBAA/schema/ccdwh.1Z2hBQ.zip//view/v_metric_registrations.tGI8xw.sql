create view v_metric_registrations as
SELECT dt.the_date, count(*) AS number_registrations
FROM (dim_users_static us
       JOIN dim_dates dt ON ((us.registered_date_key = dt.date_key)))
WHERE ((us.portal)::text = 'crowdcube'::text)
GROUP BY dt.the_date
ORDER BY dt.the_date DESC;

alter table v_metric_registrations
  owner to ccdatawh;

