create view v_metric_pitches_launched_by_date as
SELECT dt.the_date,
       CASE WHEN (ds.num_launched IS NULL) THEN (0)::bigint ELSE ds.num_launched END                        AS num_launched,
       CASE
         WHEN (ds.pitches_launched IS NULL) THEN 'None'::character varying
         ELSE ds.pitches_launched END                                                                       AS pitches_launched,
       CASE
         WHEN (ds.number_investments IS NULL) THEN (0)::bigint
         ELSE ds.number_investments END                                                                     AS number_investments,
       CASE
         WHEN (ds.final_investment_amount IS NULL) THEN (0)::numeric
         ELSE ds.final_investment_amount END                                                                AS investment_reached_amount_gbp
FROM (v_master_dates dt
       LEFT JOIN (SELECT pc.created_date_key                         AS launched_date,
                         count(*)                                    AS num_launched,
                         sum(pc.investor_count)                      AS number_investments,
                         sum(pc.reached_amount)                      AS final_investment_amount,
                         pg_catalog.listagg((pc.pitch_name)::text, ', '::text)
                         WITHIN GROUP ( ORDER BY pc.pitch_name DESC) AS pitches_launched
                  FROM (v_master_pitches_latest pc
                         JOIN v_master_dates dt_created ON ((pc.created_date_key = dt_created.date_key)))
                  WHERE (NOT (pc.pitch_key IN (SELECT fact_test_pitch_exclude.pitch_key FROM fact_test_pitch_exclude)))
                  GROUP BY pc.created_date_key) ds ON ((dt.date_key = ds.launched_date)))
ORDER BY dt.the_date DESC;

alter table v_metric_pitches_launched_by_date
  owner to ccdatawh;

