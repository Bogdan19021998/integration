create view v_distil_products as
SELECT p.pitch_key                                           AS product_id,
       p.pitch_name                                          AS product_name,
       p.desciption                                          AS product_precis,
       p.pitch_logourl                                       AS product_thumbnail_url,
       p.pitch_coverurl                                      AS product_full_image_url,
       p.pitch_url                                           AS product_url,
       CASE
         WHEN (((p.pitch_status)::text = ('Active'::character varying)::text) OR
               ((p.pitch_status)::text = ('Active Hidden'::character varying)::text)) THEN true
         ELSE false END                                      AS available,
       p.reached_amount                                      AS list_price_excluding_tax,
       0.0                                                   AS list_price_including_tax,
       NULL::"unknown"                                       AS price_breaks_description,
       p.product_type,
       p.company_name,
       COALESCE(s.sector_name, 'unknown'::character varying) AS product_category
FROM ((v_master_pitches_latest p LEFT JOIN fact_pitch_sectors ps ON ((p.pitch_key = ps.pitch_key)))
       LEFT JOIN dim_sectors s ON ((s.sector_key = ps.sector_key)));

alter table v_distil_products
  owner to neil_stoneman;

