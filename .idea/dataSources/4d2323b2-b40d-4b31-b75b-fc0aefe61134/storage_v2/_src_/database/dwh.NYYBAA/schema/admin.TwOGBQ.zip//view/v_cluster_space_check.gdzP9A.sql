create view v_cluster_space_check as
SELECT (derived_table1.sc / 1024)                       AS capacity_gbytes,
       (derived_table1.su / 1024)                       AS used_gbytes,
       ((derived_table1.sc - derived_table1.su) / 1024) AS free_gbytes
FROM (SELECT sum(stv_partitions.capacity) AS sc, sum(stv_partitions.used) AS su
      FROM stv_partitions
      WHERE (stv_partitions.part_begin = 0)) derived_table1;

alter table v_cluster_space_check
  owner to ccdatawh;

