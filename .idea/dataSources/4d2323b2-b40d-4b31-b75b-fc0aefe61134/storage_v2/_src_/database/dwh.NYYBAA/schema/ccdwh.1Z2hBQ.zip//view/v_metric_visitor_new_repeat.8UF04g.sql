create view v_metric_visitor_new_repeat as
SELECT x.the_date, x.num_new, (x.num_unique_visitors - x.num_new) AS num_repeat, x.num_unique_visitors
FROM (SELECT dt.the_date, count(DISTINCT ds.anonymousid) AS num_new, vis.num_unique_visitors
      FROM ((dim_dates dt LEFT JOIN (SELECT DISTINCT s.anonymousid, min(s.session_start_date_key) AS first_session
                                     FROM dim_sessions s
                                     GROUP BY s.anonymousid) ds ON ((dt.date_key = ds.first_session)))
             LEFT JOIN (SELECT v_metric_unique_visitors.the_date, v_metric_unique_visitors.num_unique_visitors
                        FROM v_metric_unique_visitors) vis ON ((dt.the_date = vis.the_date)))
      WHERE (dt.the_date < ('now'::text)::date)
      GROUP BY dt.the_date, vis.num_unique_visitors
      ORDER BY dt.the_date DESC) x
ORDER BY x.the_date DESC;

alter table v_metric_visitor_new_repeat
  owner to ccdatawh;

