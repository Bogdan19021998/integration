create view v_pitch_salesforce_data_exp as
SELECT x.pitch_key,
       x.name,
       x.ea,
       x.bd,
       x.opportunity_created_date_key,
       x.opportunity_created_timestamp,
       y.lead_created_date_key,
       y.lead_created_timestamp
FROM ((SELECT op.id,
              op.pitch_id_c                                                  AS pitch_key,
              op.name,
              (((u.first_name)::text || ' '::text) || (u.last_name)::text)   AS ea,
              (((u2.first_name)::text || ' '::text) || (u2.last_name)::text) AS bd,
              op.created_date                                                AS opportunity_created_timestamp,
              d.date_key                                                     AS opportunity_created_date_key
       FROM sfexperimental.opportunities op,
            sfexperimental.users u,
            sfexperimental.users u2,
            dim_dates d
       WHERE (((((op.owner_id)::text = (u.id)::text) AND ((op.bd_manager_c)::text = (u2.id)::text)) AND
               (op.pitch_id_c IS NOT NULL)) AND (d.the_date = trunc(op.created_date)))) x
       LEFT JOIN (SELECT l.converted_opportunity_id,
                         l.created_date AS lead_created_timestamp,
                         d.date_key     AS lead_created_date_key
                  FROM sfexperimental.leads l,
                       dim_dates d
                  WHERE (d.the_date = trunc(l.created_date))) y
                 ON (((y.converted_opportunity_id)::text = (x.id)::text)));

alter table v_pitch_salesforce_data_exp
  owner to ccdatawh;

