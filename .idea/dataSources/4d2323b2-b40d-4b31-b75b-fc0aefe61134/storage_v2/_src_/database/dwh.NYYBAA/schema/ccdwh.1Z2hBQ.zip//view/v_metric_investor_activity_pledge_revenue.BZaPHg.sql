create view v_metric_investor_activity_pledge_revenue as
SELECT y.the_date,
       y.num_new,
       y.num_new_investments,
       y.total_amount_new,
       y.num_new_pledge_investors,
       y.num_new_pledge_investments,
       y.amount_new_pledge,
       (y.total_amount_new - y.amount_new_pledge)                                             AS amount_new_stripe,
       y.new_revenue,
       y.num_repeat,
       y.num_repeat_investments,
       y.amount_repeat,
       (y.total_amount_pledge - y.amount_new_pledge)                                          AS amount_repeat_pledge,
       (y.amount_repeat - (y.total_amount_pledge - y.amount_new_pledge))                      AS amount_repeat_stripe,
       y.revenue_repeat,
       y.total_num_investors,
       y.total_num_investments,
       y.total_amount_invested,
       y.total_amount_pledge,
       (y.total_amount_invested - y.total_amount_pledge)                                      AS total_amount_stripe,
       y.total_revenue,
       ((((y.total_amount_invested - y.total_amount_pledge) * 0.78) * 0.049))::numeric(12, 2) AS projected_revenue_minus_pledge
FROM (SELECT x.the_date,
             x.num_new,
             x.num_new_investments,
             x.amount_new                                                                           AS total_amount_new,
             x.num_new_pledge_investors,
             x.num_new_pledge_investments,
             CASE
               WHEN (x.amount_new_pledge IS NULL) THEN (0)::numeric
               ELSE x.amount_new_pledge END                                                         AS amount_new_pledge,
             x.new_revenue,
             (x.num_investors - x.num_new)                                                          AS num_repeat,
             (x.num_investments - x.num_new_investments)                                            AS num_repeat_investments,
             (x.amount_invested - x.amount_new)                                                     AS amount_repeat,
             (x.revenue - x.new_revenue)                                                            AS revenue_repeat,
             x.num_investors                                                                        AS total_num_investors,
             x.num_investments                                                                      AS total_num_investments,
             x.amount_invested                                                                      AS total_amount_invested,
             CASE
               WHEN (x.amount_pledged IS NULL) THEN (0)::numeric
               ELSE x.amount_pledged END                                                            AS total_amount_pledge,
             x.revenue                                                                              AS total_revenue
      FROM (SELECT dt.the_date,
                   count(DISTINCT ds.user_key)                                                                       AS num_new,
                   count(id.pitch_key)                                                                               AS num_new_investments,
                   count(DISTINCT CASE
                                    WHEN ((id.payment_method)::text = 'pledge'::text) THEN id.user_key
                                    ELSE NULL::integer END)                                                          AS num_new_pledge_investors,
                   count(CASE
                           WHEN ((id.payment_method)::text = 'pledge'::text) THEN id.investment_id
                           ELSE NULL::integer END)                                                                   AS num_new_pledge_investments,
                   sum(id.amount)                                                                                    AS amount_new,
                   sum(CASE
                         WHEN ((id.payment_method)::text = 'pledge'::text) THEN id.amount
                         ELSE NULL::numeric END)                                                                     AS amount_new_pledge,
                   sum(id.fee_amount)                                                                                AS new_revenue,
                   inv.num_investors,
                   inv.num_investments,
                   inv.amount_invested,
                   inv.amount_pledged,
                   inv.revenue
            FROM (((dim_dates dt LEFT JOIN (SELECT DISTINCT pi.user_key,
                                                            min(pi.investment_date_key) AS first_investment,
                                                            min(pi.investment_id)       AS first_id
                                            FROM (fact_pitch_investments pi
                                                   JOIN dim_pitches_static ps ON ((pi.pitch_key = ps.pitch_key)))
                                            WHERE (((ps.portal_name)::text = 'crowdcube'::text) AND
                                                   ((((((ps.pitch_key <> 19833) AND (ps.pitch_key <> 20779)) AND
                                                       (ps.pitch_key <> 20866)) AND (ps.pitch_key <> 20809)) AND
                                                     (ps.pitch_key <> 20938)) AND (ps.pitch_key <> 20940)))
                                            GROUP BY pi.user_key) ds ON ((dt.date_key = ds.first_investment))) LEFT JOIN (SELECT dt.the_date,
                                                                                                                                 count(DISTINCT pi.user_key)   AS num_investors,
                                                                                                                                 count(pi.pitch_key)           AS num_investments,
                                                                                                                                 sum(pi.amount)                AS amount_invested,
                                                                                                                                 sum(
                                                                                                                                     CASE
                                                                                                                                       WHEN ((pi.payment_method)::text = 'pledge'::text)
                                                                                                                                         THEN pi.amount
                                                                                                                                       ELSE NULL::numeric END) AS amount_pledged,
                                                                                                                                 sum(pi.fee_amount)            AS revenue
                                                                                                                          FROM ((fact_pitch_investments pi JOIN dim_dates dt ON ((pi.investment_date_key = dt.date_key)))
                                                                                                                                 JOIN v_master_pitches_latest ps ON ((pi.pitch_key = ps.pitch_key)))
                                                                                                                          WHERE ((((((((((ps.pitch_status)::text = 'Active'::text) OR
                                                                                                                                        ((ps.pitch_status)::text = 'Active Hidden'::text)) OR
                                                                                                                                       ((ps.pitch_status)::text = 'Active Hidden Private'::text)) OR
                                                                                                                                      ((ps.pitch_status)::text = 'Funded'::text)) OR
                                                                                                                                     ((ps.pitch_status)::text = 'Cancelled'::text)) OR
                                                                                                                                    ((ps.pitch_status)::text = 'Expired'::text)) AND
                                                                                                                                   (ps.created_date_key > 1)) AND
                                                                                                                                  ((((((ps.pitch_key <> 19833) AND (ps.pitch_key <> 20779)) AND
                                                                                                                                      (ps.pitch_key <> 20866)) AND
                                                                                                                                     (ps.pitch_key <> 20809)) AND
                                                                                                                                    (ps.pitch_key <> 20938)) AND
                                                                                                                                   (ps.pitch_key <> 20940))) AND
                                                                                                                                 (dt.the_date < (('now'::text)::date + 1)))
                                                                                                                          GROUP BY dt.the_date
                                                                                                                          ORDER BY dt.the_date) inv ON ((dt.the_date = inv.the_date)))
                   LEFT JOIN (SELECT pi.user_key,
                                     pi.amount,
                                     pi.payment_method,
                                     pi.pitch_key,
                                     pi.investment_id,
                                     pi.fee_amount
                              FROM (fact_pitch_investments pi
                                     JOIN dim_pitches_static ps ON ((pi.pitch_key = ps.pitch_key)))
                              WHERE (((ps.portal_name)::text = 'crowdcube'::text) AND
                                     ((((((ps.pitch_key <> 19833) AND (ps.pitch_key <> 20779)) AND
                                         (ps.pitch_key <> 20866)) AND (ps.pitch_key <> 20809)) AND
                                       (ps.pitch_key <> 20938)) AND (ps.pitch_key <> 20940)))) id
                             ON ((id.investment_id = ds.first_id)))
            WHERE (dt.the_date < ('now'::text)::date)
            GROUP BY dt.the_date, inv.num_investors, inv.num_investments, inv.amount_invested, inv.amount_pledged,
                     inv.revenue
            ORDER BY dt.the_date DESC) x
      WHERE (x.the_date <= ('now'::text)::date)
      ORDER BY x.the_date DESC) y
WHERE (y.the_date > '2011-02-13'::date)
ORDER BY y.the_date DESC;

alter table v_metric_investor_activity_pledge_revenue
  owner to ccdatawh;

