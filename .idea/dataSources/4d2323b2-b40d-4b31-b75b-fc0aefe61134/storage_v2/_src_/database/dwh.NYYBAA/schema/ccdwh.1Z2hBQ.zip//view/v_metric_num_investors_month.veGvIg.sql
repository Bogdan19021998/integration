create view v_metric_num_investors_month as
SELECT dt.year_month, count(DISTINCT pi.user_key) AS num_investors_month
FROM ((fact_pitch_investments pi JOIN dim_dates dt ON ((pi.investment_date_key = dt.date_key)))
       JOIN v_master_pitches_latest pl ON ((pi.pitch_key = pl.pitch_key)))
WHERE (((((((((pl.pitch_key <> 19833) AND (pl.pitch_key <> 20779)) AND (pl.pitch_key <> 20866)) AND
            (pl.pitch_key <> 20809)) AND (pl.pitch_key <> 20938)) AND (pl.pitch_key <> 20940)) AND
         (((((((pl.pitch_status)::text = 'Active'::text) OR ((pl.pitch_status)::text = 'Funded'::text)) OR
             ((pl.pitch_status)::text = 'Cancelled'::text)) OR ((pl.pitch_status)::text = 'Expired'::text)) OR
           ((pl.pitch_status)::text = 'Active Hidden Private'::text)) OR
          ((pl.pitch_status)::text = 'Active Hidden'::text))) AND (dt.the_date < (('now'::text)::date + 1))) AND
       ((dt.year_month)::text >= '2015/04'::text))
GROUP BY dt.year_month
ORDER BY dt.year_month;

alter table v_metric_num_investors_month
  owner to ccdatawh;

