create view v_metric_new_repeat_visitors as
SELECT d.the_date,
       CASE
         WHEN (ss.count_second_sessions IS NULL) THEN (0)::bigint
         ELSE ss.count_second_sessions END AS count_second_visits
FROM (dim_dates d
       LEFT JOIN (SELECT date(derived_table2.first_repeat_session) AS session_date, count(*) AS count_second_sessions
                  FROM (SELECT derived_table1.anonymousid,
                               min(derived_table1.repeat_session_time) AS first_repeat_session
                        FROM (SELECT s.session_start_timestamp AS repeat_session_time,
                                     s.anonymousid,
                                     s.session_key,
                                     fsd.session_key
                              FROM (dim_sessions s
                                     JOIN (SELECT DISTINCT s.session_key, s.anonymousid, s.session_start_timestamp
                                           FROM (dim_sessions s
                                                  JOIN (SELECT DISTINCT dim_sessions.anonymousid,
                                                                        min(dim_sessions.session_start_timestamp) AS first_session_time
                                                        FROM dim_sessions
                                                        GROUP BY dim_sessions.anonymousid) fs
                                                       ON ((((s.anonymousid)::text = (fs.anonymousid)::text) AND
                                                            (s.session_start_timestamp = fs.first_session_time))))) fsd
                                          ON (((s.anonymousid)::text = (fsd.anonymousid)::text)))
                              WHERE ((s.session_key)::text <> (fsd.session_key)::text)) derived_table1
                        GROUP BY derived_table1.anonymousid) derived_table2
                  GROUP BY date(derived_table2.first_repeat_session)) ss ON ((d.the_date = ss.session_date)))
WHERE ((d.the_date > '2013-01-01'::date) AND (d.the_date < ('now'::text)::date))
ORDER BY d.the_date;

alter table v_metric_new_repeat_visitors
  owner to ccdatawh;

