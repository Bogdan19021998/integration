create view pg_stat_all_tables as
SELECT c.oid                                         AS relid,
       n.nspname                                     AS schemaname,
       c.relname,
       pg_stat_get_numscans(c.oid)                   AS seq_scan,
       pg_stat_get_tuples_returned(c.oid)            AS seq_tup_read,
       sum(pg_stat_get_numscans(i.indexrelid))       AS idx_scan,
       sum(pg_stat_get_tuples_fetched(i.indexrelid)) AS idx_tup_fetch,
       pg_stat_get_tuples_inserted(c.oid)            AS n_tup_ins,
       pg_stat_get_tuples_updated(c.oid)             AS n_tup_upd,
       pg_stat_get_tuples_deleted(c.oid)             AS n_tup_del
FROM ((pg_class c LEFT JOIN pg_index i ON ((c.oid = i.indrelid)))
       LEFT JOIN pg_namespace n ON ((n.oid = c.relnamespace)))
WHERE (c.relkind = 'r'::"char")
GROUP BY c.oid, n.nspname, c.relname;

alter table pg_stat_all_tables
  owner to rdsdb;

