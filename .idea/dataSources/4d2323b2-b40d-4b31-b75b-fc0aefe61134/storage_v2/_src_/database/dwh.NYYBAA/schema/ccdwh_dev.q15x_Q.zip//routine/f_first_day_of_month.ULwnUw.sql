create function f_first_day_of_month(date_to_inspect date) returns date
  stable
  language plpythonu
as
$$
        return date_to_inspect.replace(day=1)

$$;

