create view v_cluster_houseprices as
SELECT v_cluster_geospatial_investment.winner_cluster,
       avg(v_cluster_geospatial_investment.investment_total_amount) AS avg_member_worth,
       min(v_cluster_geospatial_investment.average_house_value)     AS min_house_value,
       "max"(v_cluster_geospatial_investment.average_house_value)   AS max_house_value,
       avg(v_cluster_geospatial_investment.average_house_value)     AS avg_house_value,
       count(*)                                                     AS num_instances
FROM ccseg.v_cluster_geospatial_investment
GROUP BY v_cluster_geospatial_investment.winner_cluster;

alter table v_cluster_houseprices
  owner to ccdatawh;

