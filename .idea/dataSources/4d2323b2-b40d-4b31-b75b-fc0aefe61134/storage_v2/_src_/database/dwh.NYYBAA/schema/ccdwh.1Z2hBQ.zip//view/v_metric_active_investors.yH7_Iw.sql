create view v_metric_active_investors as
SELECT dt.the_date, num30.active_investor_30_day, num60.active_investor_60_day, num90.active_investor_90_day
FROM (((dim_dates dt LEFT JOIN (SELECT dt.the_date, count(DISTINCT us.user_key) AS active_investor_30_day
                                FROM (((dim_dates dt JOIN fact_pitch_investments i ON ((
                                    (i.investment_date_key >= (dt.date_key - 30)) AND
                                    (i.investment_date_key <= dt.date_key)))) JOIN dim_users_static us ON ((i.user_key = us.user_key)))
                                       JOIN dim_pitches_static ps ON ((i.pitch_key = ps.pitch_key)))
                                WHERE ((((us.portal)::text = 'crowdcube'::text) AND
                                        ((ps.portal_name)::text = 'crowdcube'::text)) AND
                                       (dt.the_date <= ('now'::text)::date))
                                GROUP BY dt.the_date) num30 ON ((dt.the_date = num30.the_date))) LEFT JOIN (SELECT dt.the_date,
                                                                                                                   count(DISTINCT us.user_key) AS active_investor_60_day
                                                                                                            FROM (((dim_dates dt JOIN fact_pitch_investments i ON ((
                                                                                                                (i.investment_date_key >= (dt.date_key - 60)) AND
                                                                                                                (i.investment_date_key <= dt.date_key)))) JOIN dim_users_static us ON ((i.user_key = us.user_key)))
                                                                                                                   JOIN dim_pitches_static ps ON ((i.pitch_key = ps.pitch_key)))
                                                                                                            WHERE ((((us.portal)::text = 'crowdcube'::text) AND
                                                                                                                    ((ps.portal_name)::text = 'crowdcube'::text)) AND
                                                                                                                   (dt.the_date <= ('now'::text)::date))
                                                                                                            GROUP BY dt.the_date) num60 ON ((dt.the_date = num60.the_date)))
       LEFT JOIN (SELECT dt.the_date, count(DISTINCT us.user_key) AS active_investor_90_day
                  FROM (((dim_dates dt JOIN fact_pitch_investments i ON ((
                      (i.investment_date_key >= (dt.date_key - 90)) AND
                      (i.investment_date_key <= dt.date_key)))) JOIN dim_users_static us ON ((i.user_key = us.user_key)))
                         JOIN dim_pitches_static ps ON ((i.pitch_key = ps.pitch_key)))
                  WHERE ((((us.portal)::text = 'crowdcube'::text) AND ((ps.portal_name)::text = 'crowdcube'::text)) AND
                         (dt.the_date <= ('now'::text)::date))
                  GROUP BY dt.the_date) num90 ON ((dt.the_date = num90.the_date)))
WHERE ((dt.the_date > (('now'::text)::date - 366)) AND (dt.the_date <= ('now'::text)::date))
ORDER BY dt.the_date;

alter table v_metric_active_investors
  owner to ccdatawh;

