create view v_master_users_latest as
SELECT DISTINCT us.user_key,
                us.user_name,
                us.user_email,
                us.user_firstname,
                us.user_lastname,
                us.private_address_address_1,
                us.private_address_address_2,
                us.private_address_town,
                us.private_address_county,
                us.private_address_post_code,
                us.private_address_country,
                us.telephone,
                us.gender,
                us.portal,
                us.first_channel_key,
                us.registered_date_key,
                us.birth_date_key,
                us.registered_timestamp,
                us.rfi,
                us.rfm,
                uc.snapshot_date_key,
                uc.activated,
                uc.suspended,
                uc.deleted,
                uc.whitelist,
                uc.aml_status,
                uc.aml_status_last_checked_date_key,
                uc.user_type,
                uc.subscribed_newsletter,
                uc.subscribed_summary,
                uc.non_investor_newsletter_category,
                uc.user_category,
                uc.aml_status_checked_count,
                uc.aml_status_last_checked_date,
                uc.aml_status_last_interpreted_result,
                uc.aml_status_last_failure_reason,
                uc.aml_status_final_disposition_date,
                uc.aml_status_final_disposition,
                uc.users_email,
                uc.email_address_valid,
                uc.crowdcube_active_user,
                uc.investor_type_classification,
                uc.pitch_owner_type,
                uc.selligent_active_user
FROM (v_master_users_static us
       JOIN dim_users_changing uc ON (((us.user_key = uc.user_key) AND (uc.snapshot_date_key =
                                                                        (SELECT "max"(dim_users_changing.snapshot_date_key) AS "max"
                                                                         FROM dim_users_changing)))));

alter table v_master_users_latest
  owner to ccdatawh;

