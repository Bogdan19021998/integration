create view v_distil_investor_chronotype_classifications as
SELECT u.user_key,
       u.user_name,
       CASE
         WHEN ((engagement_hour.hour_engagement >= 0) AND (engagement_hour.hour_engagement <= 5))
           THEN 'Night-Owl (0 to 5)'::text
         WHEN ((engagement_hour.hour_engagement >= 6) AND (engagement_hour.hour_engagement <= 10))
           THEN 'Early-Bird (6 to 10)'::text
         WHEN ((engagement_hour.hour_engagement >= 11) AND (engagement_hour.hour_engagement <= 14))
           THEN 'Lunch-Timer (11 to 14)'::text
         WHEN ((engagement_hour.hour_engagement >= 15) AND (engagement_hour.hour_engagement <= 18))
           THEN 'Afternoon (15 to 18)'::text
         WHEN ((engagement_hour.hour_engagement >= 19) AND (engagement_hour.hour_engagement <= 23))
           THEN 'Evening (19 to 0)'::text
         ELSE 'Unknown'::text END AS chronotype
FROM (v_master_users_static u
       LEFT JOIN (SELECT derived_table3.user_key, derived_table3.hour_engagement
                  FROM (SELECT derived_table2.user_key,
                               derived_table2.hour_engagement,
                               derived_table2.count_engagements,
                               pg_catalog.row_number()
                               OVER ( PARTITION BY derived_table2.user_key ORDER BY derived_table2.count_engagements DESC, derived_table2.hour_engagement) AS rn
                        FROM (SELECT derived_table1.user_key,
                                     derived_table1.hour_engagement,
                                     count(*) AS count_engagements
                              FROM (SELECT fact_engagement.user_key,
                                           "date_part"('hour'::text, fact_engagement.event_timestamp) AS hour_engagement
                                    FROM fast.fact_engagement
                                    WHERE ((fact_engagement.user_key IS NOT NULL) AND
                                           (fact_engagement.user_key > 1))) derived_table1
                              GROUP BY derived_table1.user_key, derived_table1.hour_engagement) derived_table2) derived_table3
                  WHERE (derived_table3.rn = 1)) engagement_hour ON ((engagement_hour.user_key = u.user_key)))
ORDER BY u.user_key;

alter table v_distil_investor_chronotype_classifications
  owner to ccdatawh;

