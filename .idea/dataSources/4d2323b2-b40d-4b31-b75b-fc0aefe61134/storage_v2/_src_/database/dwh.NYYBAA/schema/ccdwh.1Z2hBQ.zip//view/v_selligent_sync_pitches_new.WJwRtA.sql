create view v_selligent_sync_pitches_new as
SELECT DISTINCT ps.pitch_key                                                                               AS pitch_id,
                (('"'::text || "replace"(btrim((ps.pitch_name)::text), '"'::text, ''::text)) || '"'::text) AS name,
                (('"'::text || (ps.pitch_logourl)::text) || '"'::text)                                     AS logo_url,
                (('"'::text || (ps.pitch_coverurl)::text) || '"'::text)                                    AS cover_image_url,
                (('"'::text || "replace"(btrim((ps.desciption)::text), '"'::text, ''::text)) || '"'::text) AS precis,
                (('"'::text || (ps.pitch_url)::text) || '"'::text)                                         AS pitch_url,
                pc.target_funding                                                                          AS target,
                pc.progress_percent,
                CASE
                  WHEN ((pc.pitch_status)::text = 'Active Hidden Private'::text) THEN 'Active Hid/Priv'::text
                  WHEN ((pc.pitch_status)::text = 'Active Hidden'::text) THEN 'Active Hid'::text
                  WHEN ((pc.pitch_status)::text = 'Active Private'::text) THEN 'Active Priv'::text
                  ELSE "substring"((pc.pitch_status)::text, 0, 15) END                                     AS pitch_status,
                pc.investor_count                                                                          AS number_investors,
                pc.reached_amount                                                                          AS investment_amount,
                pc.equity_offered,
                (('"'::text ||
                  (CASE WHEN ((pc.eis)::text = 'Pending'::text) THEN 'No'::character varying ELSE pc.eis END)::text) ||
                 '"'::text)                                                                                AS has_eis,
                (('"'::text || (CASE
                                  WHEN ((pc.seis)::text = 'Pending'::text) THEN 'No'::character varying
                                  ELSE pc.seis END)::text) || '"'::text)                                   AS has_seis,
                CASE
                  WHEN ((pc.pitch_expiry_date_key - pc.snapshot_date_key) < 0) THEN 0
                  ELSE (pc.pitch_expiry_date_key - pc.snapshot_date_key) END                               AS days_remaining,
                (('"'::text ||
                  "replace"("replace"(btrim((pc.update_title_1)::text), '"'::text, ''::text), '”'::text, ''::text)) ||
                 '"'::text)                                                                                AS update_title_1,
                (('"'::text || (pc.update_url_1)::text) || '"'::text)                                      AS update_url_1,
                (('"'::text ||
                  "replace"("replace"(btrim((pc.update_title_2)::text), '"'::text, ''::text), '”'::text, ''::text)) ||
                 '"'::text)                                                                                AS update_title_2,
                (('"'::text || (pc.update_url_2)::text) || '"'::text)                                      AS update_url_2,
                (('"'::text ||
                  "replace"("replace"(btrim((pc.update_title_3)::text), '"'::text, ''::text), '”'::text, ''::text)) ||
                 '"'::text)                                                                                AS update_title_3,
                (('"'::text || (pc.update_url_3)::text) || '"'::text)                                      AS update_url_3,
                (('"'::text ||
                  "replace"("replace"(btrim((pc.discussion_title_1)::text), '"'::text, ''::text), '”'::text,
                            ''::text)) ||
                 '"'::text)                                                                                AS discussion_title_1,
                (('"'::text || (pc.discussion_url_1)::text) || '"'::text)                                  AS discussion_url_1,
                (('"'::text ||
                  "replace"("replace"(btrim((pc.discussion_title_2)::text), '"'::text, ''::text), '”'::text,
                            ''::text)) ||
                 '"'::text)                                                                                AS discussion_title_2,
                (('"'::text || (pc.discussion_url_2)::text) || '"'::text)                                  AS discussion_url_2,
                (('"'::text ||
                  "replace"("replace"(btrim((pc.discussion_title_3)::text), '"'::text, ''::text), '”'::text,
                            ''::text)) ||
                 '"'::text)                                                                                AS discussion_title_3,
                (('"'::text || (pc.discussion_url_3)::text) || '"'::text)                                  AS discussion_url_3,
                COALESCE(pitch_update_count.total, (0)::bigint)                                            AS update_count_last_7_days,
                COALESCE(pitch_discussion_count.total, (0)::bigint)                                        AS discussion_count_last_7_days,
                pc.investment_last_7_days                                                                  AS amount_raised_last_7_days,
                pc.investment_delta                                                                        AS amount_raised_last_7_days_delta,
                pc.no_investment_last_7_days                                                               AS no_investors_last_7_days,
                pc.no_investment_delta                                                                     AS no_investors_last_7_days_delta,
                pc.max_investment                                                                          AS largest_investment_to_date,
                pc.pre_money_valuation,
                pc.follow_count                                                                            AS count_total_followers,
                ps.company_key                                                                             AS company_id
FROM ((((dim_pitches_static ps JOIN dim_pitches_changing pc ON (((ps.pitch_key = pc.pitch_key) AND
                                                                 (pc.snapshot_date_key =
                                                                  (SELECT "max"(dim_pitches_changing.snapshot_date_key) AS "max"
                                                                   FROM dim_pitches_changing))))) LEFT JOIN (SELECT ps.pitch_key,
                                                                                                                    COALESCE(inv_last_7_days.total, (0)::bigint)       AS last_7_days,
                                                                                                                    COALESCE(inv_previous_7_days.total, (0)::bigint)   AS last_14_days,
                                                                                                                    (COALESCE(inv_last_7_days.total, (0)::bigint) -
                                                                                                                     COALESCE(inv_previous_7_days.total, (0)::bigint)) AS inv_delta
                                                                                                             FROM ((dim_pitches_static ps LEFT JOIN (SELECT j.pitch_key, count(*) AS total
                                                                                                                                                     FROM (SELECT DISTINCT pi.pitch_key, pi.user_key
                                                                                                                                                           FROM (fact_pitch_investments pi
                                                                                                                                                                  JOIN dim_dates d ON ((d.date_key = pi.investment_date_key)))
                                                                                                                                                           WHERE (((pi.investment_status)::text = 'live'::text) AND
                                                                                                                                                                  (d.the_date > (('now'::text)::date - 7)))) j
                                                                                                                                                     GROUP BY j.pitch_key) inv_last_7_days ON ((inv_last_7_days.pitch_key = ps.pitch_key)))
                                                                                                                    LEFT JOIN (SELECT j.pitch_key, count(*) AS total
                                                                                                                               FROM (SELECT DISTINCT pi.pitch_key, pi.user_key
                                                                                                                                     FROM (fact_pitch_investments pi
                                                                                                                                            JOIN dim_dates d ON ((d.date_key = pi.investment_date_key)))
                                                                                                                                     WHERE ((((pi.investment_status)::text = 'live'::text) AND
                                                                                                                                             (d.the_date > (('now'::text)::date - 14))) AND
                                                                                                                                            (d.the_date <= (('now'::text)::date - 7)))) j
                                                                                                                               GROUP BY j.pitch_key) inv_previous_7_days
                                                                                                                              ON ((inv_previous_7_days.pitch_key = ps.pitch_key)))) inv ON ((inv.pitch_key = ps.pitch_key))) LEFT JOIN (SELECT ps.pitch_key, count(*) AS total
                                                                                                                                                                                                                                        FROM (dim_pitches_static ps
                                                                                                                                                                                                                                               JOIN fact_company_articles fca ON ((fca.company_key = ps.company_key)))
                                                                                                                                                                                                                                        WHERE (((fca.article_type)::text = 'update'::text) AND
                                                                                                                                                                                                                                               (fca.date_created > (('now'::text)::date - 7)))
                                                                                                                                                                                                                                        GROUP BY ps.pitch_key) pitch_update_count ON ((pitch_update_count.pitch_key = ps.pitch_key)))
       LEFT JOIN (SELECT ps.pitch_key, count(*) AS total
                  FROM (dim_pitches_static ps
                         JOIN fact_company_articles fca ON ((fca.company_key = ps.company_key)))
                  WHERE (((fca.article_type)::text = 'discussion'::text) AND
                         (fca.date_created > (('now'::text)::date - 7)))
                  GROUP BY ps.pitch_key) pitch_discussion_count ON ((pitch_discussion_count.pitch_key = ps.pitch_key)))
WHERE ((((btrim((ps.pitch_name)::text) <> ''::text) AND ((ps.portal_name)::text = 'crowdcube'::text)) AND
        ((ps.pitch_key <> 20938) AND (ps.pitch_key <> 20940))) AND
       (((((((pc.pitch_status)::text <> 'Not assigned'::text) AND ((pc.pitch_status)::text <> 'Pending'::text)) AND
           ((pc.pitch_status)::text <> 'Manual Pending'::text)) AND
          ((pc.pitch_status)::text <> 'Disapproved'::text)) AND
         ((pc.pitch_status)::text <> 'Publish Pending'::text)) AND ((pc.pitch_status)::text <> 'Incomplete'::text)))
ORDER BY ps.pitch_key;

alter table v_selligent_sync_pitches_new
  owner to ccdatawh;

