create view v_distil_purchase_history as
SELECT DISTINCT pi.user_key                  AS customer_id,
                pi.investment_id             AS order_id,
                pi.pitch_key                 AS product_id,
                pi.investment_timestamp      AS order_timestamp,
                1                            AS qty,
                pi.amount                    AS line_value_excluding_tax,
                pi.amount                    AS line_value_including_tax,
                pi.payment_method,
                pi.currency_iso_code         AS currency,
                us.private_address_post_code AS delivery_address_postcode,
                us.private_address_post_code AS billing_address_postcode,
                pi.fee_percentage,
                pi.fee_amount,
                pi.investment_fee_amount,
                pi.investment_status,
                pi.investment_source
FROM (fact_pitch_investments pi
       LEFT JOIN dim_users_static us ON ((pi.user_key = us.user_key)));

alter table v_distil_purchase_history
  owner to ccdatawh;

