create view v_metric_new_repeat_investors as
SELECT dt.the_date,
       CASE
         WHEN (ds3.count_second_investments IS NULL) THEN (0)::bigint
         ELSE ds3.count_second_investments END AS count_second_investments
FROM (dim_dates dt
       LEFT JOIN (SELECT ds2.first_second_investment_date_key AS date_key, count(*) AS count_second_investments
                  FROM (SELECT ds.user_key, min(ds.investment_date_key) AS first_second_investment_date_key
                        FROM (SELECT i.investment_date_key, i.user_key, i.pitch_key, f_i.pitch_key AS first_pitch_key
                              FROM ((fact_pitch_investments i JOIN dim_users_static us ON ((us.user_key = i.user_key)))
                                     JOIN (SELECT DISTINCT pi.user_key, pi.pitch_key
                                           FROM (fact_pitch_investments pi
                                                  JOIN (SELECT fact_pitch_investments.user_key,
                                                               min(fact_pitch_investments.investment_id) AS investment_id
                                                        FROM fact_pitch_investments
                                                        GROUP BY fact_pitch_investments.user_key) first_inv
                                                       ON (((pi.user_key = first_inv.user_key) AND
                                                            (pi.investment_id = first_inv.investment_id))))) f_i
                                          ON ((i.user_key = f_i.user_key)))
                              WHERE ((i.pitch_key <> f_i.pitch_key) AND ((us.portal)::text = 'crowdcube'::text))) ds
                        GROUP BY ds.user_key) ds2
                  GROUP BY ds2.first_second_investment_date_key
                  ORDER BY ds2.first_second_investment_date_key) ds3 ON ((dt.date_key = ds3.date_key)))
WHERE ((dt.the_date > '2013-01-01'::date) AND (dt.the_date <= ('now'::text)::date));

alter table v_metric_new_repeat_investors
  owner to ccdatawh;

