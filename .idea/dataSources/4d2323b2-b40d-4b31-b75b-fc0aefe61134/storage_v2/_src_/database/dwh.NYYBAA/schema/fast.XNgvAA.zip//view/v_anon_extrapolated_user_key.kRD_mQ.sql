create view v_anon_extrapolated_user_key as
SELECT derived_table1.anonymousid, "max"(derived_table1.user_key) AS extrapolated_user_key
FROM (SELECT DISTINCT s.anonymousid, e.user_key
      FROM (fast.fact_engagement e
             JOIN fast.dim_sessions s ON (((e.session_key)::text = (s.session_key)::text)))) derived_table1
GROUP BY derived_table1.anonymousid;

alter table v_anon_extrapolated_user_key
  owner to ccdatawh;

