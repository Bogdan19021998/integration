create view v_pitch_region as
SELECT x.pitch_key,
       x.company_address,
       x.company_postcode,
       CASE
         WHEN (((x.company_postcode IS NULL) OR ((x.company_postcode)::text = 'Not Assign'::text)) OR
               (("left"((x.company_postcode)::text, 1) >= (0)::text) AND
                ("left"((x.company_postcode)::text, 1) <= (9)::text))) THEN 'not known'::character varying
         WHEN ((x.pitch_key = 14964) OR (x.pitch_key = 16565)) THEN 'overseas'::character varying
         ELSE y.postaltown END   AS postal_town,
       CASE
         WHEN (((x.company_postcode IS NULL) OR ((x.company_postcode)::text = 'Not Assign'::text)) OR
               (("left"((x.company_postcode)::text, 1) >= (0)::text) AND
                ("left"((x.company_postcode)::text, 1) <= (9)::text))) THEN 'not known'::character varying
         WHEN ((x.pitch_key = 14964) OR (x.pitch_key = 16565)) THEN 'overseas'::character varying
         ELSE y.postalregion END AS postal_region,
       CASE
         WHEN (((x.company_postcode IS NULL) OR ((x.company_postcode)::text = 'Not Assign'::text)) OR
               (("left"((x.company_postcode)::text, 1) >= (0)::text) AND
                ("left"((x.company_postcode)::text, 1) <= (9)::text))) THEN 'not known'::character varying
         WHEN ((x.pitch_key = 14964) OR (x.pitch_key = 16565)) THEN 'overseas'::character varying
         ELSE y.tableautown END  AS tableau_town
FROM ((SELECT ps.pitch_key,
              ps.company_address,
              ps.company_postcode,
              CASE
                WHEN (((((((((("substring"((ps.company_postcode)::text, 2, 1) = '0'::text) OR
                              ("substring"((ps.company_postcode)::text, 2, 1) = '1'::text)) OR
                             ("substring"((ps.company_postcode)::text, 2, 1) = '2'::text)) OR
                            ("substring"((ps.company_postcode)::text, 2, 1) = '3'::text)) OR
                           ("substring"((ps.company_postcode)::text, 2, 1) = '4'::text)) OR
                          ("substring"((ps.company_postcode)::text, 2, 1) = '5'::text)) OR
                         ("substring"((ps.company_postcode)::text, 2, 1) = '6'::text)) OR
                        ("substring"((ps.company_postcode)::text, 2, 1) = '7'::text)) OR
                       ("substring"((ps.company_postcode)::text, 2, 1) = '8'::text)) OR
                      ("substring"((ps.company_postcode)::text, 2, 1) = '9'::text))
                  THEN upper("substring"((ps.company_postcode)::text, 1, 1))
                ELSE upper("substring"((ps.company_postcode)::text, 1, 2)) END AS truncated_postcode
       FROM dim_pitches_static ps
       WHERE ((ps.portal_name)::text = 'crowdcube'::text)) x
       LEFT JOIN (SELECT r.postcode, r.postaltown, r.postalregion, r.tableautown FROM dim_regions r) y
                 ON ((x.truncated_postcode = (y.postcode)::text)));

alter table v_pitch_region
  owner to ccdatawh;

