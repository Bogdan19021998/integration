create view v_mailchimp_sync_list as
SELECT u.user_key,
       lower((u.user_email)::text)                   AS user_email,
       u.user_firstname,
       u.user_lastname,
       u.user_type,
       u.subscribed_newsletter,
       u.subscribed_summary,
       CASE
         WHEN (u.non_investor_newsletter_category IS NULL) THEN 'Excluded'::character varying
         WHEN (u.subscribed_newsletter = false) THEN 'Excluded'::character varying
         ELSE u.non_investor_newsletter_category END AS non_investor_newsletter_category,
       CASE
         WHEN ((((u.snapshot_date_key - u.registered_date_key) = 1) AND (i.num_investments IS NULL)) AND
               (u.subscribed_newsletter = true)) THEN 'One day post registration'::text
         WHEN ((((u.snapshot_date_key - u.registered_date_key) = 2) AND (i.num_investments IS NULL)) AND
               (u.subscribed_newsletter = true)) THEN 'Two day post registration'::text
         WHEN ((((u.snapshot_date_key - u.registered_date_key) = 3) AND (i.num_investments IS NULL)) AND
               (u.subscribed_newsletter = true)) THEN 'Three day post registration'::text
         WHEN ((((u.snapshot_date_key - u.registered_date_key) = 7) AND (i.num_investments IS NULL)) AND
               (u.subscribed_newsletter = true)) THEN 'Seven day post registration'::text
         ELSE 'Excluded'::text END                   AS post_registration_engagement_category
FROM (v_master_users_latest u
       LEFT JOIN (SELECT fact_pitch_investments.user_key, count(*) AS num_investments
                  FROM fact_pitch_investments
                  GROUP BY fact_pitch_investments.user_key) i ON ((u.user_key = i.user_key)))
WHERE (((u.subscribed_newsletter = true) AND ((u.suspended)::text = 'No'::text)) AND ((u.deleted)::text = 'No'::text));

alter table v_mailchimp_sync_list
  owner to ccdatawh;

