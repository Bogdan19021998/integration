create view v_distil_sahara_funnel_pitchquality_score as
SELECT derived_table1.id,
       derived_table1.opportunity_id,
       derived_table1.pitch_id,
       derived_table1.opportunity_name,
       derived_table1.general_c,
       derived_table1.opportunity_owner,
       derived_table1.bd_manager,
       derived_table1.stage,
       derived_table1.owner_email,
       derived_table1.sector,
       derived_table1.source,
       derived_table1.created_date,
       derived_table1.days_since_opportunity_creation,
       derived_table1.raised_finance_before,
       derived_table1.prospective_target,
       derived_table1.minimum_fee,
       derived_table1.expected_fee,
       derived_table1.overfunding_fee,
       derived_table1.auto_qualification,
       derived_table1.hyperlink,
       derived_table1.beauhurst_url,
       derived_table1.in_beauhurst,
       derived_table1.tier_flag,
       CASE
         WHEN (derived_table1.tier_flag = 'Outbound'::text) THEN 40
         WHEN (derived_table1.tier_flag = 'Referral Partner'::text) THEN 35
         WHEN (derived_table1.tier_flag = 'Inbound (Triaged)'::text) THEN 20
         WHEN (derived_table1.tier_flag = 'Inbound (Register Interest)'::text) THEN 5
         ELSE NULL::integer END                                                                        AS channel_score,
       CASE
         WHEN (derived_table1.tier_flag = 'Outbound'::text) THEN CASE
                                                                   WHEN ((derived_table1.prospective_target)::text <= (250000)::text)
                                                                     THEN 10
                                                                   WHEN (
                                                                       ((derived_table1.prospective_target)::text > (250000)::text) AND
                                                                       ((derived_table1.prospective_target)::text <= (500000)::text))
                                                                     THEN 20
                                                                   WHEN (
                                                                       ((derived_table1.prospective_target)::text > (500000)::text) AND
                                                                       ((derived_table1.prospective_target)::text < (750000)::text))
                                                                     THEN 25
                                                                   WHEN ((derived_table1.prospective_target)::text >= (750000)::text)
                                                                     THEN 35
                                                                   ELSE NULL::integer END
         WHEN (derived_table1.tier_flag = 'Referral Partner'::text) THEN CASE
                                                                           WHEN ((derived_table1.prospective_target)::text <= (250000)::text)
                                                                             THEN 10
                                                                           WHEN (
                                                                               ((derived_table1.prospective_target)::text > (250000)::text) AND
                                                                               ((derived_table1.prospective_target)::text <= (500000)::text))
                                                                             THEN 20
                                                                           WHEN (
                                                                               ((derived_table1.prospective_target)::text > (500000)::text) AND
                                                                               ((derived_table1.prospective_target)::text < (750000)::text))
                                                                             THEN 25
                                                                           WHEN ((derived_table1.prospective_target)::text >= (750000)::text)
                                                                             THEN 30
                                                                           ELSE NULL::integer END
         WHEN (derived_table1.tier_flag = 'Inbound (Triaged)'::text) THEN CASE
                                                                            WHEN ((derived_table1.prospective_target)::text <= (250000)::text)
                                                                              THEN 3
                                                                            WHEN (
                                                                                ((derived_table1.prospective_target)::text > (250000)::text) AND
                                                                                ((derived_table1.prospective_target)::text <= (500000)::text))
                                                                              THEN 6
                                                                            WHEN (
                                                                                ((derived_table1.prospective_target)::text > (500000)::text) AND
                                                                                ((derived_table1.prospective_target)::text < (750000)::text))
                                                                              THEN 9
                                                                            WHEN ((derived_table1.prospective_target)::text >= (750000)::text)
                                                                              THEN 12
                                                                            ELSE NULL::integer END
         WHEN (derived_table1.tier_flag = 'Inbound (Register Interest)'::text) THEN CASE
                                                                                      WHEN ((derived_table1.prospective_target)::text <= (250000)::text)
                                                                                        THEN 2
                                                                                      WHEN (
                                                                                          ((derived_table1.prospective_target)::text > (250000)::text) AND
                                                                                          ((derived_table1.prospective_target)::text <= (500000)::text))
                                                                                        THEN 3
                                                                                      WHEN (
                                                                                          ((derived_table1.prospective_target)::text > (500000)::text) AND
                                                                                          ((derived_table1.prospective_target)::text < (750000)::text))
                                                                                        THEN 4
                                                                                      WHEN ((derived_table1.prospective_target)::text >= (750000)::text)
                                                                                        THEN 5
                                                                                      ELSE NULL::integer END
         ELSE NULL::integer END                                                                        AS target_score,
       CASE
         WHEN ((derived_table1.tier_flag = 'Outbound'::text) OR (derived_table1.tier_flag = 'Referral Partner'::text))
           THEN CASE WHEN (derived_table1.in_beauhurst = 'Yes'::text) THEN 25 ELSE 0 END
         WHEN (derived_table1.tier_flag = 'Inbound (Triaged)'::text)
           THEN CASE WHEN (derived_table1.in_beauhurst = 'Yes'::text) THEN 15 ELSE 0 END
         WHEN (derived_table1.tier_flag = 'Inbound (Register Interest)'::text)
           THEN CASE WHEN (derived_table1.in_beauhurst = 'Yes'::text) THEN 5 ELSE 0 END
         ELSE NULL::integer END                                                                        AS bh_score,
       ((COALESCE(CASE
                    WHEN (derived_table1.tier_flag = 'Outbound'::text) THEN 40
                    WHEN (derived_table1.tier_flag = 'Referral Partner'::text) THEN 35
                    WHEN (derived_table1.tier_flag = 'Inbound (Triaged)'::text) THEN 20
                    WHEN (derived_table1.tier_flag = 'Inbound (Register Interest)'::text) THEN 5
                    ELSE NULL::integer END, 0) + COALESCE(CASE
                                                            WHEN (derived_table1.tier_flag = 'Outbound'::text) THEN CASE
                                                                                                                      WHEN ((derived_table1.prospective_target)::text <= (250000)::text)
                                                                                                                        THEN 10
                                                                                                                      WHEN (
                                                                                                                          ((derived_table1.prospective_target)::text > (250000)::text) AND
                                                                                                                          ((derived_table1.prospective_target)::text <= (500000)::text))
                                                                                                                        THEN 20
                                                                                                                      WHEN (
                                                                                                                          ((derived_table1.prospective_target)::text > (500000)::text) AND
                                                                                                                          ((derived_table1.prospective_target)::text < (750000)::text))
                                                                                                                        THEN 25
                                                                                                                      WHEN ((derived_table1.prospective_target)::text >= (750000)::text)
                                                                                                                        THEN 35
                                                                                                                      ELSE NULL::integer END
                                                            WHEN (derived_table1.tier_flag = 'Referral Partner'::text)
                                                              THEN CASE
                                                                     WHEN ((derived_table1.prospective_target)::text <= (250000)::text)
                                                                       THEN 10
                                                                     WHEN (
                                                                         ((derived_table1.prospective_target)::text > (250000)::text) AND
                                                                         ((derived_table1.prospective_target)::text <= (500000)::text))
                                                                       THEN 20
                                                                     WHEN (
                                                                         ((derived_table1.prospective_target)::text > (500000)::text) AND
                                                                         ((derived_table1.prospective_target)::text < (750000)::text))
                                                                       THEN 25
                                                                     WHEN ((derived_table1.prospective_target)::text >= (750000)::text)
                                                                       THEN 30
                                                                     ELSE NULL::integer END
                                                            WHEN (derived_table1.tier_flag = 'Inbound (Triaged)'::text)
                                                              THEN CASE
                                                                     WHEN ((derived_table1.prospective_target)::text <= (250000)::text)
                                                                       THEN 3
                                                                     WHEN (
                                                                         ((derived_table1.prospective_target)::text > (250000)::text) AND
                                                                         ((derived_table1.prospective_target)::text <= (500000)::text))
                                                                       THEN 6
                                                                     WHEN (
                                                                         ((derived_table1.prospective_target)::text > (500000)::text) AND
                                                                         ((derived_table1.prospective_target)::text < (750000)::text))
                                                                       THEN 9
                                                                     WHEN ((derived_table1.prospective_target)::text >= (750000)::text)
                                                                       THEN 12
                                                                     ELSE NULL::integer END
                                                            WHEN (derived_table1.tier_flag = 'Inbound (Register Interest)'::text)
                                                              THEN CASE
                                                                     WHEN ((derived_table1.prospective_target)::text <= (250000)::text)
                                                                       THEN 2
                                                                     WHEN (
                                                                         ((derived_table1.prospective_target)::text > (250000)::text) AND
                                                                         ((derived_table1.prospective_target)::text <= (500000)::text))
                                                                       THEN 3
                                                                     WHEN (
                                                                         ((derived_table1.prospective_target)::text > (500000)::text) AND
                                                                         ((derived_table1.prospective_target)::text < (750000)::text))
                                                                       THEN 4
                                                                     WHEN ((derived_table1.prospective_target)::text >= (750000)::text)
                                                                       THEN 5
                                                                     ELSE NULL::integer END
                                                            ELSE NULL::integer END, 0)) + COALESCE(CASE
                                                                                                     WHEN (
                                                                                                         (derived_table1.tier_flag = 'Outbound'::text) OR
                                                                                                         (derived_table1.tier_flag = 'Referral Partner'::text))
                                                                                                       THEN CASE WHEN (derived_table1.in_beauhurst = 'Yes'::text) THEN 25 ELSE 0 END
                                                                                                     WHEN (derived_table1.tier_flag = 'Inbound (Triaged)'::text)
                                                                                                       THEN CASE WHEN (derived_table1.in_beauhurst = 'Yes'::text) THEN 15 ELSE 0 END
                                                                                                     WHEN (derived_table1.tier_flag = 'Inbound (Register Interest)'::text)
                                                                                                       THEN CASE WHEN (derived_table1.in_beauhurst = 'Yes'::text) THEN 5 ELSE 0 END
                                                                                                     ELSE NULL::integer END,
                                                                                                   0)) AS pitch_score
FROM (SELECT sfo.id,
             sfo.x18_digit_id_c                                                                           AS opportunity_id,
             opp_pitch.pitch_key                                                                          AS pitch_id,
             sfo.name                                                                                     AS opportunity_name,
             sfo.general_c,
             sfcb.name                                                                                    AS opportunity_owner,
             sfbd.name                                                                                    AS bd_manager,
             sfo.stage_name                                                                               AS stage,
             ct.email                                                                                     AS owner_email,
             sfo.industry_c                                                                               AS sector,
             sfo.pitch_tier_c                                                                             AS source,
             sfo.created_date,
             date_diff('day'::text, sfo.created_date,
                       (('now'::text)::date)::timestamp without time zone)                                AS days_since_opportunity_creation,
             CASE
               WHEN (b.date_of_the_last_fundraising IS NULL) THEN 'No'::text
               ELSE 'Yes'::text END                                                                       AS raised_finance_before,
             sfo.prospective_target_c                                                                     AS prospective_target,
             sfo.minimum_fee_c                                                                            AS minimum_fee,
             sfo.expected_fee_c                                                                           AS expected_fee,
             sfo.overfunding_fee_c                                                                        AS overfunding_fee,
             q.auto_qualification,
             ('https://eu7.salesforce.com/'::text + (sfo.x18_digit_id_c)::text)                           AS hyperlink,
             sfo.beauhurst_url_c                                                                          AS beauhurst_url,
             CASE
               WHEN (sfo.beauhurst_url_c IS NULL) THEN 'No'::text
               ELSE 'Yes'::text END                                                                       AS in_beauhurst,
             CASE
               WHEN ((sfo.opportunity_source_c)::text = 'Outbound'::text) THEN 'Outbound'::text
               WHEN ((sfo.opportunity_source_c)::text = 'Referral Partner'::text) THEN 'Referral Partner'::text
               WHEN (((sfo.opportunity_source_c)::text = 'Inbound'::text) AND
                     ((sfo.priority_tiers_c)::text = 'Priority 3'::text)) THEN 'Inbound (Triaged)'::text
               ELSE 'Inbound (Register Interest)'::text END                                               AS tier_flag
      FROM ((((((((sfexperimental.opportunities sfo LEFT JOIN sfexperimental.users sfbd ON (((sfbd.id)::text = (sfo.bd_manager_c)::text))) LEFT JOIN sfexperimental.users sfcb ON (((sfcb.id)::text = (sfo.created_by_id)::text))) LEFT JOIN v_salesforce_opportunity_pitch_relation opp_pitch ON (((opp_pitch.opportunity_id)::text = (sfo.x18_digit_id_c)::text))) LEFT JOIN sfexperimental.contacts ct ON (((sfo.primary_contact_18_id_c)::text = (ct.id)::text))) LEFT JOIN sfexperimental.companies c ON (((sfo.account_18_id_c)::text = (c.id)::text))) LEFT JOIN sfexperimental.leads l ON (((sfo.lead_18_id_c)::text = (l.id)::text))) LEFT JOIN sahara.beauhurst_data b ON ((
          lpad((c.company_reg_number_c)::text, 8, (0)::text) = (b.companies_house_number)::text)))
             LEFT JOIN (SELECT v_sf_opportunity_validation_latest.opportunity_id,
                               CASE
                                 WHEN ((v_sf_opportunity_validation_latest.website_response_code = 200) AND
                                       ((((v_sf_opportunity_validation_latest.ch_result)::text =
                                          'COMPANIES_HOUSE_NUMBER'::text) OR
                                         ((v_sf_opportunity_validation_latest.ch_result)::text = 'TITLE'::text)) OR
                                        ((v_sf_opportunity_validation_latest.ch_result)::text =
                                         'ALTERNATE_TITLE'::text))) THEN 'Passed'::text
                                 ELSE 'Failed'::text END AS auto_qualification
                        FROM sahara.v_sf_opportunity_validation_latest) q
                       ON (((sfo.id)::text = (q.opportunity_id)::text)))
      WHERE (sfo.is_test_c = false)) derived_table1;

alter table v_distil_sahara_funnel_pitchquality_score
  owner to ccdatawh;

