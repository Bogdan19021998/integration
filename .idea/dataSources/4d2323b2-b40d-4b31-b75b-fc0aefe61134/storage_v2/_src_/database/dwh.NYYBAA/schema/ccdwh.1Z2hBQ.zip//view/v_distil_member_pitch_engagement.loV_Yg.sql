create view v_distil_member_pitch_engagement as
SELECT us.user_key,
       us.user_name,
       us.user_email,
       uc.selligent_active_user,
       uc.crowdcube_active_user,
       pitches.pitch_key,
       pitches.pitch_name,
       pitches.pitch_status,
       CASE WHEN (fol.company_key IS NULL) THEN false ELSE true END                               AS follows_company,
       CASE WHEN (inv.num_investments IS NULL) THEN (0)::bigint ELSE inv.num_investments END      AS num_investments,
       CASE WHEN (inv.value_investments IS NULL) THEN (0)::numeric ELSE inv.value_investments END AS value_investments,
       CASE WHEN (eng.engagement_count IS NULL) THEN (0)::bigint ELSE eng.engagement_count END    AS engagement_count,
       CASE WHEN (geo.geo_distance IS NULL) THEN (-1)::double precision ELSE geo.geo_distance END AS geo_distance
FROM ((((((dim_users_static us JOIN dim_users_changing uc ON (((us.user_key = uc.user_key) AND (uc.snapshot_date_key =
                                                                                                (SELECT dim_dates.date_key
                                                                                                 FROM dim_dates
                                                                                                 WHERE (dim_dates.the_date = ('now'::text)::date)))))) CROSS JOIN (SELECT ps.pitch_key,
                                                                                                                                                                          ps.pitch_name,
                                                                                                                                                                          pc.pitch_status,
                                                                                                                                                                          pc.reached_amount,
                                                                                                                                                                          ps.company_key
                                                                                                                                                                   FROM (dim_pitches_static ps
                                                                                                                                                                          JOIN dim_pitches_changing pc
                                                                                                                                                                               ON ((
                                                                                                                                                                                   (ps.pitch_key = pc.pitch_key) AND
                                                                                                                                                                                   (pc.snapshot_date_key =
                                                                                                                                                                                    (SELECT dim_dates.date_key
                                                                                                                                                                                     FROM dim_dates
                                                                                                                                                                                     WHERE (dim_dates.the_date = ('now'::text)::date))))))
                                                                                                                                                                   WHERE (((ps.last_investment_date_key >
                                                                                                                                                                            (SELECT (dim_dates.date_key - 365)
                                                                                                                                                                             FROM dim_dates
                                                                                                                                                                             WHERE (dim_dates.the_date = ('now'::text)::date))) AND
                                                                                                                                                                           (pc.reached_amount > (0)::numeric)) AND
                                                                                                                                                                          (((pc.pitch_status)::text <> 'Expired'::text) AND
                                                                                                                                                                           ((pc.pitch_status)::text <> 'Cancelled'::text)))) pitches) LEFT JOIN (SELECT fact_pitch_investments.user_key,
                                                                                                                                                                                                                                                        fact_pitch_investments.pitch_key,
                                                                                                                                                                                                                                                        count(*)                                  AS num_investments,
                                                                                                                                                                                                                                                        sum(fact_pitch_investments.amount_in_gbp) AS value_investments
                                                                                                                                                                                                                                                 FROM fact_pitch_investments
                                                                                                                                                                                                                                                 WHERE ((((fact_pitch_investments.investment_status)::text <> 'cancelled'::text) AND
                                                                                                                                                                                                                                                         ((fact_pitch_investments.investment_status)::text <> 'refunded'::text)) AND
                                                                                                                                                                                                                                                        ((fact_pitch_investments.investment_status)::text <> 'expired'::text))
                                                                                                                                                                                                                                                 GROUP BY fact_pitch_investments.user_key,
                                                                                                                                                                                                                                                          fact_pitch_investments.pitch_key) inv ON (((us.user_key = inv.user_key) AND (pitches.pitch_key = inv.pitch_key)))) LEFT JOIN (SELECT fact_engagement.user_key,
                                                                                                                                                                                                                                                                                                                                                                                               fact_engagement.pitch_key,
                                                                                                                                                                                                                                                                                                                                                                                               count(*) AS engagement_count
                                                                                                                                                                                                                                                                                                                                                                                        FROM fast.fact_engagement
                                                                                                                                                                                                                                                                                                                                                                                        GROUP BY fact_engagement.user_key, fact_engagement.pitch_key) eng ON (((us.user_key = eng.user_key) AND (pitches.pitch_key = eng.pitch_key)))) LEFT JOIN fact_company_follows fol ON ((
    (pitches.company_key = fol.company_key) AND (us.user_key = fol.user_key))))
       LEFT JOIN (SELECT user_pitch.pitch_key, user_pitch.user_key, user_pitch.geo_distance
                  FROM (SELECT p.pitch_key,
                               u.user_key,
                               f_latlog_distance((p.lat)::double precision, (p.long)::double precision,
                                                 (postcodes_user.lat)::double precision,
                                                 (postcodes_user.long)::double precision) AS geo_distance
                        FROM (((SELECT DISTINCT u.user_key,
                                                u.user_name,
                                                u.user_email,
                                                u.user_firstname,
                                                u.user_lastname,
                                                u.private_address_address_1,
                                                u.private_address_address_2,
                                                u.private_address_town,
                                                u.private_address_county,
                                                u.private_address_post_code,
                                                u.private_address_country,
                                                u.telephone,
                                                u.gender,
                                                u.portal,
                                                u.first_channel_key,
                                                u.registered_date_key,
                                                u.birth_date_key,
                                                u.registered_timestamp,
                                                u.rfi,
                                                u.rfm,
                                                u.snapshot_date_key,
                                                u.activated,
                                                u.suspended,
                                                u.deleted,
                                                u.whitelist,
                                                u.aml_status,
                                                u.aml_status_last_checked_date_key,
                                                u.user_type,
                                                u.subscribed_newsletter,
                                                u.subscribed_summary,
                                                u.non_investor_newsletter_category,
                                                u.user_category,
                                                u.aml_status_checked_count,
                                                u.aml_status_last_checked_date,
                                                u.aml_status_last_interpreted_result,
                                                u.aml_status_last_failure_reason,
                                                u.aml_status_final_disposition_date,
                                                u.aml_status_final_disposition,
                                                u.users_email,
                                                u.email_address_valid,
                                                u.crowdcube_active_user,
                                                u.investor_type_classification,
                                                u.pitch_owner_type,
                                                u.selligent_active_user,
                                                CASE WHEN (mod(u.user_key, 2) = 1) THEN 'A'::text ELSE 'B'::text END AS ab_category,
                                                us.encrypted_user_id
                                FROM (v_master_users_latest u
                                       JOIN dim_users_static us ON ((us.user_key = u.user_key)))
                                WHERE (((u.selligent_active_user)::text = 'Active'::text) OR
                                       ((((u.user_key = 123248) OR (u.user_key = 164222)) OR (u.user_key = 34462)) OR
                                        (u.user_key = 429473)))) u LEFT JOIN (SELECT upper("replace"((onspd.pcd)::text, ' '::text, ''::text)) AS upper_postcode,
                                                                                     onspd.lat,
                                                                                     onspd.long
                                                                              FROM onsdata.onspd) postcodes_user ON ((
                            postcodes_user.upper_postcode =
                            upper("replace"((u.private_address_post_code)::text, ' '::text, ''::text)))))
                               CROSS JOIN (SELECT p.pitch_key, postcodes_pitch.lat, postcodes_pitch.long
                                           FROM (v_master_pitches_latest p
                                                  LEFT JOIN (SELECT upper("replace"((onspd.pcd)::text, ' '::text, ''::text)) AS upper_postcode,
                                                                    onspd.lat,
                                                                    onspd.long
                                                             FROM onsdata.onspd) postcodes_pitch
                                                            ON ((postcodes_pitch.upper_postcode = upper(
                                                                "replace"((p.company_postcode)::text, ' '::text, ''::text)))))
                                           WHERE ((postcodes_pitch.lat IS NOT NULL) AND
                                                  (((p.pitch_status)::text <> 'Expired'::text) AND
                                                   ((p.pitch_status)::text <> 'Cancelled'::text)))
                                           LIMIT 1) p)
                        WHERE (postcodes_user.lat IS NOT NULL)) user_pitch) geo
                 ON (((pitches.pitch_key = geo.pitch_key) AND (us.user_key = geo.user_key))));

alter table v_distil_member_pitch_engagement
  owner to ccdatawh;

