create function f_first_day_of_current_month() returns date
  stable
  language plpythonu
as
$$
        return dateadd(day, 1, dateadd(month, -1, last_day(current_date)))

$$;

