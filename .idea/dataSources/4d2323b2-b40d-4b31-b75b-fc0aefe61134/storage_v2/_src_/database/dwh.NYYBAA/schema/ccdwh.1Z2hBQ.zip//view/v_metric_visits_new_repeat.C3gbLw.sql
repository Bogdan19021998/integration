create view v_metric_visits_new_repeat as
SELECT x.the_date, x.num_new_visits, (x.num_visits - x.num_new_visits) AS num_repeat_visits, x.num_visits
FROM (SELECT dt.the_date, sum(nv.num_new_visits) AS num_new_visits, s.count_of_sessions AS num_visits
      FROM (((dim_dates dt LEFT JOIN (SELECT DISTINCT s.anonymousid, min(s.session_start_date_key) AS first_session
                                      FROM dim_sessions s
                                      GROUP BY s.anonymousid) fs ON ((dt.date_key = fs.first_session))) LEFT JOIN (SELECT s.session_start_date_key,
                                                                                                                          s.anonymousid,
                                                                                                                          count(*) AS num_new_visits
                                                                                                                   FROM dim_sessions s
                                                                                                                   GROUP BY s.session_start_date_key, s.anonymousid) nv ON ((
          (dt.date_key = nv.session_start_date_key) AND ((fs.anonymousid)::text = (nv.anonymousid)::text))))
             LEFT JOIN v_num_sessions_per_day s ON ((dt.the_date = s.the_date)))
      WHERE ((dt.the_date < ('now'::text)::date) AND (dt.the_date > '2013-01-01'::date))
      GROUP BY dt.the_date, s.count_of_sessions
      ORDER BY dt.the_date DESC) x
ORDER BY x.the_date DESC;

alter table v_metric_visits_new_repeat
  owner to ccdatawh;

