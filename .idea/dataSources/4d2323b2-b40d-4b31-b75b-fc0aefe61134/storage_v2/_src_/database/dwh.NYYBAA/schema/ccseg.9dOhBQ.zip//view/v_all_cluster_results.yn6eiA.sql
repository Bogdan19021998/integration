create view v_all_cluster_results as
  SELECT uca.user_key,
         uca.user_name,
         uca.user_email,
         uca.investment_count,
         uca.investment_total_amount,
         uca.investment_avg_amount,
         uca.investment_max_amount,
         uca.investment_min_amount,
         uca.winner_cluster,
         uca.average_weekly_income,
         uca.perc_upper_middle_class,
         uca.perc_higher_managerial,
         uca.perc_full_time_student,
         uca.perc_level_4,
         uca.perc_shared_ownership,
         uca.sanitised_postcode,
         uca.run_code,
         1 AS from_clustering
  FROM ccseg.tbl_user_cluster_assignments uca
  UNION
  SELECT u.user_key,
         ud.user_name,
         ud.user_email,
         ud.investment_count,
         ud.investment_total_amount,
         ud.investment_avg_amount,
         ud.investment_max_amount,
         ud.investment_min_amount,
         u.winner_cluster,
         ud.average_weekly_income,
         ud.perc_upper_middle_class,
         ud.perc_higher_managerial,
         ud.perc_full_time_student,
         ud.perc_level_4,
         ud.perc_shared_ownership,
         ud.sanitised_postcode,
         u.run_code,
         0 AS from_clustering
  FROM (ccseg.tbl_user_new_cluster_assignments u
         JOIN ccseg.tbl_user_demographics ud ON ((ud.user_key = u.user_key)));

alter table v_all_cluster_results
  owner to ccdatawh;

