create view v_pitch_hot_investors as
SELECT v_hot_investor_lists.pitch_key, count(DISTINCT v_hot_investor_lists.user_key) AS hot_investors
FROM v_hot_investor_lists
GROUP BY v_hot_investor_lists.pitch_key
ORDER BY v_hot_investor_lists.pitch_key;

alter table v_pitch_hot_investors
  owner to ccdatawh;

