create view v_customer_segment_membership_latest as
SELECT ds.id,
       ds.customer_rows_hash,
       ds.fk_customer_segment_id,
       ds.fk_customer_id,
       ds.date_changed,
       ds.in_segment
FROM (SELECT customer_segment_membership.id,
             customer_segment_membership.fk_customer_segment_id,
             customer_segment_membership.fk_customer_id,
             customer_segment_membership.date_changed,
             customer_segment_membership.in_segment,
             customer_segment_membership.customer_rows_hash,
             row_number()
                 OVER (PARTITION BY customer_segment_membership.fk_customer_id, customer_segment_membership.fk_customer_segment_id ORDER BY customer_segment_membership.id DESC) AS rn
      FROM distil_org_xx.customer_segment_membership) ds
WHERE ((ds.rn = 1) AND (ds.in_segment = true));

alter table v_customer_segment_membership_latest
  owner to postgres;

