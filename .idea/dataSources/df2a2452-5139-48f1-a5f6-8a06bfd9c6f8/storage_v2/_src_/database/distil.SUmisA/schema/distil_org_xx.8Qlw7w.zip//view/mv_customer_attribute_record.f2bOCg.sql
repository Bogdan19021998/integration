create view mv_customer_attribute_record as
SELECT customer_attribute_record_1575909357358.id,
       customer_attribute_record_1575909357358.customer_id,
       customer_attribute_record_1575909357358.data_source_id,
       customer_attribute_record_1575909357358.data_source_name,
       customer_attribute_record_1575909357358.attribute_id,
       customer_attribute_record_1575909357358.attribute_distil_name,
       customer_attribute_record_1575909357358.attribute_display_name,
       customer_attribute_record_1575909357358.attribute_type,
       customer_attribute_record_1575909357358.attribute_data_tag,
       customer_attribute_record_1575909357358.value_integer,
       customer_attribute_record_1575909357358.value_double,
       customer_attribute_record_1575909357358.value_string,
       customer_attribute_record_1575909357358.value_text,
       customer_attribute_record_1575909357358.value_date,
       customer_attribute_record_1575909357358.value_boolean,
       customer_attribute_record_1575909357358.value_long
FROM distil_org_xx.customer_attribute_record_1575909357358;

alter table mv_customer_attribute_record
  owner to postgres;

