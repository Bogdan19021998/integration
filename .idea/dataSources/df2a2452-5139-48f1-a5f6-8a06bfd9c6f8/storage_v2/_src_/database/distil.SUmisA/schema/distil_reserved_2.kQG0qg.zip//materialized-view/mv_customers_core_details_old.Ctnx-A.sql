create materialized view mv_customers_core_details_old as
  WITH customer_core_data AS (
    SELECT v.fk_customer_id AS customer_id,
           v.value_string,
           a.attribute_data_tag
    FROM (distil_reserved_2.data_source_attribute_value v
           JOIN distil_reserved_2.data_source_attribute a ON ((v.fk_data_source_attribute_id = a.id)))
    WHERE (v.fk_data_source_id = (SELECT data_source.id
                                  FROM distil_reserved_2.data_source
                                  WHERE ((data_source.data_source_type)::text = 'CUSTOMER_CORE_DATA'::text)))
    ), customer_ids AS (
    SELECT DISTINCT customer_core_data.customer_id
    FROM customer_core_data
    ), external_ids AS (
    SELECT customer_core_data.customer_id,
           customer_core_data.value_string AS external_id
    FROM customer_core_data
    WHERE (customer_core_data.attribute_data_tag = 'CUSTOMER_EXTERNAL_ID'::distil_reserved_2.attribute_data_tag)
    ), first_names AS (
    SELECT customer_core_data.customer_id,
           customer_core_data.value_string AS first_name
    FROM customer_core_data
    WHERE (customer_core_data.attribute_data_tag = 'CUSTOMER_FIRST_NAME'::distil_reserved_2.attribute_data_tag)
    ), last_names AS (
    SELECT customer_core_data.customer_id,
           customer_core_data.value_string AS last_name
    FROM customer_core_data
    WHERE (customer_core_data.attribute_data_tag = 'CUSTOMER_LAST_NAME'::distil_reserved_2.attribute_data_tag)
    ), email_addresses AS (
    SELECT customer_core_data.customer_id,
           customer_core_data.value_string AS email_address
    FROM customer_core_data
    WHERE (customer_core_data.attribute_data_tag = 'CUSTOMER_EMAIL_ADDRESS'::distil_reserved_2.attribute_data_tag)
    ), mobile_numbers AS (
    SELECT customer_core_data.customer_id,
           customer_core_data.value_string AS mobile_number
    FROM customer_core_data
    WHERE (customer_core_data.attribute_data_tag = 'CUSTOMER_MOBILE_NUMBER'::distil_reserved_2.attribute_data_tag)
    ), postcodes AS (
    SELECT customer_core_data.customer_id,
           customer_core_data.value_string AS postal_code
    FROM customer_core_data
    WHERE (customer_core_data.attribute_data_tag = 'CUSTOMER_POSTCODE'::distil_reserved_2.attribute_data_tag)
    ), country_codes AS (
    SELECT customer_core_data.customer_id,
           customer_core_data.value_string AS country_code
    FROM customer_core_data
    WHERE (customer_core_data.attribute_data_tag = 'CUSTOMER_COUNTRY_CODE'::distil_reserved_2.attribute_data_tag)
    )
    SELECT c.customer_id AS id,
           ex.external_id,
           fn.first_name,
           ln.last_name,
           em.email_address,
           mb.mobile_number,
           pc.postal_code,
           cc.country_code
    FROM (((((((customer_ids c
      LEFT JOIN external_ids ex ON (((c.customer_id)::text = (ex.customer_id)::text)))
      LEFT JOIN first_names fn ON (((c.customer_id)::text = (fn.customer_id)::text)))
      LEFT JOIN last_names ln ON (((c.customer_id)::text = (ln.customer_id)::text)))
      LEFT JOIN email_addresses em ON (((c.customer_id)::text = (em.customer_id)::text)))
      LEFT JOIN mobile_numbers mb ON (((c.customer_id)::text = (mb.customer_id)::text)))
      LEFT JOIN postcodes pc ON (((c.customer_id)::text = (pc.customer_id)::text)))
           LEFT JOIN country_codes cc ON (((c.customer_id)::text = (cc.customer_id)::text)));

alter materialized view mv_customers_core_details_old owner to postgres;

create index idx_mv_customers_core_details_external_id
  on mv_customers_core_details_old (lower(external_id::text));

create index idx_mv_customers_core_details_first_name
  on mv_customers_core_details_old (lower(first_name::text));

create index idx_mv_customers_core_details_last_name
  on mv_customers_core_details_old (lower(last_name::text));

create index idx_mv_customers_core_details_email_address
  on mv_customers_core_details_old (lower(email_address::text));

create index idx_mv_customers_core_details_mobile_number
  on mv_customers_core_details_old (lower(mobile_number::text));

create index idx_mv_customers_core_details_postal_code
  on mv_customers_core_details_old (lower(postal_code::text));

create index idx_mv_customers_core_details_country_code
  on mv_customers_core_details_old (lower(country_code::text));

