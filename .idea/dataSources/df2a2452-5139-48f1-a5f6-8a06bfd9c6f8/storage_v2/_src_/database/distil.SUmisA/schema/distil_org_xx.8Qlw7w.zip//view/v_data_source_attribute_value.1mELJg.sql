create view v_data_source_attribute_value as
SELECT data_source_attribute_value_1575909357323.id,
       data_source_attribute_value_1575909357323.fk_customer_id,
       data_source_attribute_value_1575909357323.fk_data_source_id,
       data_source_attribute_value_1575909357323.fk_data_source_attribute_id,
       data_source_attribute_value_1575909357323.date_created,
       data_source_attribute_value_1575909357323.date_updated,
       data_source_attribute_value_1575909357323.value_integer,
       data_source_attribute_value_1575909357323.value_double,
       data_source_attribute_value_1575909357323.value_string,
       data_source_attribute_value_1575909357323.value_text,
       data_source_attribute_value_1575909357323.value_date,
       data_source_attribute_value_1575909357323.value_boolean,
       data_source_attribute_value_1575909357323.value_long
FROM distil_org_xx.data_source_attribute_value_1575909357323;

alter table v_data_source_attribute_value
  owner to postgres;

