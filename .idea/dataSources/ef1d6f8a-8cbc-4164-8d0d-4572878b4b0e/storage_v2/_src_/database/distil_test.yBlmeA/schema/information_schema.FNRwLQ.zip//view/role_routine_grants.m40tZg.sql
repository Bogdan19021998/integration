create view role_routine_grants as
SELECT (u_grantor.usename)::information_schema.sql_identifier                                                        AS grantor,
       (g_grantee.groname)::information_schema.sql_identifier                                                        AS grantee,
       (current_database())::information_schema.sql_identifier                                                       AS specific_catalog,
       (n.nspname)::information_schema.sql_identifier                                                                AS specific_schema,
       ((((p.proname)::text || '_'::text) ||
         ((p.oid)::character varying)::text))::information_schema.sql_identifier                                     AS specific_name,
       (current_database())::information_schema.sql_identifier                                                       AS routine_catalog,
       (n.nspname)::information_schema.sql_identifier                                                                AS routine_schema,
       (p.proname)::information_schema.sql_identifier                                                                AS routine_name,
       ('EXECUTE'::information_schema.character_data)::information_schema.character_data                             AS privilege_type,
       (CASE
          WHEN aclcontains(p.proacl, makeaclitem(0, g_grantee.grosysid, u_grantor.usesysid, 'EXECUTE'::text, true))
            THEN 'YES'::text
          ELSE 'NO'::text END)::information_schema.character_data                                                    AS is_grantable
FROM pg_proc p,
     pg_namespace n,
     pg_user u_grantor,
     pg_group g_grantee
WHERE (((p.pronamespace = n.oid) AND
        aclcontains(p.proacl, makeaclitem(0, g_grantee.grosysid, u_grantor.usesysid, 'EXECUTE'::text, false))) AND
       ((g_grantee.groname)::information_schema.sql_identifier IN
        (SELECT enabled_roles.role_name FROM information_schema.enabled_roles)));

alter table role_routine_grants
  owner to rdsdb;

