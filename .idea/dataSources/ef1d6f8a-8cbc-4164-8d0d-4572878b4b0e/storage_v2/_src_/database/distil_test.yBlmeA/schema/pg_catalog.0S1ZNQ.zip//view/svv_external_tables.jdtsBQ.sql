create view svv_external_tables as
SELECT (btrim((ext_tables.schemaname)::text))::character varying(128)        AS schemaname,
       (btrim((ext_tables.tablename)::text))::character varying(128)         AS tablename,
       (btrim((ext_tables."location")::text))::character varying(128)        AS "location",
       (btrim((ext_tables.input_format)::text))::character varying(128)      AS input_format,
       (btrim((ext_tables.output_format)::text))::character varying(128)     AS output_format,
       (btrim((ext_tables.serialization_lib)::text))::character varying(128) AS serialization_lib,
       (btrim((ext_tables.serde_parameters)::text))::character varying(128)  AS serde_parameters,
       ext_tables.compressed,
       (btrim((ext_tables.parameters)::text))::character varying(128)        AS parameters
FROM pg_get_external_tables() ext_tables(esoid integer, schemaname character varying, tablename character varying,
                                         "location" character varying, input_format character varying,
                                         output_format character varying, serialization_lib character varying,
                                         serde_parameters character varying, compressed integer,
                                         parameters character varying)
ORDER BY (btrim((ext_tables.schemaname)::text))::character varying(128),
         (btrim((ext_tables.tablename)::text))::character varying(128);

alter table svv_external_tables
  owner to rdsdb;

