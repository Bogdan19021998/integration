create function "_pg_keyissubset"(smallint[], smallint[]) returns boolean
  immutable
  language sql
as
$$
select $1[1] is null or ($1[1] = any ($2) and coalesce(information_schema._pg_keyissubset($1[2:pg_catalog.array_upper($1,1)], $2), true))
$$;

