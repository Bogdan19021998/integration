create view distil_customers as
SELECT (pg_catalog.row_number() OVER ( PARTITION BY data_types.int_type))::character varying AS id,
       data_types.int_type,
       data_types.bigint_type,
       data_types.smallint_type,
       data_types.numeric_type,
       data_types.float_type,
       data_types.decimal_type,
       data_types.real_type,
       data_types.double_precision_type,
       data_types.text_type,
       data_types.varcharvarying_type,
       data_types.varchar_type,
       data_types.timestamp_type,
       data_types.date_type,
       data_types.bool_type
FROM data_types;

alter table distil_customers
  owner to vitaliy;

