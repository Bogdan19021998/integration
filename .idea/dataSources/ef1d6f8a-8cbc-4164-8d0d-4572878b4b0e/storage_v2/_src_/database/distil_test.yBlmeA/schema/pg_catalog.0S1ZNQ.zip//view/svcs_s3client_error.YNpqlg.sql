create view svcs_s3client_error as
  SELECT stcs.userid,
         "map".primary_query      AS query,
         ('1970-01-01 00:00:00'::timestamp without time zone +
          (((((stcs.recordtime)::numeric / (1000.0 * 1000.0)) + 946684800.0))::double precision *
           '00:00:01'::interval)) AS recordtime,
         stcs.pid,
         stcs.http_method,
         stcs.bucket,
         stcs."key",
         stcs.error
  FROM (stcs_s3client_error stcs
         JOIN stcs_concurrency_scaling_query_mapping "map" ON (("map".concurrency_scaling_query = stcs.query)))
  WHERE ((("map".concurrency_scaling_cluster)::text =
          split_part(split_part((stcs.__path)::text, '/stl_s3client_error/'::text, 2), '_'::text, 1)) AND (((EXISTS(
      SELECT 1 FROM pg_user WHERE ((pg_user.usename = ("current_user"())::name) AND (pg_user.usesuper = true)))) OR
                                                                                                            (EXISTS(
                                                                                                                SELECT 1
                                                                                                                FROM pg_shadow_extended
                                                                                                                WHERE (((pg_shadow_extended."sysid" = "current_user_id"()) AND
                                                                                                                        (pg_shadow_extended.colnum = 2)) AND
                                                                                                                       (pg_shadow_extended.value = (-1)::text))))) OR
                                                                                                           (stcs.userid = "current_user_id"())))
  UNION ALL
  SELECT stl_s3client_error.userid,
         stl_s3client_error.query,
         stl_s3client_error.recordtime,
         stl_s3client_error.pid,
         stl_s3client_error.http_method,
         stl_s3client_error.bucket,
         stl_s3client_error."key",
         stl_s3client_error.error
  FROM stl_s3client_error;

alter table svcs_s3client_error
  owner to rdsdb;

