create view svcs_alert_event_log as
  SELECT stcs.userid,
         "map".primary_query      AS query,
         stcs.segment,
         stcs.step,
         stcs.pid,
         stcs.xid,
         stcs.event,
         stcs.solution,
         ('1970-01-01 00:00:00'::timestamp without time zone +
          (((((stcs.event_time)::numeric / (1000.0 * 1000.0)) + 946684800.0))::double precision *
           '00:00:01'::interval)) AS event_time
  FROM (stcs_alert_event_log stcs
         JOIN stcs_concurrency_scaling_query_mapping "map" ON (("map".concurrency_scaling_query = stcs.query)))
  WHERE ((("map".concurrency_scaling_cluster)::text =
          split_part(split_part((stcs.__path)::text, '/stl_alert_event_log/'::text, 2), '_'::text, 1)) AND (((EXISTS(
      SELECT 1 FROM pg_user WHERE ((pg_user.usename = ("current_user"())::name) AND (pg_user.usesuper = true)))) OR
                                                                                                             (EXISTS(
                                                                                                                 SELECT 1
                                                                                                                 FROM pg_shadow_extended
                                                                                                                 WHERE (((pg_shadow_extended."sysid" = "current_user_id"()) AND
                                                                                                                         (pg_shadow_extended.colnum = 2)) AND
                                                                                                                        (pg_shadow_extended.value = (-1)::text))))) OR
                                                                                                            (stcs.userid = "current_user_id"())))
  UNION ALL
  SELECT stl_alert_event_log.userid,
         stl_alert_event_log.query,
         stl_alert_event_log.segment,
         stl_alert_event_log.step,
         stl_alert_event_log.pid,
         stl_alert_event_log.xid,
         stl_alert_event_log.event,
         stl_alert_event_log.solution,
         stl_alert_event_log.event_time
  FROM stl_alert_event_log;

alter table svcs_alert_event_log
  owner to rdsdb;

