create view triggered_update_columns as
SELECT (current_database())::information_schema.sql_identifier                      AS trigger_catalog,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier AS trigger_schema,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier AS trigger_name,
       (current_database())::information_schema.sql_identifier                      AS event_object_catalog,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier AS event_object_schema,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier AS event_object_table,
       (NULL::information_schema.sql_identifier)::information_schema.sql_identifier AS event_object_column
WHERE false;

alter table triggered_update_columns
  owner to rdsdb;

