create view svl_s3list as
SELECT stl_s3list.query,
       stl_s3list.segment,
       stl_s3list.node,
       stl_s3list.slice,
       stl_s3list.eventtime,
       btrim((stl_s3list.bucket)::text) AS bucket,
       btrim((stl_s3list.prefix)::text) AS prefix,
       stl_s3list."recursive",
       stl_s3list.retrieved_files,
       stl_s3list.max_file_size,
       stl_s3list.avg_file_size,
       stl_s3list.generated_splits,
       stl_s3list.avg_split_length,
       stl_s3list.duration
FROM stl_s3list;

alter table svl_s3list
  owner to rdsdb;

