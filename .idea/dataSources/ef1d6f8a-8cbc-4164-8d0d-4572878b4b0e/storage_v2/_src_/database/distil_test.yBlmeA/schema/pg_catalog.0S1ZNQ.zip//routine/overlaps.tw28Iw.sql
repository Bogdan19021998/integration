create function "overlaps"(time without time zone, interval, time without time zone, interval) returns boolean
  immutable
  language sql
as
$$
select ($1, ($1 + $2)) overlaps ($3, ($3 + $4))
$$;

comment on function "overlaps"(time, interval, time, interval) is 'SQL92 interval comparison';

