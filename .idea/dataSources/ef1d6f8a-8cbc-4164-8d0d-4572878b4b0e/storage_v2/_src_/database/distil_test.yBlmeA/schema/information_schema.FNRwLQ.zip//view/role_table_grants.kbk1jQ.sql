create view role_table_grants as
SELECT (u_grantor.usename)::information_schema.sql_identifier                       AS grantor,
       (g_grantee.groname)::information_schema.sql_identifier                       AS grantee,
       (current_database())::information_schema.sql_identifier                      AS table_catalog,
       (nc.nspname)::information_schema.sql_identifier                              AS table_schema,
       (c.relname)::information_schema.sql_identifier                               AS table_name,
       (pr."type")::information_schema.character_data                               AS privilege_type,
       (CASE
          WHEN aclcontains(c.relacl, makeaclitem(0, g_grantee.grosysid, u_grantor.usesysid, (pr."type")::text, true))
            THEN 'YES'::text
          ELSE 'NO'::text END)::information_schema.character_data                   AS is_grantable,
       ('NO'::information_schema.character_data)::information_schema.character_data AS with_hierarchy
FROM pg_class c,
     pg_namespace nc,
     pg_user u_grantor,
     pg_group g_grantee,
     ((((((SELECT 'SELECT'::character varying UNION ALL SELECT 'DELETE'::character varying)
          UNION ALL
          SELECT 'INSERT'::character varying)
         UNION ALL
         SELECT 'UPDATE'::character varying)
        UNION ALL
        SELECT 'REFERENCES'::character varying)
       UNION ALL
       SELECT 'RULE'::character varying)
      UNION ALL
      SELECT 'TRIGGER'::character varying) pr("type")
WHERE ((((c.relnamespace = nc.oid) AND ((c.relkind = 'r'::"char") OR (c.relkind = 'v'::"char"))) AND
        aclcontains(c.relacl, makeaclitem(0, g_grantee.grosysid, u_grantor.usesysid, (pr."type")::text, false))) AND
       ((g_grantee.groname)::information_schema.sql_identifier IN
        (SELECT enabled_roles.role_name FROM information_schema.enabled_roles)));

alter table role_table_grants
  owner to rdsdb;

