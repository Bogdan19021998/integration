create view pg_stat_database as
SELECT d.oid                                                                     AS datid,
       d.datname,
       pg_stat_get_db_numbackends(d.oid)                                         AS numbackends,
       pg_stat_get_db_xact_commit(d.oid)                                         AS xact_commit,
       pg_stat_get_db_xact_rollback(d.oid)                                       AS xact_rollback,
       (pg_stat_get_db_blocks_fetched(d.oid) - pg_stat_get_db_blocks_hit(d.oid)) AS blks_read,
       pg_stat_get_db_blocks_hit(d.oid)                                          AS blks_hit
FROM pg_database d;

alter table pg_stat_database
  owner to rdsdb;

