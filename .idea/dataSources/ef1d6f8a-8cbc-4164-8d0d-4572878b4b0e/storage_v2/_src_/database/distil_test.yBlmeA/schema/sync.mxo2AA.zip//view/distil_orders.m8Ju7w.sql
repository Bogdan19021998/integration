create view distil_orders as
SELECT (pg_catalog.row_number() OVER ( PARTITION BY test.string_column))::character varying AS id,
       test.string_column,
       test.int_column
FROM test;

alter table distil_orders
  owner to vitaliy;

