create view svcs_perf_histograms as
SELECT ('1970-01-01 00:00:00'::timestamp without time zone +
        (((((stcs_perf_histograms.now)::numeric / (1000.0 * 1000.0)) + 946684800.0))::double precision *
         '00:00:01'::interval)) AS now,
       ('1970-01-01 00:00:00'::timestamp without time zone +
        (((((stcs_perf_histograms.since)::numeric / (1000.0 * 1000.0)) + 946684800.0))::double precision *
         '00:00:01'::interval)) AS since,
       stcs_perf_histograms.name,
       stcs_perf_histograms.mean,
       stcs_perf_histograms.stdev,
       stcs_perf_histograms.ten_us,
       stcs_perf_histograms.hundred_us,
       stcs_perf_histograms.one_ms,
       stcs_perf_histograms.ten_ms,
       stcs_perf_histograms.hundred_ms,
       stcs_perf_histograms.one_s,
       stcs_perf_histograms.ten_s,
       stcs_perf_histograms.inf,
       stcs_perf_histograms.min,
       stcs_perf_histograms."max",
       stcs_perf_histograms.total,
       stcs_perf_histograms.sum,
       stcs_perf_histograms.node
FROM stcs_perf_histograms;

alter table svcs_perf_histograms
  owner to rdsdb;

