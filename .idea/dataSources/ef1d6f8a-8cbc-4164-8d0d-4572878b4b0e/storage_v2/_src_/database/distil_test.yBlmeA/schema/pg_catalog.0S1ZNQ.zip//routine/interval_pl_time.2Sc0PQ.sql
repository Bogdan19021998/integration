create function interval_pl_time(interval, time without time zone) returns time without time zone
  immutable
  language sql
as
$$
select $2 + $1
$$;

comment on function interval_pl_time(interval, time) is 'plus';

