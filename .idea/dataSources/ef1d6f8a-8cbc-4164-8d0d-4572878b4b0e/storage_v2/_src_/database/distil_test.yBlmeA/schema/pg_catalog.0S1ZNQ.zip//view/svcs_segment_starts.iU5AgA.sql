create view svcs_segment_starts as
SELECT stcs.userid,
       stcs.node,
       stcs.tasknum,
       stcs.pid,
       ('1970-01-01 00:00:00'::timestamp without time zone +
        (((((stcs.starttime)::numeric / (1000.0 * 1000.0)) + 946684800.0))::double precision *
         '00:00:01'::interval)) AS starttime,
       "map".primary_query      AS query,
       stcs.slice,
       stcs.seg
FROM (stcs_segment_starts stcs
       JOIN stcs_concurrency_scaling_query_mapping "map" ON (("map".concurrency_scaling_query = stcs.query)))
WHERE (("map".concurrency_scaling_cluster)::text =
       split_part(split_part((stcs.__path)::text, '/stl_segment_starts/'::text, 2), '_'::text, 1));

alter table svcs_segment_starts
  owner to rdsdb;

