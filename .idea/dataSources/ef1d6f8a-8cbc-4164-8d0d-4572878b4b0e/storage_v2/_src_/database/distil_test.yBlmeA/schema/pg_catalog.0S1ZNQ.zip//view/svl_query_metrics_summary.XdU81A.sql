create view svl_query_metrics_summary as
SELECT svl_query_metrics.userid,
       svl_query_metrics.query,
       svl_query_metrics.service_class,
       "max"(svl_query_metrics.query_cpu_time)             AS query_cpu_time,
       "max"(svl_query_metrics.query_blocks_read)          AS query_blocks_read,
       "max"(svl_query_metrics.query_execution_time)       AS query_execution_time,
       "max"(svl_query_metrics.query_cpu_usage_percent)    AS query_cpu_usage_percent,
       "max"(svl_query_metrics.query_temp_blocks_to_disk)  AS query_temp_blocks_to_disk,
       "max"(svl_query_metrics.segment_execution_time)     AS segment_execution_time,
       "max"(svl_query_metrics.cpu_skew)                   AS cpu_skew,
       "max"(svl_query_metrics.io_skew)                    AS io_skew,
       "max"(svl_query_metrics.scan_row_count)             AS scan_row_count,
       "max"(svl_query_metrics.join_row_count)             AS join_row_count,
       "max"(svl_query_metrics.nested_loop_join_row_count) AS nested_loop_join_row_count,
       "max"(svl_query_metrics.return_row_count)           AS return_row_count,
       "max"(svl_query_metrics.spectrum_scan_row_count)    AS spectrum_scan_row_count,
       "max"(svl_query_metrics.spectrum_scan_size_mb)      AS spectrum_scan_size_mb
FROM svl_query_metrics
GROUP BY svl_query_metrics.userid, svl_query_metrics.query, svl_query_metrics.service_class;

alter table svl_query_metrics_summary
  owner to rdsdb;

