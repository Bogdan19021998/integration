create view usage_privileges as
SELECT (u.usename)::information_schema.sql_identifier                                   AS grantor,
       ('PUBLIC'::information_schema.sql_identifier)::information_schema.sql_identifier AS grantee,
       (current_database())::information_schema.sql_identifier                          AS object_catalog,
       (n.nspname)::information_schema.sql_identifier                                   AS object_schema,
       (t.typname)::information_schema.sql_identifier                                   AS object_name,
       ('DOMAIN'::information_schema.character_data)::information_schema.character_data AS object_type,
       ('USAGE'::information_schema.character_data)::information_schema.character_data  AS privilege_type,
       ('NO'::information_schema.character_data)::information_schema.character_data     AS is_grantable
FROM pg_user u,
     pg_namespace n,
     pg_type t
WHERE (((u.usesysid = t.typowner) AND (t.typnamespace = n.oid)) AND (t.typtype = 'd'::"char"));

alter table usage_privileges
  owner to rdsdb;

