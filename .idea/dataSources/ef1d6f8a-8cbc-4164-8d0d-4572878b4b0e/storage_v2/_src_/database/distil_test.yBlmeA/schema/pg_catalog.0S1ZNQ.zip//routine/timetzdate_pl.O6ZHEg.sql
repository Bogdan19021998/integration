create function timetzdate_pl(time with time zone, date) returns timestamp with time zone
  immutable
  language sql
as
$$
select ($2 + $1)
$$;

comment on function timetzdate_pl(time with time zone, date) is 'convert time with time zone and date to timestamp with time zone';

