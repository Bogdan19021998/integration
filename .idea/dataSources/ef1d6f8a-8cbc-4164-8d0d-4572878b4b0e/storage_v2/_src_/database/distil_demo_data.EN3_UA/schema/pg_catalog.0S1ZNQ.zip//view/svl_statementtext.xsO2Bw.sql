create view svl_statementtext as
  (SELECT stl_ddltext.userid,
          stl_ddltext.xid,
          stl_ddltext.pid,
          stl_ddltext."label",
          stl_ddltext.starttime,
          stl_ddltext.endtime,
          stl_ddltext."sequence",
          ('DDL'::character varying)::character varying(10)               AS "type",
          (CASE
             WHEN (rtrim((stl_ddltext.text)::text) = (0)::text) THEN (stl_ddltext.text)::text
             ELSE rtrim((stl_ddltext.text)::text) END)::character varying AS text
   FROM stl_ddltext
   UNION ALL
   SELECT stl_utilitytext.userid,
          stl_utilitytext.xid,
          stl_utilitytext.pid,
          stl_utilitytext."label",
          stl_utilitytext.starttime,
          stl_utilitytext.endtime,
          stl_utilitytext."sequence",
          ('UTILITY'::character varying)::character varying(10)               AS "type",
          (CASE
             WHEN (rtrim((stl_utilitytext.text)::text) = (0)::text) THEN (stl_utilitytext.text)::text
             ELSE rtrim((stl_utilitytext.text)::text) END)::character varying AS text
   FROM stl_utilitytext)
  UNION ALL
  SELECT stl_query.userid,
         stl_query.xid,
         stl_query.pid,
         stl_query."label",
         stl_query.starttime,
         stl_query.endtime,
         stl_querytext."sequence",
         ('QUERY'::character varying)::character varying(10)               AS "type",
         (CASE
            WHEN (rtrim((stl_querytext.text)::text) = (0)::text) THEN (stl_querytext.text)::text
            ELSE rtrim((stl_querytext.text)::text) END)::character varying AS text
  FROM stl_query,
       stl_querytext
  WHERE (stl_query.query = stl_querytext.query);

alter table svl_statementtext
  owner to rdsdb;

