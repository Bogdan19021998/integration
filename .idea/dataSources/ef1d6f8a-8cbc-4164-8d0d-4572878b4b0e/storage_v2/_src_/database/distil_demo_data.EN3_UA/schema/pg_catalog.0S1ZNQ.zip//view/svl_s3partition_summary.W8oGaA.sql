create view svl_s3partition_summary as
SELECT stl_s3partition_elimination.query,
       stl_s3partition_elimination.segment,
       stl_s3partition_elimination."assignment",
       min(stl_s3partition_elimination.starttime)                                                               AS min_starttime,
       "max"(stl_s3partition_elimination.endtime)                                                               AS max_endtime,
       min(date_diff('us'::text, stl_s3partition_elimination.starttime,
                     stl_s3partition_elimination.endtime))                                                      AS min_duration,
       "max"(date_diff('us'::text, stl_s3partition_elimination.starttime,
                       stl_s3partition_elimination.endtime))                                                    AS max_duration,
       avg(date_diff('us'::text, stl_s3partition_elimination.starttime,
                     stl_s3partition_elimination.endtime))                                                      AS avg_duration,
       "max"(stl_s3partition_elimination.total_partitions)                                                      AS total_partitions,
       "max"(stl_s3partition_elimination.qualified_partitions)                                                  AS qualified_partitions,
       min(stl_s3partition_elimination.assigned_partitions)                                                     AS min_assigned_partitions,
       "max"(stl_s3partition_elimination.assigned_partitions)                                                   AS max_assigned_partitions,
       avg(stl_s3partition_elimination.assigned_partitions)                                                     AS avg_assigned_partitions
FROM stl_s3partition_elimination
GROUP BY stl_s3partition_elimination.query, stl_s3partition_elimination.segment,
         stl_s3partition_elimination."assignment";

alter table svl_s3partition_summary
  owner to rdsdb;

