create view pg_database_info as
SELECT pg_database.oid                                                                                       AS datid,
       pg_database.datname,
       pg_database.datdba,
       pg_database."encoding",
       pg_database.datistemplate,
       pg_database.datallowconn,
       pg_database.datlastsysoid,
       pg_database.datvacuumxid,
       pg_database.datfrozenxid,
       pg_database.dattablespace,
       pg_database.datconfig,
       pg_database.datacl,
       CASE
         WHEN (pde_col1.value = ((- (1)::smallint))::text) THEN 'UNLIMITED'::text
         ELSE pde_col1.value END                                                                             AS datconnlimit
FROM (pg_database
       LEFT JOIN pg_database_extended pde_col1 ON (((pg_database.oid = pde_col1.dbid) AND (pde_col1.colnum = 1))));

alter table pg_database_info
  owner to rdsdb;

