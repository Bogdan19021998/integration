create view svcs_s3catalog as
SELECT "map".primary_query                                                                                            AS query,
       stcs.segment,
       stcs.node,
       ('1970-01-01 00:00:00'::timestamp without time zone +
        (((((stcs.eventtime)::numeric / (1000.0 * 1000.0)) + 946684800.0))::double precision *
         '00:00:01'::interval))                                                                                       AS eventtime,
       stcs."call",
       stcs.objects,
       stcs.duration
FROM (stcs_external_catalog_calls stcs
       JOIN stcs_concurrency_scaling_query_mapping "map" ON (("map".concurrency_scaling_query = stcs.query)))
WHERE (("map".concurrency_scaling_cluster)::text =
       split_part(split_part((stcs.__path)::text, '/stl_external_catalog_calls/'::text, 2), '_'::text, 1));

alter table svcs_s3catalog
  owner to rdsdb;

