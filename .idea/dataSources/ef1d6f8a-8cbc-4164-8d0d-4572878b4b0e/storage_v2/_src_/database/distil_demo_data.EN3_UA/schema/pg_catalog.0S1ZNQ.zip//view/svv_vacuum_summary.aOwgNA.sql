create view svv_vacuum_summary as
SELECT COALESCE(rtrim((t.name)::text), 'TABLE DROPPED'::text) AS table_name,
       v.xid,
       s.parts                                                AS sort_partitions,
       m.increments                                           AS merge_increments,
       date_diff('microsec'::text, v.eventtime, v2.eventtime) AS elapsed_time,
       (v2."rows" - v."rows")                                 AS row_delta,
       (v2.sortedrows - v.sortedrows)                         AS sortedrow_delta,
       (v2."blocks" - v."blocks")                             AS block_delta,
       v.max_merge_partitions
FROM (((stl_vacuum v JOIN (SELECT stl_query.xid, count(*) AS parts
                           FROM stl_query
                           WHERE ((rtrim((stl_query.querytxt)::text) ~~ '% sort (partition%'::text) OR
                                  (rtrim((stl_query.querytxt)::text) ~~ 'Vacuum: delete %'::text))
                           GROUP BY stl_query.xid) s ON ((v.xid = s.xid))) JOIN (SELECT stl_query.xid, count(*) AS increments
                                                                                 FROM stl_query
                                                                                 WHERE ((rtrim((stl_query.querytxt)::text) ~~ '% merge (increment%'::text) OR
                                                                                        (rtrim((stl_query.querytxt)::text) ~~ 'Vacuum: delete %'::text))
                                                                                 GROUP BY stl_query.xid) m ON ((v.xid = m.xid)))
       LEFT JOIN stv_tbl_perm t ON (((v.table_id = t.id) AND (t.slice = 0)))),
     stl_vacuum v2
WHERE (((v.status <> 'Finished'::bpchar) AND (v2.status = 'Finished'::bpchar)) AND (v.xid = v2.xid))
ORDER BY COALESCE(rtrim((t.name)::text), 'TABLE DROPPED'::text), v.xid;

alter table svv_vacuum_summary
  owner to rdsdb;

