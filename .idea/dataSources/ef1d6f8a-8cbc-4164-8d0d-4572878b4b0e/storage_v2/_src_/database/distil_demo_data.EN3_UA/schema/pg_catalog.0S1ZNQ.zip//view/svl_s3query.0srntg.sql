create view svl_s3query as
SELECT stl_s3query.userid,
       stl_s3query.query,
       stl_s3query.segment,
       stl_s3query.step,
       stl_s3query.node,
       stl_s3query.slice,
       stl_s3query.starttime,
       stl_s3query.endtime,
       date_diff('us'::text, stl_s3query.starttime, stl_s3query.endtime) AS elapsed,
       btrim((stl_s3query.external_table_name)::text)                    AS external_table_name,
       stl_s3query.file_format,
       stl_s3query.is_partitioned,
       stl_s3query.is_rrscan,
       stl_s3query.is_nested,
       stl_s3query.s3_scanned_rows,
       stl_s3query.s3_scanned_bytes,
       stl_s3query.s3query_returned_rows,
       stl_s3query.s3query_returned_bytes,
       stl_s3query.files,
       stl_s3query.splits,
       stl_s3query.total_split_size,
       stl_s3query.max_split_size,
       stl_s3query.total_retries,
       stl_s3query.max_retries,
       stl_s3query.max_request_duration,
       stl_s3query.avg_request_duration,
       stl_s3query.max_request_parallelism,
       stl_s3query.avg_request_parallelism,
       stl_s3query.slowdown_count,
       stl_s3query.max_concurrent_slowdown_count
FROM stl_s3query
WHERE (stl_s3query.is_copy = 0);

alter table svl_s3query
  owner to rdsdb;

