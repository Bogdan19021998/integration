create function regexp_instr(text, text) returns integer
  immutable
  language sql
as
$$
select regexp_instr($1, $2, 1, 1, 0, '')
$$;

comment on function regexp_instr(text, text) is 'return beginning of matched regular expression';

