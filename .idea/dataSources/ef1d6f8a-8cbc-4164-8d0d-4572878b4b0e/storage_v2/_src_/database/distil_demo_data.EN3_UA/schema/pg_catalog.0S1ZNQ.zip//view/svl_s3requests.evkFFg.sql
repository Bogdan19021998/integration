create view svl_s3requests as
SELECT r.query,
       r.uuid,
       r.pid,
       r.segment,
       r.node,
       r.slice,
       r.eventtime,
       round(((r.duration)::double precision / (1000)::double precision), (1)::numeric)     AS duration_msec,
       r.retry_count,
       r.returned_rows,
       r.returned_bytes,
       r.s3_scanned_rows,
       r.s3_scanned_bytes,
       r.row_groups,
       r.skipped_row_groups,
       r.skipped_rows,
       r.fetched,
       r.file_size,
       r.start_offset,
       r.length,
       btrim((r."location")::text)                                                          AS "location",
       btrim((r.file_name)::text)                                                           AS "file",
       r.num_splits,
       round(((r.last_timeout)::double precision / (1000)::double precision), (1)::numeric) AS last_timeout_msec,
       r.failed,
       btrim((r.etag)::text)                                                                AS etag,
       q.request_fingerprint                                                                AS fingerprint,
       CASE WHEN (r.cache_status > 1) THEN -1 ELSE r.cache_status END                       AS cache_status,
       r.s3_physical_scanned_bytes,
       r.starttime,
       r.client_fetch_wait_time
FROM (stl_s3requests r
       LEFT JOIN stl_s3query q ON (((((r.query = q.query) AND (r.segment = q.segment)) AND (r.node = q.node)) AND
                                    (r.slice = q.slice))));

alter table svl_s3requests
  owner to rdsdb;

