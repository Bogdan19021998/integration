create view mv_customer_attribute_record as
SELECT mv_customer_attribute_record_old.id,
       mv_customer_attribute_record_old.customer_id,
       mv_customer_attribute_record_old.data_source_id,
       mv_customer_attribute_record_old.data_source_name,
       mv_customer_attribute_record_old.attribute_id,
       mv_customer_attribute_record_old.attribute_distil_name,
       mv_customer_attribute_record_old.attribute_display_name,
       mv_customer_attribute_record_old.attribute_type,
       mv_customer_attribute_record_old.attribute_data_tag,
       mv_customer_attribute_record_old.value_integer,
       mv_customer_attribute_record_old.value_double,
       mv_customer_attribute_record_old.value_string,
       mv_customer_attribute_record_old.value_text,
       mv_customer_attribute_record_old.value_date,
       mv_customer_attribute_record_old.value_boolean,
       mv_customer_attribute_record_old.value_long
FROM distil_org_neiltest541631.mv_customer_attribute_record_old;

alter table mv_customer_attribute_record
  owner to postgres;

