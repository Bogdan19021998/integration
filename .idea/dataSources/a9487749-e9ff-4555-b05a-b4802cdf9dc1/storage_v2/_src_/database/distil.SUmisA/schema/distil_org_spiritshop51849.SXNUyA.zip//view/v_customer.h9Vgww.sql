create view v_customer as
SELECT customer.id,
       customer.date_created,
       customer.date_updated,
       customer.is_anonymous_only,
       customer.deleted
FROM distil_org_spiritshop51849.customer;

alter table v_customer
  owner to postgres;

