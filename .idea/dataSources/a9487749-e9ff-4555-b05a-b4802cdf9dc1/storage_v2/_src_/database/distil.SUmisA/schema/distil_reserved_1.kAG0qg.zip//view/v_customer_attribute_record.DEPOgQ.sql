create view v_customer_attribute_record as
SELECT row_number() OVER (ORDER BY v.fk_customer_id) AS id,
       v.fk_customer_id                              AS customer_id,
       ds.id                                         AS data_source_id,
       ds.name                                       AS data_source_name,
       a.id                                          AS attribute_id,
       a.attribute_distil_name,
       a.attribute_display_name,
       a.attribute_type,
       a.attribute_data_tag,
       v.value_integer,
       v.value_double,
       v.value_string,
       v.value_text,
       v.value_date,
       v.value_boolean,
       v.value_long
FROM ((distil_reserved_1.data_source_attribute_value v
  JOIN distil_reserved_1.data_source ds ON ((v.fk_data_source_id = ds.id)))
       JOIN distil_reserved_1.data_source_attribute a ON ((v.fk_data_source_attribute_id = a.id)))
WHERE ((ds.data_source_type)::text ~~ '%CUSTOMER%'::text)
ORDER BY v.fk_customer_id;

alter table v_customer_attribute_record
  owner to postgres;

