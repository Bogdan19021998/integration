create procedure insert_test_user_invite_data(fk_org_id bigint, fk_inviting_user_id bigint, invite_response distil_app.invite_response, membership_type distil_app.membership_type, email_address character varying, first_name character varying, last_name character varying, fk_accepted_user_id bigint)
  language sql
as
$$
INSERT INTO distil_app.user_invite
(fk_org_id, fk_inviting_user_id, email_address, invite_response, first_name, last_name, date_invite_sent,
 date_invite_responded_to, membership_type, fk_accepted_user_id)
VALUES (fk_org_id, fk_inviting_user_id, email_address, invite_response, first_name, last_name, current_timestamp,
        current_timestamp, membership_type, fk_accepted_user_id)
$$;

alter procedure insert_test_user_invite_data(bigint, bigint, distil_app.invite_response, distil_app.membership_type, varchar, varchar, varchar, bigint) owner to postgres;

