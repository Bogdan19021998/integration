create view v_customer_data_marker_membership_latest as
SELECT ds.id,
       ds.fk_customer_data_marker_id,
       ds.fk_customer_id,
       ds.date_changed,
       ds.has_data_marker
FROM (SELECT customer_data_marker_membership.id,
             customer_data_marker_membership.fk_customer_data_marker_id,
             customer_data_marker_membership.fk_customer_id,
             customer_data_marker_membership.date_changed,
             customer_data_marker_membership.has_data_marker,
             row_number()
                 OVER (PARTITION BY customer_data_marker_membership.fk_customer_id, customer_data_marker_membership.fk_customer_data_marker_id ORDER BY customer_data_marker_membership.id DESC) AS rn
      FROM distil_org_aa95266.customer_data_marker_membership) ds
WHERE ((ds.rn = 1) AND (ds.has_data_marker = true));

alter table v_customer_data_marker_membership_latest
  owner to postgres;

