create view v_customer_segmentation_rule_data as
SELECT c.id                                AS customer_id,
       g.fk_customer_segment_id            AS segment_id,
       r.fk_customer_segment_rule_group_id AS rule_group_id,
       r.id                                AS rule_id,
       dsa.id                              AS fk_data_source_attribute_id,
       r.match_condition,
       v.value_integer,
       r.value_integer                     AS rule_value_integer,
       v.value_double,
       r.value_double                      AS rule_value_double,
       v.value_string,
       r.value_string                      AS rule_value_string,
       v.value_text,
       r.value_text                        AS rule_value_text,
       v.value_date,
       r.value_date                        AS rule_value_date,
       v.value_boolean,
       r.value_boolean                     AS rule_value_boolean,
       v.value_long,
       r.value_long                        AS rule_value_long
FROM ((((distil_org_moga74982.v_customer c
  LEFT JOIN distil_org_moga74982.data_source_attribute dsa ON (true))
  LEFT JOIN distil_org_moga74982.v_data_source_attribute_value v ON ((((v.fk_customer_id)::text = (c.id)::text) AND
                                                                      (dsa.id = v.fk_data_source_attribute_id))))
  LEFT JOIN distil_org_moga74982.customer_segment_rule r ON ((dsa.id = r.fk_data_source_attribute_id)))
       LEFT JOIN distil_org_moga74982.customer_segment_rule_group g ON ((r.fk_customer_segment_rule_group_id = g.id)));

alter table v_customer_segmentation_rule_data
  owner to postgres;

