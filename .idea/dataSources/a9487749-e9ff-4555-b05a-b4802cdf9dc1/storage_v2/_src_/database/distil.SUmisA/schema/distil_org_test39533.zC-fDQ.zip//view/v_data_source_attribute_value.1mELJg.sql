create view v_data_source_attribute_value as
SELECT data_source_attribute_value.id,
       data_source_attribute_value.fk_customer_id,
       data_source_attribute_value.fk_data_source_id,
       data_source_attribute_value.fk_data_source_attribute_id,
       data_source_attribute_value.date_created,
       data_source_attribute_value.date_updated,
       data_source_attribute_value.value_integer,
       data_source_attribute_value.value_double,
       data_source_attribute_value.value_string,
       data_source_attribute_value.value_text,
       data_source_attribute_value.value_date,
       data_source_attribute_value.value_boolean,
       data_source_attribute_value.value_long
FROM distil_org_test39533.data_source_attribute_value;

alter table v_data_source_attribute_value
  owner to postgres;

