create view mv_customers_core_details as
SELECT mv_customers_core_details_old.id,
       mv_customers_core_details_old.external_id,
       mv_customers_core_details_old.first_name,
       mv_customers_core_details_old.last_name,
       mv_customers_core_details_old.email_address,
       mv_customers_core_details_old.mobile_number,
       mv_customers_core_details_old.postal_code,
       mv_customers_core_details_old.country_code
FROM distil_reserved_0.mv_customers_core_details_old;

alter table mv_customers_core_details
  owner to postgres;

