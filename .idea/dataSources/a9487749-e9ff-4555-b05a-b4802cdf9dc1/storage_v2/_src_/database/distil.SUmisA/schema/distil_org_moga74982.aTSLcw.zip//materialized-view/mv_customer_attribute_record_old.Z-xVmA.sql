create materialized view mv_customer_attribute_record_old as
SELECT row_number() OVER () AS id,
       dsav.fk_customer_id  AS customer_id,
       ds.id                AS data_source_id,
       ds.name              AS data_source_name,
       dsa.id               AS attribute_id,
       dsa.attribute_distil_name,
       dsa.attribute_display_name,
       dsa.attribute_type,
       dsa.attribute_data_tag,
       dsav.value_integer,
       dsav.value_double,
       dsav.value_string,
       dsav.value_text,
       dsav.value_date,
       dsav.value_boolean,
       dsav.value_long
FROM ((distil_org_moga74982.data_source ds
  JOIN distil_org_moga74982.data_source_attribute dsa ON ((ds.id = dsa.fk_data_source_id)))
       JOIN (SELECT DISTINCT data_source_attribute_value.fk_customer_id,
                             data_source_attribute_value.fk_data_source_id,
                             data_source_attribute_value.fk_data_source_attribute_id,
                             data_source_attribute_value.value_integer,
                             data_source_attribute_value.value_double,
                             data_source_attribute_value.value_string,
                             data_source_attribute_value.value_text,
                             data_source_attribute_value.value_date,
                             data_source_attribute_value.value_boolean,
                             data_source_attribute_value.value_long
             FROM distil_org_moga74982.data_source_attribute_value) dsav
            ON ((dsav.fk_data_source_attribute_id = dsa.id)));

alter materialized view mv_customer_attribute_record_old owner to postgres;

create index idx_mv_customer_attribute_record_customer_id
  on mv_customer_attribute_record_old (customer_id);

