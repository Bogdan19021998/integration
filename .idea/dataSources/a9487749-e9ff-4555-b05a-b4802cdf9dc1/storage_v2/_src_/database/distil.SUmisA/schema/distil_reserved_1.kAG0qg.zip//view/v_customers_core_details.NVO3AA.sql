create view v_customers_core_details as
SELECT ds.fk_customer_id AS id,
       ds.external_id,
       ds.first_name,
       ds.last_name,
       ds.email_address,
       ds.mobile_number,
       ds.postal_code,
       ds.country_code
FROM (WITH customer_ids AS (
  SELECT DISTINCT v.fk_customer_id
  FROM (distil_reserved_1.data_source_attribute_value v
         JOIN distil_reserved_1.data_source_attribute a ON ((v.fk_data_source_attribute_id = a.id)))
  WHERE (v.fk_data_source_id = (SELECT data_source.id
                                FROM distil_reserved_1.data_source
                                WHERE ((data_source.data_source_type)::text = 'CUSTOMER_CORE_DATA'::text)))
  ), external_ids AS (
  SELECT v.fk_customer_id,
         v.value_string AS external_id
  FROM (distil_reserved_1.data_source_attribute_value v
         JOIN distil_reserved_1.data_source_attribute a ON ((v.fk_data_source_attribute_id = a.id)))
  WHERE ((v.fk_data_source_id = (SELECT data_source.id
                                 FROM distil_reserved_1.data_source
                                 WHERE ((data_source.data_source_type)::text = 'CUSTOMER_CORE_DATA'::text))) AND
         (a.attribute_data_tag = 2))
  ), first_names AS (
  SELECT v.fk_customer_id,
         v.value_string AS first_name
  FROM (distil_reserved_1.data_source_attribute_value v
         JOIN distil_reserved_1.data_source_attribute a ON ((v.fk_data_source_attribute_id = a.id)))
  WHERE ((v.fk_data_source_id = (SELECT data_source.id
                                 FROM distil_reserved_1.data_source
                                 WHERE ((data_source.data_source_type)::text = 'CUSTOMER_CORE_DATA'::text))) AND
         (a.attribute_data_tag = 5))
  ), last_names AS (
  SELECT v.fk_customer_id,
         v.value_string AS last_name
  FROM (distil_reserved_1.data_source_attribute_value v
         JOIN distil_reserved_1.data_source_attribute a ON ((v.fk_data_source_attribute_id = a.id)))
  WHERE ((v.fk_data_source_id = (SELECT data_source.id
                                 FROM distil_reserved_1.data_source
                                 WHERE ((data_source.data_source_type)::text = 'CUSTOMER_CORE_DATA'::text))) AND
         (a.attribute_data_tag = 6))
  ), email_addresses AS (
  SELECT v.fk_customer_id,
         v.value_string AS email_address
  FROM (distil_reserved_1.data_source_attribute_value v
         JOIN distil_reserved_1.data_source_attribute a ON ((v.fk_data_source_attribute_id = a.id)))
  WHERE ((v.fk_data_source_id = (SELECT data_source.id
                                 FROM distil_reserved_1.data_source
                                 WHERE ((data_source.data_source_type)::text = 'CUSTOMER_CORE_DATA'::text))) AND
         (a.attribute_data_tag = 3))
  ), mobile_numbers AS (
  SELECT v.fk_customer_id,
         v.value_string AS mobile_number
  FROM (distil_reserved_1.data_source_attribute_value v
         JOIN distil_reserved_1.data_source_attribute a ON ((v.fk_data_source_attribute_id = a.id)))
  WHERE ((v.fk_data_source_id = (SELECT data_source.id
                                 FROM distil_reserved_1.data_source
                                 WHERE ((data_source.data_source_type)::text = 'CUSTOMER_CORE_DATA'::text))) AND
         (a.attribute_data_tag = 7))
  ), postcodes AS (
  SELECT v.fk_customer_id,
         v.value_string AS postal_code
  FROM (distil_reserved_1.data_source_attribute_value v
         JOIN distil_reserved_1.data_source_attribute a ON ((v.fk_data_source_attribute_id = a.id)))
  WHERE ((v.fk_data_source_id = (SELECT data_source.id
                                 FROM distil_reserved_1.data_source
                                 WHERE ((data_source.data_source_type)::text = 'CUSTOMER_CORE_DATA'::text))) AND
         (a.attribute_data_tag = 4))
  ), country_codes AS (
  SELECT v.fk_customer_id,
         v.value_string AS country_code
  FROM (distil_reserved_1.data_source_attribute_value v
         JOIN distil_reserved_1.data_source_attribute a ON ((v.fk_data_source_attribute_id = a.id)))
  WHERE ((v.fk_data_source_id = (SELECT data_source.id
                                 FROM distil_reserved_1.data_source
                                 WHERE ((data_source.data_source_type)::text = 'CUSTOMER_CORE_DATA'::text))) AND
         (a.attribute_data_tag = 8))
  )
  SELECT c.fk_customer_id,
         ex.external_id,
         fn.first_name,
         ln.last_name,
         em.email_address,
         mb.mobile_number,
         pc.postal_code,
         cc.country_code
  FROM (((((((customer_ids c
    LEFT JOIN external_ids ex ON ((c.fk_customer_id = ex.fk_customer_id)))
    LEFT JOIN first_names fn ON ((c.fk_customer_id = fn.fk_customer_id)))
    LEFT JOIN last_names ln ON ((c.fk_customer_id = ln.fk_customer_id)))
    LEFT JOIN email_addresses em ON ((c.fk_customer_id = em.fk_customer_id)))
    LEFT JOIN mobile_numbers mb ON ((c.fk_customer_id = mb.fk_customer_id)))
    LEFT JOIN postcodes pc ON ((c.fk_customer_id = pc.fk_customer_id)))
         LEFT JOIN country_codes cc ON ((c.fk_customer_id = cc.fk_customer_id)))) ds;

alter table v_customers_core_details
  owner to postgres;

